package kr.personal.foldfinance.domain

/** 금융 알림의 최소 필드만 파싱. 원문은 저장하지 않는다. */
data class ParsedNotice(val amount: Long, val merchant: String, val kind: String)

object BankNoticeParser {
    private val amountPattern = Regex("(?:^|\\s|\\[|\\()([0-9]{1,3}(?:,[0-9]{3})+|[0-9]{4,9})\\s*원")
    private val merchantLabeled = Regex("(?:가맹점|사용처|이용처|결제처)\\s*[:：]\\s*([^\\n]+)")
    private val redacted = Regex("(?i)(\\d{6,}|비밀번호|인증번호|OTP)")
    fun parse(message: String): ParsedNotice? {
        if (message.length !in 6..1200) return null
        val compact = message.replace('\r', ' ')
        if (!listOf("승인", "결제", "사용", "취소", "환불").any { compact.contains(it) }) return null
        if (listOf("청구서", "카드대금", "결제예정금액", "교통카드 가승인", "후불교통", "교통카드 청구", "납부안내").any { compact.contains(it) }) return null
        val amount = amountPattern.find(compact)?.groupValues?.get(1)?.replace(",", "")?.toLongOrNull() ?: return null
        if (amount !in 1..100_000_000) return null
        val merchant = merchantLabeled.find(compact)?.groupValues?.get(1)?.trim()
            ?.take(45)?.takeIf { it.isNotBlank() && !redacted.containsMatchIn(it) }
            ?: return null // 가맹점을 확인하지 못했다면 추측 수집하지 않음
        val type = if (compact.contains("취소") || compact.contains("환불")) "REFUND" else "PURCHASE"
        return ParsedNotice(if (type == "REFUND") -amount else amount, merchant, type)
    }
}
