package kr.personal.foldfinance.domain

import java.time.LocalDate
import java.time.LocalTime

/**
 * 일정·소비 연결 추천 엔진. 날짜와 사용자가 확인한 결제 시각 없이는 추천하지 않는다.
 * 후보를 반환할 뿐 자동으로 태그/카테고리/실제 지출을 변경하지 않는다.
 */
data class EventWindow(
    val id: Long,
    val date: String,
    val title: String,
    val start: String,
    val end: String
)

data class EventCandidate(
    val id: Long,
    val title: String,
    val suggestedTag: String?,
    val confidence: String = "MEDIUM"
)

object EventExpenseMatcher {
    private fun clock(raw: String): LocalTime? = try {
        val value = LocalTime.parse(raw)
        if (raw.matches(Regex("(?:[01]\\d|2[0-3]):[0-5]\\d"))) value else null
    } catch (_: Exception) { null }

    private fun tag(title: String): String? = when {
        title.contains("데이트", ignoreCase = true) || title.contains("여자친구") || title.contains("남자친구") -> "데이트"
        title.contains("출퇴근") || title.contains("출근") || title.contains("퇴근") -> "출퇴근"
        title.contains("여행") -> "여행"
        else -> null
    }

    fun candidates(date: String, time: String?, merchant: String, events: List<EventWindow>): List<EventCandidate> {
        if (merchant.isBlank() || time.isNullOrBlank() || runCatching { LocalDate.parse(date) }.isFailure) return emptyList()
        val paid = clock(time) ?: return emptyList()
        return events.filter { event ->
            if (event.date != date) return@filter false
            val start = clock(event.start) ?: return@filter false
            val end = clock(event.end) ?: return@filter false
            !end.isBefore(start) && !paid.isBefore(start) && !paid.isAfter(end)
        }.map { EventCandidate(it.id, it.title, tag(it.title)) }
            .sortedWith(compareBy<EventCandidate> { it.id })
    }

    /** 사용자가 명시적으로 동의한 경우에만 기존 태그와 병합. */
    fun mergeTag(original: String, recommended: String?): String =
        (original.split(',').map { it.trim().removePrefix("#") } + listOfNotNull(recommended))
            .filter { it.isNotBlank() }.distinct().joinToString(",")
}
