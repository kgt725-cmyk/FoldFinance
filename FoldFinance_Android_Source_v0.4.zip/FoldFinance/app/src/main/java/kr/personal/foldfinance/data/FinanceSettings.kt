package kr.personal.foldfinance.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.financeSettingsStore by preferencesDataStore("finance_settings")

data class FinanceSettings(
    val salary: Long = 2_400_000,
    val savingsGoal: Long = 1_400_000,
    val budget: Long = 1_000_000,
    val payday: Int = 15,
    val oneWayFare: Long = 0, // 사용자가 실제 운임을 설정하기 전에는 예상 금액을 만들지 않는다
    val ridesPerDay: Int = 2,
    val weekdayMask: Int = 31, // 평일
    val kpassEnabled: Boolean = false,
    val widgetPrivate: Boolean = false
)

class SettingsStore(private val context: Context) {
    private object K {
        val salary = longPreferencesKey("salary")
        val savings = longPreferencesKey("savings")
        val budget = longPreferencesKey("budget")
        val payday = intPreferencesKey("payday")
        val fare = longPreferencesKey("fare")
        val rides = intPreferencesKey("rides")
        val weekdays = intPreferencesKey("weekdays")
        val kpass = booleanPreferencesKey("kpass")
        val widgetPrivate = booleanPreferencesKey("widget_private")
    }
    val state: Flow<FinanceSettings> = context.financeSettingsStore.data.map { prefs ->
        FinanceSettings(
            prefs[K.salary] ?: 2_400_000,
            prefs[K.savings] ?: 1_400_000,
            prefs[K.budget] ?: 1_000_000,
            prefs[K.payday] ?: 15,
            prefs[K.fare] ?: 0,
            prefs[K.rides] ?: 2,
            prefs[K.weekdays] ?: 31,
            prefs[K.kpass] ?: false,
            prefs[K.widgetPrivate] ?: false
        )
    }
    suspend fun current(): FinanceSettings = state.first()
    suspend fun update(s: FinanceSettings) {
        require(s.salary >= 0 && s.savingsGoal >= 0 && s.budget >= 0)
        require(s.payday in 1..28 && s.oneWayFare >= 0 && s.ridesPerDay in 0..10 && s.weekdayMask in 0..127)
        context.financeSettingsStore.edit {
            it[K.salary] = s.salary; it[K.savings] = s.savingsGoal; it[K.budget] = s.budget
            it[K.payday] = s.payday; it[K.fare] = s.oneWayFare; it[K.rides] = s.ridesPerDay
            it[K.weekdays] = s.weekdayMask; it[K.kpass] = s.kpassEnabled; it[K.widgetPrivate] = s.widgetPrivate
        }
    }
}

/** 알림 리스너 서비스에서 비동기로 설정이 늦게 읽히는 것을 피하기 위한 명시적 허용 목록 */
object BankPackageAllowlist {
    private const val SP = "bank_notification_sources"
    fun get(context: Context): Set<String> =
        context.getSharedPreferences(SP, Context.MODE_PRIVATE).getStringSet("packages", emptySet()) ?: emptySet()
    fun set(context: Context, raw: String) {
        val validated = raw.split(',', '\n', ' ').map { it.trim() }
            .filter { it.matches(Regex("[a-zA-Z][a-zA-Z0-9_]*(?:\\.[a-zA-Z][a-zA-Z0-9_]*)+")) }
            .toSet()
        context.getSharedPreferences(SP, Context.MODE_PRIVATE).edit().putStringSet("packages", validated).apply()
    }
}
