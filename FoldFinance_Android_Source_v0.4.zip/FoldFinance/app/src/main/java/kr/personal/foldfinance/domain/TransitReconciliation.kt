package kr.personal.foldfinance.domain

import java.time.LocalDate

/** 실제 이용내역의 날짜가 확정되기 전, 기간 총액을 개별 지출로 나누지 않는다. */
data class ConfirmedTransitUse(
    val date: LocalDate,
    val amount: Long
)

data class TransitReconciliation(
    val start: LocalDate,
    val endInclusive: LocalDate,
    val reportedAmount: Long,
    val knownDatedAmount: Long,
    val datedDays: Int,
    /** 양수: 신고 총액이 더 큼 / 음수: 확정 일별 기록이 더 큼 */
    val difference: Long
) {
    val amountMatches: Boolean get() = difference == 0L
    val requiresReview: Boolean get() = !amountMatches
}

object TransitReconcile {
    fun compare(
        start: LocalDate,
        endInclusive: LocalDate,
        reportedAmount: Long,
        actualUses: List<ConfirmedTransitUse>
    ): TransitReconciliation {
        require(!endInclusive.isBefore(start)) { "이용 종료일은 시작일보다 빠를 수 없습니다." }
        require(reportedAmount >= 0L) { "금액은 0원 이상이어야 합니다." }
        require(actualUses.all { it.amount >= 0 }) { "일별 확정 운임은 음수일 수 없습니다." }
        val relevant = actualUses.filter { it.date >= start && it.date <= endInclusive }
        // Long overflow를 허용하지 않고 오류로 처리
        val total = relevant.fold(0L) { acc, t -> Math.addExact(acc, t.amount) }
        val difference = Math.subtractExact(reportedAmount, total)
        return TransitReconciliation(start, endInclusive, reportedAmount, total, relevant.map { it.date }.distinct().size, difference)
    }
}
