package kr.personal.foldfinance

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import kr.personal.foldfinance.data.FinanceViewModel
import kr.personal.foldfinance.ui.FinanceApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val model: FinanceViewModel = viewModel()
            FinanceApp(model, Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing))
        }
    }
}
