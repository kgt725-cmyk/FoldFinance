package kr.personal.foldfinance.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [LedgerEntry::class, CalendarEvent::class, WorkdayOverride::class, TransitBill::class, TransitStatement::class, MerchantRule::class, RecurringPlan::class],
    version = 4, exportSchema = true
)
abstract class FinanceDatabase : RoomDatabase() {
    abstract fun dao(): AppDao
    companion object {
        // 기존 0.1 기록을 삭제하지 않는 데이터베이스 업데이트.
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS `transit_statements` (
                    `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    `startDate` TEXT NOT NULL,
                    `endDate` TEXT NOT NULL,
                    `amount` INTEGER NOT NULL,
                    `memo` TEXT NOT NULL
                )""".trimIndent())
                db.execSQL("""CREATE TABLE IF NOT EXISTS `merchant_rules` (
                    `merchantKey` TEXT NOT NULL PRIMARY KEY,
                    `category` TEXT NOT NULL,
                    `tags` TEXT NOT NULL,
                    `autoConfirm` INTEGER NOT NULL
                )""".trimIndent())
            }
        }
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `ledger` ADD COLUMN `occurredAtTime` TEXT")
                db.execSQL("ALTER TABLE `ledger` ADD COLUMN `linkedEventId` INTEGER")
            }
        }
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `ledger` ADD COLUMN `linkedRecurringId` INTEGER")
                db.execSQL("ALTER TABLE `ledger` ADD COLUMN `linkedPlanMonth` TEXT")
                db.execSQL("""CREATE TABLE IF NOT EXISTS `recurring_plans` (
                    `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    `kind` TEXT NOT NULL,
                    `title` TEXT NOT NULL,
                    `amount` INTEGER NOT NULL,
                    `category` TEXT NOT NULL,
                    `dayOfMonth` INTEGER NOT NULL,
                    `startMonth` TEXT NOT NULL,
                    `active` INTEGER NOT NULL,
                    `memo` TEXT NOT NULL
                )""".trimIndent())
            }
        }
        @Volatile private var INSTANCE: FinanceDatabase? = null
        fun get(context: Context): FinanceDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, FinanceDatabase::class.java, "foldfinance.db")
                // destructive migration 금지: 새 DB 변경 시 Migration을 작성해야 한다.
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4).build().also { INSTANCE = it }
        }
    }
}
