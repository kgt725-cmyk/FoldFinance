package kr.personal.foldfinance.domain

import java.time.LocalDate
import java.time.YearMonth

/** 예정 기록을 원장으로 복제하지 않는다. 실거래의 연결 키가 있을 때에만 실제 납입/결제를 인정한다. */
data class MonthlyPlan(
    val id: Long,
    val kind: String, // INCOME / EXPENSE
    val title: String,
    val amount: Long,
    val day: Int,
    val startMonth: YearMonth,
    val active: Boolean
)

data class PlanPayment(
    val planId: Long,
    val planMonth: YearMonth,
    val kind: String,
    val amount: Long,
    val status: String,
    val occurredOn: LocalDate
)

data class PlanOccurrence(
    val planId: Long,
    val kind: String,
    val title: String,
    val dueDate: LocalDate,
    val planMonth: YearMonth,
    val plannedAmount: Long,
    val actualAmount: Long,
    val pendingAmount: Long,
    val paymentCount: Int,
    val status: String,
    /** 급여 예정일과 별개의 근무 귀속월. 급여 항목에만 사용. */
    val incomeWorkMonth: YearMonth?
)

object RecurringMath {
    fun occurrences(plans: List<MonthlyPlan>, payments: List<PlanPayment>, window: DateWindow): List<PlanOccurrence> {
        val firstMonth = YearMonth.from(window.start)
        val lastMonth = YearMonth.from(window.endExclusive.minusDays(1))
        val planById = plans.associateBy { it.id }
        require(plans.map { it.id }.toSet().size == plans.size)
        require(plans.all { it.id > 0 && it.kind in setOf("INCOME", "EXPENSE") && it.day in 1..28 && it.amount > 0 })
        require(payments.all { p ->
            p.planId in planById && p.kind == planById[p.planId]?.kind && p.amount > 0 &&
                p.status in setOf("EXPECTED", "REVIEW", "CONFIRMED", "SETTLED")
        })
        val grouped = payments.filter { it.status == "CONFIRMED" || it.status == "SETTLED" }
            .groupBy { it.planId to it.planMonth }
        return plans.asSequence().filter { it.active }.flatMap { p ->
            generateSequence(firstMonth) { it.plusMonths(1) }
                .takeWhile { it <= lastMonth }.filter { it >= p.startMonth }
                .map { m ->
                    val due = m.atDay(p.day)
                    if (!window.contains(due)) null else {
                        val matched = grouped[p.id to m].orEmpty()
                        val actual = matched.fold(0L) { acc, payment -> Math.addExact(acc, payment.amount) }
                        val left = Math.subtractExact(p.amount, actual).coerceAtLeast(0L)
                        PlanOccurrence(p.id, p.kind, p.title, due, m, p.amount, actual, left, matched.size,
                            when {
                                actual == 0L -> "EXPECTED"
                                actual < p.amount -> "PARTIAL"
                                actual == p.amount -> "PAID"
                                else -> "OVERPAID"
                            }, if (p.kind == "INCOME") m.minusMonths(1) else null)
                    }
                }.filterNotNull()
        }.sortedWith(compareBy<PlanOccurrence> { it.dueDate }.thenBy { it.planId }).toList()
    }

    fun validMonth(value: String): Boolean = runCatching {
        YearMonth.parse(value).toString() == value
    }.getOrDefault(false)

    /** 실제 입금일이 전후로 밀려도 연결된 예정월은 변하지 않는다. */
    fun actualFor(payments: List<PlanPayment>, planId: Long, month: YearMonth): Long =
        payments.filter { it.planId == planId && it.planMonth == month && it.status in setOf("CONFIRMED", "SETTLED") }
            .fold(0L) { sum, payment -> Math.addExact(sum, payment.amount) }
}
