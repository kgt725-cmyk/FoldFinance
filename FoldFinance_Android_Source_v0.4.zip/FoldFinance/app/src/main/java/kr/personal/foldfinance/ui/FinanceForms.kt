package kr.personal.foldfinance.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kr.personal.foldfinance.data.FinanceViewModel
import kr.personal.foldfinance.data.LedgerEntry
import kr.personal.foldfinance.data.CalendarEvent
import kr.personal.foldfinance.data.RecurringPlan
import java.time.YearMonth
import kr.personal.foldfinance.domain.*
import java.time.LocalDate

internal val incomeCats = listOf("급여", "상여금", "성과급", "부수입", "기타 수입")
internal val savingsCats = listOf("적금", "주식", "주택청약", "현금 저축")
internal val expenseCats = listOf("데이트", "개인 식비", "카페·커피", "교통", "쇼핑", "통신비", "구독 서비스", "생활용품", "취미·여가", "의료·건강", "고정지출", "기타", "미분류")

@Composable
internal fun Field(label: String, value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier, singleLine: Boolean = true) {
    OutlinedTextField(value = value, onValueChange = onValueChange, label = { Text(label) }, modifier = modifier.fillMaxWidth(), singleLine = singleLine)
}

@Composable
internal fun LedgerEditor(kind: String, events: List<CalendarEvent>, plans: List<RecurringPlan> = emptyList(), original: LedgerEntry? = null, onDismiss: () -> Unit, onSave: (LedgerEntry) -> Unit) {
    val initial = when(kind) { "INCOME" -> "급여"; "SAVING" -> "적금"; "KPASS_REBATE" -> "교통"; else -> "개인 식비" }
    var date by remember { mutableStateOf(original?.date ?: LocalDate.now().toString()) }
    var amount by remember { mutableStateOf(original?.amount?.toString() ?: "") }
    var cat by remember { mutableStateOf(original?.category ?: initial) }
    var merchant by remember { mutableStateOf(original?.merchant.orEmpty()) }
    var memo by remember { mutableStateOf(original?.memo.orEmpty()) }
    var tags by remember { mutableStateOf(original?.tags.orEmpty()) }
    var transactionTime by remember { mutableStateOf(original?.occurredAtTime.orEmpty()) }
    var linkedEvent by remember { mutableStateOf(original?.linkedEventId) }
    val eventCandidates = EventExpenseMatcher.candidates(date, transactionTime, merchant,
        events.map { EventWindow(it.id, it.date, it.title, it.start, it.end) })
    var workMonth by remember { mutableStateOf(original?.workMonth.orEmpty()) }
    var pending by remember { mutableStateOf(original?.status == "EXPECTED") }
    var approvedReview by remember { mutableStateOf(false) }
    var linkedPlanId by remember { mutableStateOf(original?.linkedRecurringId) }
    var linkedPlanMonth by remember { mutableStateOf(original?.linkedPlanMonth ?: YearMonth.from(tryDate(date) ?: LocalDate.now()).toString()) }
    var error by remember { mutableStateOf("") }
    val suggestions = when(kind) {
        "INCOME" -> incomeCats; "SAVING" -> savingsCats; "KPASS_REBATE" -> listOf("교통")
        else -> expenseCats
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if(original != null) "거래 수정" else "${when(kind) {"INCOME" -> "수입"; "SAVING" -> "저축"; "KPASS_REBATE" -> "K-패스 환급"; else -> "지출"}} 추가") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                if(original?.transitDate != null) Text("교통비 실제 이용일은 교통비 메뉴에서 관리합니다.", fontSize = 11.sp)
                Field("거래 날짜 · YYYY-MM-DD", date, { date = it; linkedEvent = null })
                Field("금액 · 원", amount, { amount = it })
                Field("카테고리 (직접 입력 가능)", cat, { cat = it })
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    suggestions.forEach { choice -> SuggestionChip(onClick = { cat = choice }, label = { Text(choice, fontSize = 11.sp) }) }
                }
                Field(if(kind == "INCOME") "입금처 / 설명" else "가맹점 / 설명", merchant, { merchant = it })
                if(kind == "INCOME") Field("귀속 근무월 · YYYY-MM (선택)", workMonth, { workMonth = it })
                if (kind == "EXPENSE") {
                    Field("실제 결제 시각 · HH:mm (선택)", transactionTime, { transactionTime = it; linkedEvent = null })
                    Text("알림 수신 시각은 실제 결제 시각과 다를 수 있으므로 자동 입력하지 않습니다.", fontSize = 11.sp)
                    if (eventCandidates.isNotEmpty()) {
                        Text("시간이 일치하는 일정 · 연결은 직접 선택", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        eventCandidates.forEach { candidate ->
                            OutlinedButton(onClick = {
                                linkedEvent = candidate.id
                                tags = EventExpenseMatcher.mergeTag(tags, candidate.suggestedTag)
                            }) {
                                Text("${if (linkedEvent == candidate.id) "✓ " else ""}${candidate.title}" +
                                    (candidate.suggestedTag?.let { "  #$it 추천" } ?: ""))
                            }
                        }
                        if (linkedEvent != null) TextButton(onClick = { linkedEvent = null }) { Text("일정 연결 해제") }
                    }
                    if (original?.linkedEventId != null && eventCandidates.none { it.id == original.linkedEventId }) {
                        Text("기존 일정 연결이 있습니다. 거래 시각을 수정하면 연결을 다시 선택해야 합니다.", fontSize = 11.sp)
                    }
                }
                if (kind == "INCOME" || kind == "EXPENSE") {
                    val eligible = plans.filter { it.kind == kind }
                    if (eligible.isNotEmpty()) {
                        Text("정기 급여·고정지출 계획에 연결 (선택)", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            FilterChip(selected = linkedPlanId == null, onClick = { linkedPlanId = null }, label = { Text("연결 없음") })
                            eligible.forEach { plan ->
                                FilterChip(selected = linkedPlanId == plan.id, onClick = {
                                    linkedPlanId = plan.id
                                    linkedPlanMonth = YearMonth.from(tryDate(date) ?: LocalDate.now()).toString()
                                }, label = { Text(plan.title) })
                            }
                        }
                        if (linkedPlanId != null) {
                            Field("연결할 예정월 (YYYY-MM)", linkedPlanMonth, { linkedPlanMonth = it })
                            Text("실제 결제일이 예정일과 달라도 해당 예정월에 연결합니다. 같은 거래를 또 입력하면 중복 집계되므로 주의하세요.", fontSize = 11.sp)
                        }
                    }
                }
                Field("메모", memo, { memo = it })
                Field("태그 (쉼표로 구분, 예: 데이트, 출퇴근)", tags, { tags = it })
                if (kind == "EXPENSE" && original?.status == "REVIEW") Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = approvedReview, onCheckedChange = { approvedReview = it })
                    Text("검토를 마치고 실제 지출로 확정")
                }
                if(kind == "INCOME") Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = pending, onCheckedChange = { pending = it }); Text("입금 예정 (실제 수입에서 제외)")
                }
                if (kind == "EXPENSE" && original == null) Text("환불은 금액 앞에 -를 입력해 지출에서 차감합니다.", style = MaterialTheme.typography.labelSmall)
                if(error.isNotBlank()) Text(error, color = Pink)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val n = parseWon(amount)
                val validTime = transactionTime.isBlank() || Regex("(?:[01]\\d|2[0-3]):[0-5]\\d").matches(transactionTime)
                val validWork = workMonth.isBlank() || Regex("\\d{4}-(0[1-9]|1[0-2])").matches(workMonth)
                if(tryDate(date) == null || n == null || n == 0L || (n < 0 && (kind != "EXPENSE" || original?.transitDate != null || linkedPlanId != null)) ||
                    cat.isBlank() || !validWork || !validTime || (linkedPlanId != null && (!RecurringMath.validMonth(linkedPlanMonth) ||
                    plans.none { it.id == linkedPlanId && it.kind == kind }))) {
                    error = "날짜·금액·카테고리 또는 귀속월을 확인하세요."
                } else {
                    val status = when {
                        kind == "INCOME" && pending -> "EXPECTED"
                        original?.status == "REVIEW" && kind == "EXPENSE" && !approvedReview -> "REVIEW"
                        else -> "CONFIRMED"
                    }
                    onSave((original ?: LedgerEntry(kind = kind, amount = n, date = date, category = cat)).copy(
                        date = original?.transitDate ?: date, amount = n, category = cat.trim(), merchant = merchant.trim(), memo = memo,
                        workMonth = workMonth.takeIf { it.isNotBlank() }, status = status,
                        occurredAtTime = transactionTime.takeIf { it.isNotBlank() },
                        linkedEventId = if (kind == "EXPENSE") linkedEvent else null,
                        linkedRecurringId = if (kind in listOf("INCOME", "EXPENSE")) linkedPlanId else null,
                        linkedPlanMonth = if (linkedPlanId != null) linkedPlanMonth else null,
                        tags = tags.split(",").map { it.trim().removePrefix("#") }.filter { it.isNotBlank() }.distinct().joinToString(",")
                    ))
                }
            }) { Text("저장") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } }
    )
}

@Composable
internal fun LedgerPage(kind: String, entries: List<LedgerEntry>, events: List<CalendarEvent>, plans: List<RecurringPlan>, model: FinanceViewModel) {
    var editing by remember { mutableStateOf<LedgerEntry?>(null) }
    var creating by remember { mutableStateOf(false) }
    var deletion by remember { mutableStateOf<LedgerEntry?>(null) }
    val displayed = entries.filter { it.kind == kind }
    val title = when(kind) { "INCOME" -> "수입"; "SAVING" -> "저축"; else -> "지출" }
    Column(Modifier.fillMaxSize().padding(horizontal = 15.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("${title} 내역 ${displayed.size}건", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Button(onClick = { creating = true }) { Text("+ ${title} 입력") }
        }
        Spacer(Modifier.height(9.dp))
        if(kind == "EXPENSE" && displayed.any { it.status == "REVIEW" }) {
            RoundedCard(Modifier.fillMaxWidth()) {
                Text("금융 알림에서 수집한 미확정 거래 ${displayed.count { it.status == "REVIEW" }}건", color = Pink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("가맹점·금액 확인 후 확정해 주세요. 미확정 거래는 통계에 포함하지 않습니다.", fontSize = 11.sp)
            }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(displayed, key = { it.id }) { entry ->
                RoundedCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(entry.merchant.ifBlank { entry.category }, fontWeight = FontWeight.SemiBold)
                            Text("${entry.date} · ${entry.category} · ${when(entry.status) {"REVIEW" -> "확인 필요"; "EXPECTED" -> "예정"; else -> "확정"}}", style = MaterialTheme.typography.labelSmall)
                            if(entry.tags.isNotBlank()) Text(entry.tags.split(",").joinToString(" ") { "#$it" }, fontSize = 11.sp, color = Green)
                        }
                        Text(formatWon(entry.amount), fontWeight = FontWeight.Bold,
                            color = if(kind == "SAVING") Green else if(kind == "EXPENSE") Pink else Blue)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        if(entry.status == "REVIEW" || entry.status == "EXPECTED") {
                            TextButton(onClick = { model.setStatus(entry, "CONFIRMED") }) { Text("확정") }
                        }
                        TextButton(onClick = { editing = entry }) { Text("수정") }
                        TextButton(onClick = { deletion = entry }) { Text("삭제") }
                    }
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
    if (creating) LedgerEditor(kind, events, plans, onDismiss = { creating = false }) { model.addEntry(it); creating = false }
    editing?.let { existing -> LedgerEditor(kind, events, plans, original = existing, onDismiss = { editing = null }) { model.updateEntry(it); editing = null } }
    deletion?.let { entry ->
        AlertDialog(onDismissRequest = { deletion = null }, title = { Text("거래를 삭제할까요?") }, text = { Text("삭제한 거래는 통계에서도 제외됩니다.") },
            confirmButton = { TextButton(onClick = { model.deleteEntry(entry.id); deletion = null }) { Text("삭제") } },
            dismissButton = { TextButton(onClick = { deletion = null }) { Text("취소") } })
    }
}

@Composable
internal fun KpassRebateButton(model: FinanceViewModel) {
    var show by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { show = true }) { Text("실제 K-패스 환급 입력") }
    if(show) LedgerEditor("KPASS_REBATE", emptyList(), onDismiss = { show = false }) { model.addEntry(it); show = false }
}
