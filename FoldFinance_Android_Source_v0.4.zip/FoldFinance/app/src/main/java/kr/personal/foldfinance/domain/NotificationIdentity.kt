package kr.personal.foldfinance.domain

import java.security.MessageDigest

/**
 * Notification instance fingerprint rather than a 3-minute time bucket.
 * Different real payments of the same amount at the same merchant in a short period
 * must not silently overwrite each other. Nearby duplicates are marked REVIEW separately.
 * No raw notification key or message content is persisted.
 */
object NotificationIdentity {
    fun fingerprint(
        packageName: String,
        notificationKey: String,
        postedAtMillis: Long,
        merchant: String,
        amount: Long
    ): String {
        require(packageName.isNotBlank() && notificationKey.isNotBlank() && merchant.isNotBlank())
        val input = listOf(packageName, notificationKey, postedAtMillis.toString(), merchant, amount.toString())
            .joinToString("\u001F")
        return MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}
