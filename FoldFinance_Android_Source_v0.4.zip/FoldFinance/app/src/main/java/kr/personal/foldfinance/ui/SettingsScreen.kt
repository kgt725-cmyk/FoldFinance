package kr.personal.foldfinance.ui

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kr.personal.foldfinance.data.FinanceSettings
import kr.personal.foldfinance.data.FinanceViewModel
import kr.personal.foldfinance.domain.parseWon
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
internal fun SettingsPage(initial: FinanceSettings, model: FinanceViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    var salary by remember(initial) { mutableStateOf(initial.salary.toString()) }
    var savings by remember(initial) { mutableStateOf(initial.savingsGoal.toString()) }
    var budget by remember(initial) { mutableStateOf(initial.budget.toString()) }
    var payday by remember(initial) { mutableStateOf(initial.payday.toString()) }
    var fare by remember(initial) { mutableStateOf(initial.oneWayFare.toString()) }
    var rides by remember(initial) { mutableStateOf(initial.ridesPerDay.toString()) }
    var weekmask by remember(initial) { mutableIntStateOf(initial.weekdayMask) }
    var kpass by remember(initial) { mutableStateOf(initial.kpassEnabled) }
    var privateWidget by remember(initial) { mutableStateOf(initial.widgetPrivate) }
    var packages by remember { mutableStateOf(model.getAllowedPackages()) }
    var restoreContent by remember { mutableStateOf<String?>(null) }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if(uri != null) scope.launch {
            runCatching {
                val content = model.exportBackup()
                context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
                    ?: error("파일을 열 수 없습니다.")
            }.onSuccess { snackbar.showSnackbar("백업 파일이 저장되었습니다.") }
             .onFailure { snackbar.showSnackbar("백업 실패: ${it.message}") }
        }
    }
    val exportCsv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if(uri != null) scope.launch {
            runCatching {
                val content = model.exportCsv()
                context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
                    ?: error("CSV 파일을 열 수 없습니다.")
            }.onSuccess { snackbar.showSnackbar("CSV 내보내기를 완료했습니다.") }
             .onFailure { snackbar.showSnackbar("CSV 내보내기 실패: ${it.message}") }
        }
    }
    val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if(uri != null) scope.launch {
            runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: error("백업 파일을 읽을 수 없습니다.")
            }.onSuccess { restoreContent = it }
             .onFailure { snackbar.showSnackbar("읽기 실패: ${it.message}") }
        }
    }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            RoundedCard(Modifier.fillMaxWidth()) {
                Text("기본 재무 설정", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Field("월 실수령 예상액", salary, { salary = it })
                Field("월 저축 목표", savings, { savings = it })
                Field("급여 주기 생활비 예산", budget, { budget = it })
                Field("매월 급여 기준일 (1~28)", payday, { payday = it })
                Text("익월 15일 지급: 입금일을 해당 주기의 시작일로 사용합니다. 귀속 근무월은 수입 등록 시 별도 기입합니다.", fontSize = 11.sp)
            }
            RoundedCard(Modifier.fillMaxWidth()) {
                Text("티머니 후불 교통비 예상 설정", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Field("편도 운임 (0원은 예상 계산 보류)", fare, { fare = it })
                Field("출근일 예상 탑승 횟수", rides, { rides = it })
                Text("출퇴근 요일", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf("월", "화", "수", "목", "금", "토", "일").forEachIndexed { index, day ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(day, fontSize = 11.sp)
                            Checkbox(
                                checked = (weekmask and (1 shl index)) != 0,
                                onCheckedChange = { yes -> weekmask = if(yes) weekmask or (1 shl index) else weekmask and (1 shl index).inv() }
                            )
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = kpass, onCheckedChange = { kpass = it })
                    Text("K-패스 사용 (실제 환급액 별도 입력)", modifier = Modifier.padding(start = 8.dp), fontSize = 12.sp)
                }
            }
            Button(onClick = {
                val a = parseWon(salary); val b = parseWon(savings); val c = parseWon(budget)
                val p = payday.toIntOrNull(); val f = parseWon(fare); val r = rides.toIntOrNull()
                if(a == null || b == null || c == null || p == null || f == null || r == null ||
                    a < 0 || b < 0 || c < 0 || f < 0 || p !in 1..28 || r !in 0..10) {
                    scope.launch { snackbar.showSnackbar("재무 및 교통비 설정을 확인하세요.") }
                } else {
                    model.saveSettings(FinanceSettings(a,b,c,p,f,r,weekmask,kpass,privateWidget))
                    scope.launch { snackbar.showSnackbar("설정을 저장했습니다.") }
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("재무·교통비 설정 저장") }
            RoundedCard(Modifier.fillMaxWidth()) {
                Text("금융 알림 수집 (선택)", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("알림 접근 권한이 켜져 있어도 아래 허용 앱 목록이 비어 있으면 수집하지 않습니다. 금융 앱 패키지명을 쉼표로 구분해 입력하세요. 알림 원문과 카드번호는 저장하지 않습니다.", fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Field("허용 앱 패키지명 (예: com.example.bank)", packages, { packages = it }, singleLine = false)
                Row {
                    OutlinedButton(onClick = { model.saveAllowedPackages(packages); scope.launch { snackbar.showSnackbar("허용 앱 목록을 저장했습니다.") } }) {
                        Text("목록 저장")
                    }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = {
                        runCatching { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
                            .onFailure { scope.launch { snackbar.showSnackbar("설정을 열지 못했습니다.") } }
                    }) { Text("알림 접근 설정") }
                }
                Text("중요: 금융 앱별 알림 형식에 따라 자동 추출되지 않을 수 있습니다. 수집된 거래도 검토 후 확정해야 실제 지출에 반영됩니다.", fontSize = 11.sp, color = Pink)
            }
            RoundedCard(Modifier.fillMaxWidth()) {
                Text("백업 및 개인정보", fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = privateWidget, onCheckedChange = { privateWidget = it })
                    Text("홈 화면 위젯 금액 숨기기 (위 설정 저장 필요)", fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
                }
                Text("백업은 암호화되지 않은 JSON입니다. 개인정보를 포함할 수 있으므로 안전한 장소에 보관하세요. 복원은 기존 데이터를 교체합니다.", fontSize = 12.sp, color = Pink)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { export.launch("foldfinance_${LocalDate.now()}.json") }) { Text("전체 백업") }
                    OutlinedButton(onClick = { restore.launch(arrayOf("application/json", "text/plain")) }) { Text("백업 복원") }
                }
                OutlinedButton(onClick = { exportCsv.launch("foldfinance_${LocalDate.now()}_거래.csv") }) { Text("거래내역 CSV 내보내기") }
            }
            Text("개인용 · 로그인 없음 · 인터넷 권한 없음 · SMS 읽기 권한 없음", fontSize = 11.sp)
            Spacer(Modifier.height(24.dp))
        }
        SnackbarHost(snackbar, modifier = Modifier.align(Alignment.BottomCenter))
    }
    restoreContent?.let { content ->
        AlertDialog(onDismissRequest = { restoreContent = null }, title = { Text("백업 복원을 진행할까요?") },
            text = { Text("현재 기록 전체를 교체합니다. 복원 전 전체 백업을 먼저 저장하세요. 입력 파일에 문제가 있으면 복원을 중지합니다.") },
            confirmButton = { TextButton(onClick = {
                restoreContent = null
                scope.launch { runCatching { model.importBackup(content) }
                    .onSuccess { snackbar.showSnackbar("백업을 복원했습니다.") }
                    .onFailure { snackbar.showSnackbar("복원 실패: ${it.message}") } }
            }) { Text("전체 교체") } },
            dismissButton = { TextButton(onClick = { restoreContent = null }) { Text("취소") } })
    }
}
