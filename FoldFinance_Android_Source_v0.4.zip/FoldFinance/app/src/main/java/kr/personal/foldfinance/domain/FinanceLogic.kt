package kr.personal.foldfinance.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

/** JVM에서도 동작하는 순수 계산 계층. 임의 표시용 금액을 생성하지 않는다. */
data class DateWindow(val start: LocalDate, val endExclusive: LocalDate) {
    init { require(endExclusive > start) }
    fun contains(date: LocalDate): Boolean = date >= start && date < endExclusive
    fun days(): Long = ChronoUnit.DAYS.between(start, endExclusive)
}

enum class WindowMode { PAYDAY, MONTH, YEAR }

object FinancePeriod {
    fun of(today: LocalDate, mode: WindowMode, payday: Int = 15, offset: Int = 0): DateWindow {
        require(payday in 1..28) { "급여 기준일은 1~28일 사이여야 합니다." }
        return when (mode) {
            WindowMode.PAYDAY -> {
                val thisMonth = today.withDayOfMonth(payday)
                val anchor = (if (today >= thisMonth) thisMonth else thisMonth.minusMonths(1)).plusMonths(offset.toLong())
                DateWindow(anchor, anchor.plusMonths(1))
            }
            WindowMode.MONTH -> {
                val first = today.withDayOfMonth(1).plusMonths(offset.toLong())
                DateWindow(first, first.plusMonths(1))
            }
            WindowMode.YEAR -> {
                val first = today.withDayOfYear(1).plusYears(offset.toLong())
                DateWindow(first, first.plusYears(1))
            }
        }
    }
}

/** 실제 입금 또는 확정 거래만 집계. 예상·검토 필요 데이터는 별개로 유지한다. */
data class FinancialEntry(
    val date: LocalDate,
    val kind: String,
    val amount: Long,
    val status: String = "CONFIRMED",
    val category: String = ""
)

data class Totals(val income: Long, val savings: Long, val expense: Long, val rebate: Long) {
    val remainingAfterSpending: Long get() = income - savings - expense + rebate
}

object FinanceMath {
    fun totals(entries: List<FinancialEntry>, window: DateWindow): Totals {
        val accepted = entries.filter { window.contains(it.date) && it.status in setOf("CONFIRMED", "SETTLED") }
        return Totals(
            accepted.filter { it.kind == "INCOME" }.sumOf { it.amount },
            accepted.filter { it.kind == "SAVING" }.sumOf { it.amount },
            accepted.filter { it.kind == "EXPENSE" }.sumOf { it.amount },
            accepted.filter { it.kind == "KPASS_REBATE" }.sumOf { it.amount }
        )
    }
    fun availableBudget(budget: Long, expense: Long, rollover: Long = 0): Long = budget + rollover - expense
    fun percent(actual: Long, goal: Long): Int = if (goal <= 0) 0 else ((actual.toDouble() / goal) * 100).toInt()
    fun remainingDays(today: LocalDate, window: DateWindow): Long =
        ChronoUnit.DAYS.between(today, window.endExclusive).coerceAtLeast(0)
    fun suggestedDailyBudget(budgetLeft: Long, daysLeft: Long): Long =
        if (daysLeft <= 0) 0 else budgetLeft.coerceAtLeast(0) / daysLeft
    fun annualSavingsProjection(saved: Long, monthlyGoal: Long, monthsRemaining: Int): Long =
        saved + monthlyGoal * monthsRemaining.coerceAtLeast(0)
}

/** 실제 탑승 확인 전에는 무조건 EXPECTED/NEEDS_REVIEW, 통계 지출에는 포함하지 않는다. */
data class TransitDay(
    val date: LocalDate,
    val planned: Long,
    val actual: Long?,
    val status: String
)

object TransportMath {
    /** weekdayMask: 월요일 bit 0 ... 일요일 bit 6 */
    fun projectedDays(
        window: DateWindow,
        weekdayMask: Int,
        oneWayFare: Long,
        ridesPerDay: Int,
        workdayOverrides: Map<LocalDate, Boolean>,
        confirmedAmounts: Map<LocalDate, Long>,
        referenceToday: LocalDate = LocalDate.now()
    ): List<TransitDay> {
        require(oneWayFare >= 0 && ridesPerDay in 0..10)
        return generateSequence(window.start) { it.plusDays(1) }
            .takeWhile { it < window.endExclusive }
            .map { date ->
                val mask = 1 shl (date.dayOfWeek.value - 1)
                val scheduled = workdayOverrides[date] ?: ((weekdayMask and mask) != 0)
                val estimated = if (scheduled) oneWayFare * ridesPerDay else 0
                val actual = confirmedAmounts[date]
                TransitDay(date, estimated, actual, if (actual != null) "CONFIRMED" else if (scheduled && date < referenceToday) "NEEDS_REVIEW" else if (scheduled) "EXPECTED" else "NOT_SCHEDULED")
            }.toList()
    }
    fun expectedUnconfirmed(days: List<TransitDay>): Long = days.filter { it.actual == null }.sumOf { it.planned }
    fun confirmedTotal(days: List<TransitDay>): Long = days.sumOf { it.actual ?: 0 }
    fun projectedTotal(days: List<TransitDay>): Long = confirmedTotal(days) + expectedUnconfirmed(days)
    fun netFare(confirmedFare: Long, actualKpassRefund: Long): Long = confirmedFare - actualKpassRefund
}

/** 개인 일정이 실제 시간대와 겹치는지만 판단. 동일 날짜만으로 자동 확정하지 않음. */
object ScheduleMatch {
    fun score(paymentMinute: Int, startMinute: Int, endMinute: Int, merchantSuggestsMeal: Boolean): Int {
        if (paymentMinute !in startMinute..endMinute) return 0
        return if (merchantSuggestsMeal) 65 else 35 // 중간 신뢰도; 사용자 확인 필요
    }
}

fun formatWon(value: Long): String = String.format(Locale.KOREA, "%,d원", value)
fun parseWon(raw: String): Long? = raw.replace(",", "").replace("원", "").trim().toLongOrNull()
fun tryDate(raw: String): LocalDate? = try { LocalDate.parse(raw.trim(), DateTimeFormatter.ISO_LOCAL_DATE) } catch (_: Exception) { null }
