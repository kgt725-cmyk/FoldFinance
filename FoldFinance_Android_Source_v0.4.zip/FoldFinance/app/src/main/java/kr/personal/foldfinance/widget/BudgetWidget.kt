package kr.personal.foldfinance.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import kr.personal.foldfinance.MainActivity
import kr.personal.foldfinance.R
import kr.personal.foldfinance.data.FinanceDatabase
import kr.personal.foldfinance.data.SettingsStore
import kr.personal.foldfinance.domain.FinanceMath
import kr.personal.foldfinance.domain.FinancePeriod
import kr.personal.foldfinance.domain.FinancialEntry
import kr.personal.foldfinance.domain.WindowMode
import kr.personal.foldfinance.domain.formatWon
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

class BudgetWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        updateAll(context)
    }
    companion object {
        fun updateAll(context: Context) {
            val app = context.applicationContext
            CoroutineScope(Dispatchers.IO).launch {
                val s = SettingsStore(app).current()
                val window = FinancePeriod.of(LocalDate.now(), WindowMode.PAYDAY, s.payday)
                val entries = FinanceDatabase.get(app).dao().allLedger()
                val totals = FinanceMath.totals(entries.map {
                    FinancialEntry(LocalDate.parse(it.date), it.kind, it.amount, it.status, it.category)
                }, window)
                val remaining = FinanceMath.availableBudget(s.budget, totals.expense)
                val manager = AppWidgetManager.getInstance(app)
                val ids = manager.getAppWidgetIds(ComponentName(app, BudgetWidget::class.java))
                ids.forEach { id ->
                    val views = RemoteViews(app.packageName, R.layout.widget_budget)
                    views.setTextViewText(R.id.widget_amount, if (s.widgetPrivate) "••••••" else formatWon(remaining))
                    views.setTextViewText(R.id.widget_subtitle, "${window.start} ~ ${window.endExclusive.minusDays(1)}")
                    val intent = Intent(app, MainActivity::class.java)
                    val pending = PendingIntent.getActivity(app, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                    views.setOnClickPendingIntent(R.id.widget_root, pending)
                    manager.updateAppWidget(id, views)
                }
            }
        }
    }
}
