package kr.personal.foldfinance.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kr.personal.foldfinance.data.*
import kr.personal.foldfinance.domain.*
import java.time.LocalDate

@Composable
private fun ActualTransitDialog(date: String, onClose: () -> Unit, onConfirm: (Long) -> Unit) {
    var actual by remember { mutableStateOf("") }
    var invalid by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onClose, title = { Text("$date 실제 교통비 확정") },
        text = { Column {
            Text("삼성월렛 → 교통카드 이용내역에서 실제 탑승·운임을 확인한 뒤, 해당 날짜의 실제 합계를 입력하세요.", fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            Field("실제 확인 금액 (원)", actual, { actual = it; invalid = false })
            if(invalid) Text("0원 이상 금액을 입력하세요.", color = Pink)
        } },
        confirmButton = { TextButton(onClick = {
            val n = parseWon(actual)
            if(n == null || n < 0) invalid = true else onConfirm(n)
        }) { Text("확정") } },
        dismissButton = { TextButton(onClick = onClose) { Text("취소") } })
}

@Composable
private fun BillDialog(onClose: () -> Unit, onSave: (TransitBill) -> Unit) {
    var from by remember { mutableStateOf(LocalDate.now().withDayOfMonth(1).toString()) }
    var to by remember { mutableStateOf(LocalDate.now().toString()) }
    var amount by remember { mutableStateOf("") }
    var bad by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onClose, title = { Text("후불 청구액 대조") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("카드사 청구정보는 참고·대조용으로만 저장하며, 소비로 다시 더하지 않습니다.", fontSize = 12.sp)
            Field("청구 이용기간 시작", from, { from = it })
            Field("청구 이용기간 종료", to, { to = it })
            Field("청구 총액", amount, { amount = it })
            if(bad) Text("기간 또는 금액을 확인하세요.", color = Pink)
        } },
        confirmButton = { TextButton(onClick = {
            val n = parseWon(amount)
            if(tryDate(from) == null || tryDate(to) == null || to < from || n == null || n < 0) bad = true
            else onSave(TransitBill(startDate = from, endDate = to, amount = n))
        }) { Text("저장") } }, dismissButton = { TextButton(onClick = onClose) { Text("취소") } })
}

@Composable
private fun StatementDialog(window: DateWindow, onClose: () -> Unit, onSave: (TransitStatement) -> Unit) {
    var from by rememberSaveable { mutableStateOf(window.start.toString()) }
    var to by rememberSaveable { mutableStateOf(window.endExclusive.minusDays(1).toString()) }
    var amount by rememberSaveable { mutableStateOf("") }
    var memo by rememberSaveable { mutableStateOf("") }
    var invalid by rememberSaveable { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onClose, title = { Text("이용기간 총액 기록") },
        text = { Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("티머니 이용기간의 전체 금액만 확인한 경우 사용하세요. 개별 날짜에 임의 배분하거나 지출에 더하지 않습니다.", fontSize = 12.sp)
            Field("실제 이용기간 시작 (YYYY-MM-DD)", from, { from = it; invalid = false })
            Field("실제 이용기간 종료 (YYYY-MM-DD)", to, { to = it; invalid = false })
            Field("확인한 이용기간 총액", amount, { amount = it; invalid = false })
            Field("메모 (선택)", memo, { memo = it })
            if (invalid) Text("날짜와 금액을 확인하세요.", color = Pink, fontSize = 12.sp)
        } },
        confirmButton = { TextButton(onClick = {
            val n = parseWon(amount)
            if (tryDate(from) == null || tryDate(to) == null || from > to || n == null || n < 0) invalid = true
            else onSave(TransitStatement(startDate = from, endDate = to, amount = n, memo = memo.trim()))
        }) { Text("총액 기록") } },
        dismissButton = { TextButton(onClick = onClose) { Text("취소") } })
}

@Composable
internal fun TransitPage(
    settings: FinanceSettings, ledger: List<LedgerEntry>, overrides: List<WorkdayOverride>, bills: List<TransitBill>, statements: List<TransitStatement>,
    window: DateWindow, model: FinanceViewModel
) {
    val actualAmounts = remember(ledger) { ledger.filter { it.transitDate != null && it.amount >= 0 && it.status in listOf("CONFIRMED", "SETTLED") }
        .mapNotNull { e -> tryDate(e.transitDate!!)?.let { it to e.amount } }.toMap() }
    val overrideMap = remember(overrides) { overrides.associate { LocalDate.parse(it.date) to it.isWorkday } }
    val days = remember(window, settings, actualAmounts, overrideMap) {
        TransportMath.projectedDays(window, settings.weekdayMask, settings.oneWayFare, settings.ridesPerDay, overrideMap, actualAmounts)
    }
    val confirmedFare = ledger.filter { it.kind == "EXPENSE" && it.category == "교통" && it.status in listOf("CONFIRMED", "SETTLED") && (tryDate(it.date)?.let(window::contains) == true) }.sumOf { it.amount }
    val rebates = ledger.filter { it.kind == "KPASS_REBATE" && it.status in listOf("CONFIRMED", "SETTLED") && (tryDate(it.date)?.let(window::contains) == true) }.sumOf { it.amount }
    val unconfirmedFare = TransportMath.expectedUnconfirmed(days)
    var activeDate by remember { mutableStateOf<String?>(null) }
    var showBill by remember { mutableStateOf(false) }
    var showStatement by remember { mutableStateOf(false) }
    var removingStatement by remember { mutableStateOf<TransitStatement?>(null) }
    val invalidTransitCount = ledger.count { it.transitDate != null && it.amount < 0 }
    val verifiedTransit = remember(ledger) {
        ledger.filter { it.kind == "EXPENSE" && it.transitDate != null && it.amount >= 0 && it.status in listOf("CONFIRMED", "SETTLED") }
            .mapNotNull { entry -> tryDate(entry.transitDate!!)?.let { ConfirmedTransitUse(it, entry.amount) } }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        RoundedCard(Modifier.fillMaxWidth()) {
            if(settings.oneWayFare == 0L) Text("설정 → 편도 운임을 입력해야 예상 교통비가 계산됩니다.", color = Pink, fontSize = 12.sp)
            Text("삼성월렛 티머니 · 후불", fontWeight = FontWeight.Bold)
            if (invalidTransitCount > 0) Text("일별 교통 원장에 음수 금액 ${invalidTransitCount}건이 있습니다. 금액 정정이 필요합니다.", color = Pink, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            Metric("확정 교통비 (전체 교통 카테고리)", formatWon(confirmedFare), Blue)
            Text("후불 티머니 일별 확정 ${formatWon(TransportMath.confirmedTotal(days))}", fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) { Text("미확정 예상", fontSize = 11.sp); Text(formatWon(unconfirmedFare), fontWeight = FontWeight.SemiBold, color = Pink) }
                Column(Modifier.weight(1f)) { Text("확정 + 예상", fontSize = 11.sp); Text(formatWon(confirmedFare + unconfirmedFare), fontWeight = FontWeight.SemiBold) }
            }
            Text("실제 운임이 확인되지 않은 날짜의 예상액은 지출 통계에 포함하지 않습니다.", fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            if(settings.kpassEnabled) Text("K-패스 실제 환급 ${formatWon(rebates)} · 환급 후 ${formatWon(confirmedFare - rebates)}", color = Green, fontSize = 12.sp)
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                OutlinedButton(onClick = { showStatement = true }, modifier = Modifier.fillMaxWidth()) { Text("이용기간 총액 입력", fontSize = 12.sp) }
                OutlinedButton(onClick = { showBill = true }, modifier = Modifier.fillMaxWidth()) { Text("후불 청구 기록", fontSize = 12.sp) }
                if(settings.kpassEnabled) KpassRebateButton(model)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("출퇴근 예상 및 실제 대조 · ${days.count { it.status == "EXPECTED" || it.status == "NEEDS_REVIEW" }}일 미확정", fontSize = 12.sp)
        Spacer(Modifier.height(7.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(days.filter { it.planned > 0 || it.actual != null || overrideMap.containsKey(it.date) }, key = { it.date.toString() }) { d ->
                val override = overrideMap[d.date]
                RoundedCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${d.date} (${listOf("월","화","수","목","금","토","일")[d.date.dayOfWeek.value-1]})", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            Text(if(d.actual != null) "확정 · ${formatWon(d.actual)}" else if(d.date < LocalDate.now()) "확인 필요 · ${formatWon(d.planned)} (예상)" else "미확정 예상 · ${formatWon(d.planned)}", color = if(d.actual != null) Green else Pink, fontSize = 11.sp)
                        }
                        TextButton(onClick = { activeDate = d.date.toString() }) { Text(if(d.actual == null) "실제 확인" else "금액 수정", fontSize = 11.sp) }
                    }
                    if (d.actual == null) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("일정 변경", fontSize = 10.sp)
                        TextButton(onClick = { model.overrideDay(d.date.toString(), false) }) { Text("휴무", fontSize = 11.sp) }
                        TextButton(onClick = { model.overrideDay(d.date.toString(), true) }) { Text("출근", fontSize = 11.sp) }
                        if(override != null) TextButton(onClick = { model.overrideDay(d.date.toString(), null) }) { Text("원복", fontSize = 11.sp) }
                    }
                }
            }
            item {
                RoundedCard(Modifier.fillMaxWidth()) {
                    Text("티머니 기간 총액 대조", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("기간 총액은 확정 일별 지출과 별도로 보관합니다. 대조 결과가 0원이어도 날짜별 기록을 확인해야 합니다.", fontSize = 11.sp)
                    if(statements.isEmpty()) Text("등록된 기간 정산 기록이 없습니다.", fontSize = 11.sp)
                    statements.forEach { statement ->
                        val result = TransitReconcile.compare(
                            LocalDate.parse(statement.startDate), LocalDate.parse(statement.endDate), statement.amount, verifiedTransit)
                        Column(Modifier.padding(vertical = 6.dp)) {
                            Text("${statement.startDate} ~ ${statement.endDate}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            Text("확인 총액 ${formatWon(result.reportedAmount)} · 일별 확정 ${formatWon(result.knownDatedAmount)} (${result.datedDays}일)", fontSize = 11.sp)
                            Text(if(result.amountMatches) "금액 일치 · 날짜별 누락 여부는 직접 확인" else "미대조 차이 ${formatWon(result.difference)} · 일자별 확인 필요",
                                fontSize = 11.sp, color = if(result.amountMatches) Green else Pink)
                            if(statement.memo.isNotBlank()) Text(statement.memo, fontSize = 11.sp)
                            TextButton(onClick = { removingStatement = statement }) { Text("기록 삭제", fontSize = 11.sp) }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                RoundedCard(Modifier.fillMaxWidth()) {
                    Text("등록된 후불 청구내역", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    if(bills.isEmpty()) Text("청구내역 미등록", fontSize = 11.sp)
                    bills.take(10).forEach { bill ->
                        val result = TransitReconcile.compare(LocalDate.parse(bill.startDate), LocalDate.parse(bill.endDate), bill.amount, verifiedTransit)
                        Text("${bill.startDate}~${bill.endDate} · 청구 ${formatWon(bill.amount)} · 확인 차이 ${formatWon(result.difference)} (합계 미포함)", fontSize = 11.sp)
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
    activeDate?.let { date -> ActualTransitDialog(date, { activeDate = null }) { model.confirmTransitDay(date, it); activeDate = null } }
    if (showBill) BillDialog({ showBill = false }) { model.addBill(it); showBill = false }
    if (showStatement) StatementDialog(window, { showStatement = false }) { model.addStatement(it); showStatement = false }
    removingStatement?.let { statement ->
        AlertDialog(onDismissRequest = { removingStatement = null }, title = { Text("기간 총액 기록 삭제") },
            text = { Text("대조용 총액 기록만 삭제합니다. 확정된 날짜별 교통 지출은 보존됩니다.") },
            confirmButton = { TextButton(onClick = { model.deleteStatement(statement.id); removingStatement = null }) { Text("삭제") } },
            dismissButton = { TextButton(onClick = { removingStatement = null }) { Text("취소") } })
    }
}
