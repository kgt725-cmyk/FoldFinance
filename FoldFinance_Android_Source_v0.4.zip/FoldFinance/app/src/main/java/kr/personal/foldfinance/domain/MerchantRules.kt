package kr.personal.foldfinance.domain

import java.util.Locale

/** 가맹점명 정확 일치만 자동 분류. 부분 문자열로 인한 다른 업종 오분류를 방지한다. */
data class MerchantCategorySuggestion(
    val category: String,
    val tags: String,
    val autoConfirm: Boolean
)

object MerchantCategorizer {
    fun key(name: String): String = name.trim().replace(Regex("\\s+"), " ").lowercase(Locale.ROOT)
    fun suggest(merchant: String, rules: Map<String, MerchantCategorySuggestion>): MerchantCategorySuggestion? =
        rules[key(merchant)]?.takeIf { it.category.isNotBlank() }
    /** 명시적으로 활성화한 규칙, 승인 거래, 근접 중복이 없는 경우에만 자동 확정. */
    fun status(suggestion: MerchantCategorySuggestion?, isPurchase: Boolean, nearDuplicate: Boolean): String =
        if (suggestion?.autoConfirm == true && isPurchase && !nearDuplicate) "CONFIRMED" else "REVIEW"
}
