package kr.personal.foldfinance.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.collectLatest
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kr.personal.foldfinance.data.*
import kr.personal.foldfinance.domain.*
import java.time.LocalDate

internal val Navy = Color(0xFF16243C)
internal val Blue = Color(0xFF3478EB)
internal val Green = Color(0xFF259B79)
internal val Pink = Color(0xFFE96B86)
internal val LightBg = Color(0xFFF6F8FC)

private val financeColors = lightColorScheme(
    primary = Blue, background = LightBg, surface = Color.White, onSurface = Navy,
    secondary = Green, outline = Color(0xFFDCE3EE)
)

private val pages = listOf("홈", "수입", "저축", "지출", "캘린더", "교통비", "정기 관리", "분류 규칙", "통계", "설정")

@Composable
fun FinanceApp(model: FinanceViewModel, modifier: Modifier = Modifier) {
    val ledger by model.entries.collectAsStateWithLifecycle(initialValue = emptyList())
    val events by model.events.collectAsStateWithLifecycle(initialValue = emptyList())
    val overrides by model.overrides.collectAsStateWithLifecycle(initialValue = emptyList())
    val bills by model.bills.collectAsStateWithLifecycle(initialValue = emptyList())
    val statements by model.statements.collectAsStateWithLifecycle(initialValue = emptyList())
    val rules by model.rules.collectAsStateWithLifecycle(initialValue = emptyList())
    val plans by model.plans.collectAsStateWithLifecycle(initialValue = emptyList())
    val settings by model.settings.collectAsStateWithLifecycle(initialValue = FinanceSettings())
    var page by rememberSaveable { mutableStateOf("홈") }
    var modeName by rememberSaveable { mutableStateOf(WindowMode.PAYDAY.name) }
    var offset by rememberSaveable { mutableIntStateOf(0) }
    val today = LocalDate.now()
    val mode = WindowMode.valueOf(modeName)
    val window = FinancePeriod.of(today, mode, settings.payday, offset)
    val totals = remember(ledger, window) {
        FinanceMath.totals(ledger.map { FinancialEntry(LocalDate.parse(it.date), it.kind, it.amount, it.status, it.category) }, window)
    }
    val openPage: (String) -> Unit = { page = it }
    MaterialTheme(colorScheme = financeColors, typography = Typography()) {
        BoxWithConstraints(modifier.background(LightBg)) {
            val wide = maxWidth >= 600.dp
            if (wide) {
                Row(Modifier.fillMaxSize()) {
                    Surface(shadowElevation = 2.dp, color = Color.White, modifier = Modifier.width(186.dp).fillMaxHeight()) {
                        Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
                            Text("내 자산", Modifier.padding(14.dp), fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
                            Spacer(Modifier.height(12.dp))
                            pages.forEach { name ->
                                NavigationDrawerItem(
                                    label = { Text(name) }, selected = page == name, onClick = { page = name },
                                    modifier = Modifier.padding(vertical = 3.dp), shape = RoundedCornerShape(14.dp)
                                )
                            }
                        }
                    }
                    Column(Modifier.weight(1f)) {
                        TopHeader(page)
                        PeriodControl(mode, offset, window,
                            onMode = { modeName = it.name; offset = 0 }, onOffset = { offset += it })
                        Box(Modifier.fillMaxSize()) {
                            PageContent(page, model, settings, ledger, events, overrides, bills, statements, rules, plans, window, totals, wide, openPage)
                        }
                    }
                }
            } else {
                Scaffold(
                    containerColor = LightBg,
                    topBar = {
                        Column {
                            TopHeader(page)
                            PeriodControl(mode, offset, window, onMode = { modeName = it.name; offset = 0 }, onOffset = { offset += it })
                        }
                    },
                    bottomBar = {
                        NavigationBar(containerColor = Color.White, tonalElevation = 4.dp) {
                            listOf("홈", "저축", "지출", "캘린더", "더보기").forEach { p ->
                                NavigationBarItem(
                                    selected = if (p == "더보기") page !in listOf("홈", "저축", "지출", "캘린더") else page == p,
                                    onClick = { page = p },
                                    icon = { Text(when(p){ "홈" -> "⌂"; "저축" -> "▣"; "지출" -> "↗"; "캘린더" -> "▦"; else -> "☷" }, fontSize = 19.sp) },
                                    label = { Text(p, fontSize = 10.sp) }, alwaysShowLabel = true
                                )
                            }
                        }
                    }
                ) { padding ->
                    Box(Modifier.fillMaxSize().padding(padding)) {
                        PageContent(page, model, settings, ledger, events, overrides, bills, statements, rules, plans, window, totals, wide, openPage)
                    }
                }
            }
        }
    }
}

@Composable
private fun TopHeader(page: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(page, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.weight(1f))
        Text("오프라인 · 개인용", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
    }
}

@Composable
private fun PeriodControl(mode: WindowMode, offset: Int, window: DateWindow, onMode: (WindowMode) -> Unit, onOffset: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf(WindowMode.PAYDAY to "급여 주기", WindowMode.MONTH to "월별", WindowMode.YEAR to "연간").forEach { (item, title) ->
                FilterChip(selected = mode == item, onClick = { onMode(item) }, label = { Text(title, fontSize = 11.sp) })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { onOffset(-1) }) { Text("◀") }
            Text("${window.start} ~ ${window.endExclusive.minusDays(1)}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            TextButton(onClick = { onOffset(1) }) { Text("▶") }
            if (offset != 0) TextButton(onClick = { onOffset(-offset) }) { Text("오늘") }
        }
    }
}

@Composable
private fun PageContent(
    page: String, model: FinanceViewModel, settings: FinanceSettings,
    ledger: List<LedgerEntry>, events: List<CalendarEvent>, overrides: List<WorkdayOverride>, bills: List<TransitBill>,
    statements: List<TransitStatement>, rules: List<MerchantRule>, plans: List<RecurringPlan>, window: DateWindow, totals: Totals, wide: Boolean, openPage: (String) -> Unit
) {
    when (page) {
        "홈" -> HomePage(settings, ledger, events, window, totals, wide, openPage)
        "수입" -> LedgerPage("INCOME", ledger, events, plans, model)
        "저축" -> LedgerPage("SAVING", ledger, events, plans, model)
        "지출" -> LedgerPage("EXPENSE", ledger, events, plans, model)
        "캘린더" -> CalendarPage(events, ledger, model, wide)
        "분류 규칙" -> MerchantRulesPage(rules, model)
        "교통비" -> TransitPage(settings, ledger, overrides, bills, statements, window, model)
        "정기 관리" -> RecurringPage(settings, plans, ledger, window, model, openPage)
        "통계" -> StatsPage(ledger, totals, settings, window, openPage)
        "설정" -> SettingsPage(settings, model)
        else -> MorePage(openPage)
    }
}

@Composable
internal fun RoundedCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(18.dp), content = content)
    }
}

@Composable
internal fun Metric(label: String, value: String, color: Color = Navy, sub: String = "") {
    Text(label, fontSize = 12.sp, color = Color(0xFF718096))
    Spacer(Modifier.height(4.dp))
    Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = color)
    if (sub.isNotBlank()) Text(sub, fontSize = 11.sp, color = Color.Gray)
}

@Composable
private fun HomePage(s: FinanceSettings, ledger: List<LedgerEntry>, events: List<CalendarEvent>, w: DateWindow, t: Totals, wide: Boolean, open: (String) -> Unit) {
    val leftBudget = FinanceMath.availableBudget(s.budget, t.expense)
    val usedPct = FinanceMath.percent(t.expense, s.budget).coerceIn(0, 100)
    val futureDays = FinanceMath.remainingDays(LocalDate.now(), w)
    val recent = ledger.filter { tryDate(it.date)?.let(w::contains) == true }.take(5)
    val main: @Composable ColumnScope.() -> Unit = {
        RoundedCard(Modifier.fillMaxWidth()) {
            Metric("이번 기간 남은 생활비", formatWon(leftBudget), if (leftBudget >= 0) Navy else Pink,
                "예산 ${formatWon(s.budget)} · 확정 소비 ${formatWon(t.expense)} · K-패스 환급 별도")
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(progress = { usedPct / 100f }, modifier = Modifier.fillMaxWidth().height(9.dp), color = Pink, trackColor = LightBg)
            Spacer(Modifier.height(9.dp))
            Row { Text("예산 사용률 $usedPct%", fontSize = 12.sp); Spacer(Modifier.weight(1f)); Text("남은 $futureDays 일", fontSize = 12.sp) }
        }
        Spacer(Modifier.height(12.dp))
        RoundedCard(Modifier.fillMaxWidth()) {
            Metric("실제 수입", formatWon(t.income), Blue)
            Spacer(Modifier.height(14.dp))
            Metric("이번 기간 납입 저축", formatWon(t.savings), Green,
                "목표 ${formatWon(s.savingsGoal)} · 달성률 ${FinanceMath.percent(t.savings, s.savingsGoal)}%")
            Spacer(Modifier.height(11.dp))
            LinearProgressIndicator(progress = { (t.savings.toFloat() / s.savingsGoal.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f) }, color = Green, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(12.dp))
        RoundedCard(Modifier.fillMaxWidth()) {
            Metric("하루 권장 사용 가능 금액", formatWon(FinanceMath.suggestedDailyBudget(leftBudget, futureDays)), Navy)
        }
    }
    val right: @Composable ColumnScope.() -> Unit = {
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("가까운 일정", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            val upcoming = events.filter { it.date >= LocalDate.now().toString() }.take(3)
            if (upcoming.isEmpty()) Text("등록된 일정이 없습니다.", color = Color.Gray)
            upcoming.forEach { Text("${it.date}  ${it.start} · ${it.title}", fontSize = 13.sp, modifier = Modifier.padding(vertical = 5.dp)) }
            TextButton(onClick = { open("캘린더") }) { Text("캘린더 열기 →") }
        }
        Spacer(Modifier.height(12.dp))
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("최근 거래", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            if (recent.isEmpty()) Text("아직 기록이 없습니다.", color = Color.Gray)
            recent.forEach {
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(it.merchant.ifBlank { it.category }, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${it.date} · ${if (it.status == "REVIEW") "검토 필요" else it.category}", fontSize = 11.sp, color = Color.Gray)
                    }
                    Text(formatWon(it.amount), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                }
            }
            TextButton(onClick = { open("지출") }) { Text("지출 확인 →") }
        }
        Spacer(Modifier.height(12.dp))
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("검토 필요 거래", fontSize = 12.sp, color = Color.Gray)
            Text("${ledger.count { it.status == "REVIEW" }}건", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Pink)
        }
    }
    if (wide) {
        Row(Modifier.fillMaxSize().padding(horizontal = 16.dp).verticalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(Modifier.weight(1f), content = main)
            Column(Modifier.weight(1f), content = right)
        }
    } else {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp)) {
            main(); Spacer(Modifier.height(12.dp)); right()
        }
    }
}

@Composable
private fun MorePage(open: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("모든 메뉴", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        listOf("수입", "교통비", "정기 관리", "분류 규칙", "통계", "설정").forEach { page ->
            RoundedCard(Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable { open(page) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(page, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Text("›", fontSize = 25.sp, color = Blue)
                }
            }
        }
    }
}
