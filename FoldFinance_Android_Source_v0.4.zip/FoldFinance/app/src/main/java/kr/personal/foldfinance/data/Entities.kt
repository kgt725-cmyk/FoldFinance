package kr.personal.foldfinance.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** amount: 원 단위 Long, 소비 취소/환불에 한하여 EXPENSE 음수 가능. */
@Entity(tableName = "ledger", indices = [Index(value = ["dedupeKey"], unique = true), Index(value = ["transitDate"], unique = true)])
data class LedgerEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String, // INCOME / SAVING / EXPENSE / KPASS_REBATE
    val amount: Long,
    val date: String, // yyyy-MM-dd, 거래 발생일
    val category: String,
    val merchant: String = "",
    val memo: String = "",
    val status: String = "CONFIRMED", // EXPECTED / REVIEW / CONFIRMED / SETTLED
    val source: String = "MANUAL",
    val dedupeKey: String? = null,
    val transitDate: String? = null,
    val workMonth: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val tags: String = "", // 쉼표로 구분; 집계 시 금액은 거래 단위로 한 번만 합산
    val occurredAtTime: String? = null, // HH:mm, 사용자가 확인한 실제 거래 시각만 저장
    val linkedEventId: Long? = null, // 확정된 개인 일정과의 연결
    val linkedRecurringId: Long? = null, // 정기 계획에 연결할 경우 금액을 다시 합산하지 않음
    val linkedPlanMonth: String? = null // yyyy-MM; 휴일 등으로 실제 결제 날짜가 달라져도 계획월은 보존
)

@Entity(tableName = "events")
data class CalendarEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val title: String,
    val start: String = "09:00",
    val end: String = "18:00",
    val note: String = "",
    val budget: Long = 0
)

@Entity(tableName = "workday_overrides")
data class WorkdayOverride(
    @PrimaryKey val date: String,
    val isWorkday: Boolean
)

/** 후불 카드 청구 내역은 원천 지출이 아니다. 중복 지출 방지를 위해 ledger와 분리. */
@Entity(tableName = "transit_bills")
data class TransitBill(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startDate: String,
    val endDate: String,
    val amount: Long,
    val memo: String = ""
)


/** 실제 일자별 내역을 확인하기 전, 이용 기간 총액만 보관하는 대조용 자료. 원장에 합산하지 않는다. */
@Entity(tableName = "transit_statements")
data class TransitStatement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startDate: String,
    val endDate: String,
    val amount: Long,
    val memo: String = ""
)

/** 가맹점 exact-match 개인 분류 규칙. 삭제해도 기존 원장 기록은 변경되지 않는다. */
@Entity(tableName = "merchant_rules")
data class MerchantRule(
    @PrimaryKey val merchantKey: String,
    val category: String,
    val tags: String = "",
    val autoConfirm: Boolean = false
)

/** 원장과 별도로 관리되는 월간 반복 계획. 매월 가상 예정 내역만 생성하며 실거래로 집계하지 않는다. */
@Entity(tableName = "recurring_plans")
data class RecurringPlan(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String, // INCOME / EXPENSE
    val title: String,
    val amount: Long,
    val category: String,
    val dayOfMonth: Int,
    val startMonth: String, // yyyy-MM
    val active: Boolean = true,
    val memo: String = ""
)
