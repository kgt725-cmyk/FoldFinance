package kr.personal.foldfinance.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kr.personal.foldfinance.data.*
import kr.personal.foldfinance.domain.*
import java.time.LocalDate
import java.time.YearMonth

@Composable
private fun PlanCreateDialog(settings: FinanceSettings, close: () -> Unit, save: (RecurringPlan) -> Unit) {
    var kind by rememberSaveable { mutableStateOf("EXPENSE") }
    var title by rememberSaveable { mutableStateOf("") }
    var amount by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("고정지출") }
    var day by rememberSaveable { mutableStateOf("20") }
    var startMonth by rememberSaveable { mutableStateOf(YearMonth.now().toString()) }
    var memo by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf("") }
    AlertDialog(onDismissRequest = close, title = { Text("매월 반복 계획") },
        text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("예정액은 실제 수입이나 지출에 합산되지 않습니다. 사용자가 실제 거래를 확인해야 반영됩니다.", fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(kind == "INCOME", onClick = {
                        kind = "INCOME"; title = "급여"; category = "급여"
                        amount = settings.salary.toString(); day = settings.payday.toString()
                    }, label = { Text("정기 수입") })
                    FilterChip(kind == "EXPENSE", onClick = {
                        kind = "EXPENSE"; if (title == "급여") title = ""
                        category = "고정지출"; amount = ""; day = "20"
                    }, label = { Text("고정지출") })
                }
                Field("계획 명칭", title, { title = it })
                Field("예정 금액 (원)", amount, { amount = it })
                Field("카테고리", category, { category = it })
                Field("매월 예정일 (1~28일)", day, { day = it })
                Field("시작 월 (YYYY-MM)", startMonth, { startMonth = it })
                Field("메모 (선택)", memo, { memo = it })
                if (kind == "INCOME") Text("급여는 예정일의 전월 근무분으로 표시하며, 실제 입금일은 개별 기록합니다.", fontSize = 11.sp)
                if (error.isNotEmpty()) Text(error, color = Pink, fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(onClick = {
            val a = parseWon(amount)
            val d = day.toIntOrNull()
            if (title.isBlank() || category.isBlank() || a == null || a <= 0 || d == null || d !in 1..28 || !RecurringMath.validMonth(startMonth)) {
                error = "명칭, 금액, 예정일(1~28), 시작 월을 확인하세요."
            } else save(RecurringPlan(kind = kind, title = title.trim(), amount = a,
                category = category.trim(), dayOfMonth = d, startMonth = startMonth,
                memo = memo.trim()))
        }) { Text("계획 저장") } },
        dismissButton = { TextButton(onClick = close) { Text("취소") } }
    )
}

@Composable
private fun ConfirmPlanDialog(plan: RecurringPlan, occurrence: PlanOccurrence, close: () -> Unit, save: (LedgerEntry) -> Unit) {
    var actualDate by rememberSaveable { mutableStateOf(occurrence.dueDate.toString()) }
    var amount by rememberSaveable { mutableStateOf(occurrence.pendingAmount.takeIf { it > 0 }?.toString() ?: occurrence.plannedAmount.toString()) }
    var memo by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf("") }
    AlertDialog(onDismissRequest = close, title = { Text("실제 ${if (plan.kind == "INCOME") "입금" else "결제"} 확인") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${plan.title} · ${occurrence.planMonth} 예정분", fontWeight = FontWeight.Bold)
            Text("이미 원장에 등록된 알림 거래가 있다면 새 거래를 추가하지 말고 해당 거래의 '정기 계획 연결'을 사용하세요. 중복 결제를 방지합니다.", fontSize = 12.sp, color = Pink)
            if (occurrence.paymentCount > 0) Text("기존 확정 거래 ${occurrence.paymentCount}건 / ${formatWon(occurrence.actualAmount)}. 추가 입금이나 결제가 맞는지 확인하세요.", fontSize = 12.sp)
            Field("실제 ${if(plan.kind=="INCOME") "입금" else "결제"}일", actualDate, { actualDate = it })
            Field("실제 금액", amount, { amount = it })
            Field("메모", memo, { memo = it })
            if (error.isNotEmpty()) Text(error, color = Pink, fontSize = 12.sp)
        } },
        confirmButton = { TextButton(onClick = {
            val a = parseWon(amount)
            if (tryDate(actualDate) == null || a == null || a <= 0) error = "날짜와 실제 금액을 확인하세요."
            else save(LedgerEntry(kind = plan.kind, amount = a, date = actualDate,
                category = plan.category, merchant = plan.title, memo = memo.trim(),
                status = "CONFIRMED", source = "MANUAL_RECURRING",
                // 동일 날짜·금액·계획에 대한 빠른 중복 저장 방지. 별도의 실제 분할 입금은 수입/지출 화면에서 입력 가능.
                dedupeKey = "manual_recurring_${plan.id}_${occurrence.planMonth}_${actualDate}_${a}",
                workMonth = occurrence.incomeWorkMonth?.toString(),
                linkedRecurringId = plan.id, linkedPlanMonth = occurrence.planMonth.toString()))
        }) { Text("확정 거래 입력") } },
        dismissButton = { TextButton(onClick = close) { Text("취소") } })
}

@Composable
internal fun RecurringPage(settings: FinanceSettings, plans: List<RecurringPlan>, ledger: List<LedgerEntry>,
    window: DateWindow, model: FinanceViewModel, openPage: (String) -> Unit) {
    val validPayments = ledger.mapNotNull { entry ->
        val id = entry.linkedRecurringId ?: return@mapNotNull null
        val month = entry.linkedPlanMonth?.takeIf { RecurringMath.validMonth(it) } ?: return@mapNotNull null
        if (entry.amount <= 0L || entry.kind !in listOf("INCOME", "EXPENSE")) return@mapNotNull null
        PlanPayment(id, YearMonth.parse(month), entry.kind, entry.amount, entry.status, LocalDate.parse(entry.date))
    }.filter { e -> plans.any { it.id == e.planId && it.kind == e.kind } }
    val occurrences = RecurringMath.occurrences(plans.map {
        MonthlyPlan(it.id, it.kind, it.title, it.amount, it.dayOfMonth, YearMonth.parse(it.startMonth), it.active)
    }, validPayments, window)
    var creating by rememberSaveable { mutableStateOf(false) }
    var confirming by remember { mutableStateOf<PlanOccurrence?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("매월 반복 예정 내역", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Text("급여와 고정지출을 매월 자동으로 미리 표시합니다. 예정액은 실적에서 제외하며, 실제 거래가 확인되어야 집계합니다.", fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { creating = true }) { Text("+ 정기 계획 추가") }
            if (plans.isEmpty()) Text("처음에는 '정기 수입'을 선택해 15일 급여 계획을 등록하세요. 기본 급여액은 자동 제안됩니다.", fontSize = 12.sp)
        }
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("현재 조회 기간의 예정·확정", fontWeight = FontWeight.Bold)
            if (occurrences.isEmpty()) Text("해당 기간에 반복 예정 항목이 없습니다.", fontSize = 12.sp)
            occurrences.forEach { occurrence ->
                val plan = plans.first { it.id == occurrence.planId }
                HorizontalDivider(Modifier.padding(vertical = 9.dp))
                Text("${occurrence.dueDate} · ${plan.title}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("예정 ${formatWon(occurrence.plannedAmount)} / 실제 ${formatWon(occurrence.actualAmount)}", fontSize = 12.sp)
                Text(when (occurrence.status) {
                    "PAID" -> "예정 금액 충족"
                    "PARTIAL" -> "일부 확인 · 미확인 ${formatWon(occurrence.pendingAmount)}"
                    "OVERPAID" -> "예정액 초과 · 실제 거래 재확인"
                    else -> "미확정 예정 (실적 미포함)"
                }, color = if (occurrence.status == "PAID") Green else Pink, fontSize = 11.sp)
                if (occurrence.incomeWorkMonth != null) Text("근무 귀속월 ${occurrence.incomeWorkMonth}", fontSize = 11.sp)
                if (occurrence.status != "PAID") {
                    TextButton(onClick = { confirming = occurrence }) { Text("실제 거래 직접 확인") }
                }
            }
        }
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("등록된 반복 계획", fontWeight = FontWeight.Bold)
            plans.forEach { p ->
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${p.title} · 매월 ${p.dayOfMonth}일", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Text("${formatWon(p.amount)} · ${p.startMonth}부터 · ${if (p.active) "사용 중" else "일시 중단"}", fontSize = 11.sp)
                    }
                    TextButton(onClick = { model.setPlanActive(p.id, !p.active) }) { Text(if (p.active) "중단" else "재개") }
                }
            }
            Text("계획을 중단해도 과거 수입·지출 기록은 삭제되지 않습니다.", fontSize = 11.sp)
        }
        OutlinedButton(onClick = { openPage("수입") }) { Text("실제 수입 내역 열기") }
        OutlinedButton(onClick = { openPage("지출") }) { Text("실제 지출 내역 열기") }
    }
    if (creating) PlanCreateDialog(settings, close = { creating = false }) { model.addPlan(it); creating = false }
    confirming?.let { occurrence ->
        plans.firstOrNull { it.id == occurrence.planId }?.let { plan ->
            ConfirmPlanDialog(plan, occurrence, close = { confirming = null }) {
                model.addEntry(it)
                confirming = null
            }
        }
    }
}
