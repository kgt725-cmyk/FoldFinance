package kr.personal.foldfinance.notification

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kr.personal.foldfinance.data.BankPackageAllowlist
import kr.personal.foldfinance.data.FinanceDatabase
import kr.personal.foldfinance.data.LedgerEntry
import kr.personal.foldfinance.domain.BankNoticeParser
import kr.personal.foldfinance.domain.MerchantCategorizer
import kr.personal.foldfinance.domain.NotificationIdentity
import kr.personal.foldfinance.domain.MerchantCategorySuggestion
import kr.personal.foldfinance.widget.BudgetWidget
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId

/** 명시적으로 허용한 앱의 알림만 검사하고, 추출된 최소 거래 필드만 DB에 저장한다. */
class FinanceNotificationListener : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName !in BankPackageAllowlist.get(this)) return
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val content = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val parsed = BankNoticeParser.parse("$title\n$content") ?: return
        val date = Instant.ofEpochMilli(sbn.postTime).atZone(ZoneId.systemDefault()).toLocalDate().toString()
        // 같은 가맹점·동일 금액의 독립 결제가 3분 이내에 발생해도 기록을 유실하지 않음.
        // 실제 중복 의심은 아래 nearDuplicate 검사로 별도로 REVIEW 처리.
        val key = NotificationIdentity.fingerprint(
            sbn.packageName, sbn.key, sbn.postTime, parsed.merchant, parsed.amount
        )
        scope.launch {
            val dao = FinanceDatabase.get(applicationContext).dao()
            if (dao.keyCount(key) != 0) return@launch
            val near = dao.nearDuplicate(parsed.merchant, parsed.amount, sbn.postTime - 180_000L, sbn.postTime + 180_000L)
            val rule = dao.ruleFor(MerchantCategorizer.key(parsed.merchant))
            val suggestion = rule?.let { MerchantCategorySuggestion(it.category, it.tags, it.autoConfirm) }
            val resolvedStatus = MerchantCategorizer.status(suggestion, parsed.kind == "PURCHASE", near > 0)
            val entry = LedgerEntry(
                kind = "EXPENSE", amount = parsed.amount, date = date, category = suggestion?.category ?: "미분류",
                merchant = parsed.merchant, memo = if (near > 0) "유사 거래 발견 · 중복 여부 확인 필요" else if (resolvedStatus == "CONFIRMED") "사용자 승인 규칙으로 자동 확정" else "앱 알림에서 추출 · 검토 후 확정",
                status = resolvedStatus, source = "NOTIFICATION", dedupeKey = key, createdAt = sbn.postTime,
                tags = suggestion?.tags ?: ""
            )
            if (dao.insertLedger(entry) > 0) BudgetWidget.updateAll(applicationContext)
        }
    }
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
