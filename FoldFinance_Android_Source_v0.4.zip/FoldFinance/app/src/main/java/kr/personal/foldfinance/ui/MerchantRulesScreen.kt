package kr.personal.foldfinance.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kr.personal.foldfinance.data.FinanceViewModel
import kr.personal.foldfinance.data.MerchantRule
import kr.personal.foldfinance.domain.MerchantCategorizer

@Composable
private fun MerchantRuleDialog(existing: MerchantRule?, onDismiss: () -> Unit, onSave: (String, String, String, Boolean) -> Unit) {
    var merchant by rememberSaveable(existing) { mutableStateOf(existing?.merchantKey ?: "") }
    var category by rememberSaveable(existing) { mutableStateOf(existing?.category ?: "") }
    var tags by rememberSaveable(existing) { mutableStateOf(existing?.tags ?: "") }
    var autoConfirm by rememberSaveable(existing) { mutableStateOf(existing?.autoConfirm ?: false) }
    var error by rememberSaveable(existing) { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if(existing == null) "가맹점 분류 규칙 추가" else "가맹점 규칙 수정") },
        text = {
            Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Field("가맹점명 (정확 일치)", merchant, { merchant = it })
                Field("분류 카테고리", category, { category = it })
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("카페·커피", "데이트", "쇼핑", "교통").forEach { choice ->
                        // 카테고리 선택은 자유 편집을 제한하지 않는다.
                        TextButton(onClick = { category = choice }) { Text(choice, fontSize = 10.sp) }
                    }
                }
                Field("태그 (쉼표로 구분)", tags, { tags = it })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = autoConfirm, onCheckedChange = { autoConfirm = it })
                    Text("중복 의심이 없는 승인 알림 자동 확정", fontSize = 12.sp)
                }
                Text("자동 확정을 선택하지 않으면 카테고리만 자동 지정하고 최종 승인 전에 확인받습니다. 취소·환불 및 중복 의심 거래는 언제나 검토가 필요합니다.", fontSize = 11.sp, color = Pink)
                if(error) Text("가맹점명은 2~100자, 카테고리는 필수입니다.", color = Pink, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = {
            val normalized = MerchantCategorizer.key(merchant)
            if (normalized.length !in 2..100 || category.isBlank()) error = true
            else onSave(merchant, category, tags, autoConfirm)
        }) { Text("규칙 저장") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } })
}

@Composable
internal fun MerchantRulesPage(rules: List<MerchantRule>, model: FinanceViewModel) {
    var editing by remember { mutableStateOf<MerchantRule?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var remove by remember { mutableStateOf<MerchantRule?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("가맹점 자동 분류", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("본인이 지정한 정확한 가맹점명에만 규칙을 적용합니다. 앱 알림이 아닌 수기 거래, 기존 거래에는 소급 적용하지 않습니다.", fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { editing = null; showEditor = true }) { Text("+ 가맹점 규칙 추가") }
        }
        if(rules.isEmpty()) RoundedCard(Modifier.fillMaxWidth()) { Text("등록된 규칙이 없습니다.", fontSize = 12.sp) }
        rules.forEach { rule ->
            RoundedCard(Modifier.fillMaxWidth()) {
                Text(rule.merchantKey, fontWeight = FontWeight.SemiBold)
                Text("${rule.category}${if(rule.tags.isBlank()) "" else " · " + rule.tags.split(',').joinToString(" ") { "#$it" }}", fontSize = 12.sp)
                Text(if(rule.autoConfirm) "일치하는 새 승인 알림 자동 확정" else "분류만 추천 · 결제 확정은 수동 확인", color = if(rule.autoConfirm) Green else Pink, fontSize = 11.sp)
                Row {
                    TextButton(onClick = { editing = rule; showEditor = true }) { Text("수정") }
                    TextButton(onClick = { remove = rule }) { Text("삭제") }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
    }
    if(showEditor) MerchantRuleDialog(editing, { showEditor = false }) { merchant, category, tags, autoConfirm ->
        if(editing != null && MerchantCategorizer.key(merchant) != editing!!.merchantKey) model.deleteRule(editing!!.merchantKey)
        model.putRule(merchant, category, tags, autoConfirm)
        showEditor = false
    }
    remove?.let { candidate ->
        AlertDialog(onDismissRequest = { remove = null }, title = { Text("규칙을 삭제할까요?") },
            text = { Text("기존 거래의 카테고리와 지출액은 변경되지 않습니다.") },
            confirmButton = { TextButton(onClick = { model.deleteRule(candidate.merchantKey); remove = null }) { Text("삭제") } },
            dismissButton = { TextButton(onClick = { remove = null }) { Text("취소") } })
    }
}
