import kr.personal.foldfinance.domain.*

private var checks = 0
private fun eq(expected: Any?, actual: Any?, what: String) {
    check(expected == actual) { "$what: expected=$expected, actual=$actual" }; checks++
}
private fun truth(actual: Boolean, what: String) { check(actual) { what }; checks++ }

fun main() {
    val date = "2026-10-24"
    val dateEvent = EventWindow(1, date, "여자친구 데이트", "14:00", "22:00")
    val work = EventWindow(2, date, "출근", "08:00", "09:30")
    val other = EventWindow(3, "2026-10-25", "여행", "10:00", "20:00")
    val all = listOf(dateEvent,work,other)
    eq(1, EventExpenseMatcher.candidates(date,"14:00","카페",all).size, "start boundary")
    eq(1, EventExpenseMatcher.candidates(date,"22:00","카페",all).size, "end boundary")
    eq(0, EventExpenseMatcher.candidates(date,"22:01","카페",all).size, "outside")
    eq(0, EventExpenseMatcher.candidates(date,"13:59","카페",all).size, "before")
    eq(0, EventExpenseMatcher.candidates(date,"", "카페",all).size, "no time")
    eq(0, EventExpenseMatcher.candidates(date,null,"카페",all).size, "null time")
    eq(0, EventExpenseMatcher.candidates(date,"14:00","",all).size, "no merchant")
    eq(0, EventExpenseMatcher.candidates("invalid","14:00","카페",all).size, "invalid date")
    eq(0, EventExpenseMatcher.candidates(date,"25:90","카페",all).size, "invalid time")
    eq(0, EventExpenseMatcher.candidates(date,"14:00","카페",listOf(other)).size, "other day")
    eq("데이트",EventExpenseMatcher.candidates(date,"20:00","음식점",all).single().suggestedTag, "date tag")
    eq("출퇴근",EventExpenseMatcher.candidates(date,"09:00","버스",all).single().suggestedTag, "commute tag")
    eq("여행",EventExpenseMatcher.candidates("2026-10-25","10:00","택시",all).single().suggestedTag, "travel tag")
    eq("MEDIUM",EventExpenseMatcher.candidates(date,"20:00","카페",all).single().confidence, "not autoconfirm")
    val overlap = EventWindow(4, date, "가족모임", "18:00", "20:00")
    eq(listOf(1L,4L),EventExpenseMatcher.candidates(date,"19:00","레스토랑",all+overlap).map{it.id},"overlap all candidates")
    eq(null,EventExpenseMatcher.candidates(date,"19:00","레스토랑",listOf(overlap)).single().suggestedTag,"no inferred tag")
    eq("데이트",EventExpenseMatcher.mergeTag("", "데이트"),"new tag")
    eq("커피,데이트",EventExpenseMatcher.mergeTag("커피", "데이트"),"append")
    eq("데이트",EventExpenseMatcher.mergeTag("#데이트", "데이트"),"dedupe")
    eq("A,B",EventExpenseMatcher.mergeTag("A,B,A", null),"dedupe existing")
    eq("",EventExpenseMatcher.mergeTag("", null),"empty")
    eq(0,EventExpenseMatcher.candidates(date,"14:00","버스",listOf(EventWindow(9,date,"밤샘","22:00","02:00"))).size,"overnight not guessed")
    eq(0,EventExpenseMatcher.candidates(date,"14:00","버스",listOf(EventWindow(9,date,"불량시간","invalid","23:00"))).size,"bad event time")
    truth(EventExpenseMatcher.candidates(date,"19:00","마트",all+overlap).size > 1,"ambiguous event not silently chosen")
    eq(listOf(1L), EventExpenseMatcher.candidates(date,"15:00","쇼핑",all).map{it.id}, "merchant kind not mandatory")
    println("PASS: $checks event-expense matcher checks")
}
