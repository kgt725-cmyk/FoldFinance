package org.json
class JSONArray {
    constructor()
    fun put(value: Any?): JSONArray = this
    fun length(): Int = 0
    fun getJSONObject(index: Int): JSONObject = JSONObject()
}
class JSONObject {
    constructor()
    constructor(raw: String)
    fun put(key: String, value: Any?): JSONObject = this
    fun getInt(key: String): Int = 0
    fun getLong(key: String): Long = 0
    fun getString(key: String): String = ""
    fun getBoolean(key: String): Boolean = false
    fun getJSONObject(key: String): JSONObject = this
    fun getJSONArray(key: String): JSONArray = JSONArray()
    fun optString(key: String, defaultValue: String = ""): String = defaultValue
    fun optLong(key: String): Long = 0
    fun isNull(key: String): Boolean = true
    fun has(key: String): Boolean = false
    fun toString(indentSpaces: Int): String = "{}"
    companion object { val NULL = Any() }
}
