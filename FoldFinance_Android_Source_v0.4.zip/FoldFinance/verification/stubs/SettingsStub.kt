package kr.personal.foldfinance.data
data class FinanceSettings(
    val salary: Long = 2_400_000,
    val savingsGoal: Long = 1_400_000,
    val budget: Long = 1_000_000,
    val payday: Int = 15,
    val oneWayFare: Long = 0,
    val ridesPerDay: Int = 2,
    val weekdayMask: Int = 31,
    val kpassEnabled: Boolean = false,
    val widgetPrivate: Boolean = false
)
