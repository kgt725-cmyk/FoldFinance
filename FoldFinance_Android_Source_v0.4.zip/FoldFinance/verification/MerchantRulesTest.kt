import kr.personal.foldfinance.domain.MerchantCategorizer
import kr.personal.foldfinance.domain.MerchantCategorySuggestion

fun main() {
    var checked = 0
    fun verify(value: Boolean, label: String) { check(value) { label }; checked++ }
    fun rule(category: String, confirmed: Boolean = false) = MerchantCategorySuggestion(category, "데이트", confirmed)
    val key = MerchantCategorizer.key("  스타벅스  ")
    val rules = mapOf(key to rule("카페·커피"), MerchantCategorizer.key("SK텔레콤") to rule("통신비", true))
    verify(key == "스타벅스", "한글 원문 유지")
    verify(MerchantCategorizer.key("   ABC   Co  ") == "abc co", "연속 공백과 대문자 정규화")
    verify(MerchantCategorizer.key("스타벅스") == MerchantCategorizer.key(" 스타벅스 "), "양끝 공백")
    verify(MerchantCategorizer.key("NETFLIX") == MerchantCategorizer.key("Netflix"), "영문 대소문자")
    verify(MerchantCategorizer.suggest("스타벅스", rules)?.category == "카페·커피", "정확 분류")
    verify(MerchantCategorizer.suggest("스타벅스 강남점", rules) == null, "부분 일치 확정 금지")
    verify(MerchantCategorizer.suggest("스타", rules) == null, "짧은 부분 일치 금지")
    verify(MerchantCategorizer.suggest("없는 가맹점", rules) == null, "미등록 가맹점")
    verify(MerchantCategorizer.status(null, true, false) == "REVIEW", "규칙 없는 알림 검토")
    verify(MerchantCategorizer.status(rule("통신비"), true, false) == "REVIEW", "자동 확정 미동의는 검토")
    verify(MerchantCategorizer.status(rule("통신비", true), true, false) == "CONFIRMED", "사용자 설정 자동확정")
    verify(MerchantCategorizer.status(rule("통신비", true), false, false) == "REVIEW", "취소 환불 검토")
    verify(MerchantCategorizer.status(rule("통신비", true), true, true) == "REVIEW", "근접 중복 검토")
    verify(MerchantCategorizer.suggest("sk텔레콤", rules)?.autoConfirm == true, "영문 대소문자 정규화 저장")
    verify(MerchantCategorizer.status(MerchantCategorizer.suggest("SK텔레콤", rules), true, false) == "CONFIRMED", "매칭 후 자동 확정")
    verify(MerchantCategorizer.status(MerchantCategorizer.suggest("SK텔레콤", rules), true, true) == "REVIEW", "매칭되어도 중복은 보류")
    println("PASS: $checked merchant classification checks")
}
