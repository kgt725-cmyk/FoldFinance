"""Apply actual v3→v4 SQL from Kotlin file to a seeded v3 SQLite sample.
This is not Room's generated-schema verification and does not prove Android runtime compatibility.
"""
import re
import sqlite3
from pathlib import Path
source = (Path(__file__).resolve().parents[1]/'app/src/main/java/kr/personal/foldfinance/data/FinanceDatabase.kt').read_text()
section = source.split('val MIGRATION_3_4')[1].split('@Volatile')[0]
statements = re.findall(r'db\.execSQL\("([^"\n]+)"\)',section)
statements += [m.strip() for m in re.findall(r'db\.execSQL\("""(.*?)"""\.trimIndent\(\)\)',section,re.S)]
assert len(statements) == 3, statements
conn = sqlite3.connect(':memory:')
conn.executescript('''
CREATE TABLE ledger (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,kind TEXT NOT NULL,amount INTEGER NOT NULL,date TEXT NOT NULL,category TEXT NOT NULL, merchant TEXT NOT NULL,memo TEXT NOT NULL,status TEXT NOT NULL,source TEXT NOT NULL,dedupeKey TEXT,transitDate TEXT,workMonth TEXT,createdAt INTEGER NOT NULL,tags TEXT NOT NULL,occurredAtTime TEXT,linkedEventId INTEGER);
CREATE UNIQUE INDEX index_ledger_dedupeKey ON ledger(dedupeKey);
CREATE UNIQUE INDEX index_ledger_transitDate ON ledger(transitDate);
CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,date TEXT NOT NULL,title TEXT NOT NULL,start TEXT NOT NULL,end TEXT NOT NULL,note TEXT NOT NULL,budget INTEGER NOT NULL);
CREATE TABLE merchant_rules(merchantKey TEXT NOT NULL PRIMARY KEY,category TEXT NOT NULL,tags TEXT NOT NULL,autoConfirm INTEGER NOT NULL);
INSERT INTO ledger(id,kind,amount,date,category,merchant,memo,status,source,createdAt,tags,linkedEventId) VALUES (14,'INCOME',2400000,'2026-10-15','급여','태림공조','','CONFIRMED','MANUAL',123,'',NULL);
INSERT INTO ledger(id,kind,amount,date,category,merchant,memo,status,source,createdAt,tags,linkedEventId) VALUES (15,'EXPENSE',50000,'2026-10-20','통신비','통신사','','CONFIRMED','MANUAL',124,'',NULL);
INSERT INTO events VALUES(7,'2026-10-24','데이트','14:00','22:00','',60000);
INSERT INTO merchant_rules VALUES('통신사','통신비','',0);
PRAGMA user_version=3;
''')
checks = 0
def check(v, name):
    global checks
    assert v, name
    checks += 1
for stmt in statements: conn.execute(stmt)
conn.execute('PRAGMA user_version=4')
check(conn.execute('PRAGMA user_version').fetchone()[0] == 4, 'version')
colnames = [c[1] for c in conn.execute('PRAGMA table_info(ledger)')]
check(colnames[-2:] == ['linkedRecurringId','linkedPlanMonth'],'added fields')
check(conn.execute('SELECT amount FROM ledger WHERE id=14').fetchone()[0] == 2400000,'salary preserved')
check(conn.execute('SELECT amount FROM ledger WHERE id=15').fetchone()[0] == 50000,'expense preserved')
check(conn.execute('SELECT sum(amount) FROM ledger').fetchone()[0] == 2450000,'totals unchanged')
check(conn.execute('SELECT title FROM events WHERE id=7').fetchone()[0] == '데이트','events preserved')
check(conn.execute('SELECT category FROM merchant_rules WHERE merchantKey="통신사"').fetchone()[0] == '통신비','rules preserved')
check(conn.execute('SELECT linkedRecurringId FROM ledger WHERE id=14').fetchone()[0] is None,'nullable')
check(conn.execute('SELECT COUNT(*) FROM recurring_plans').fetchone()[0] == 0, 'new plans empty')
conn.execute("INSERT INTO recurring_plans(id,kind,title,amount,category,dayOfMonth,startMonth,active,memo) VALUES(1,'INCOME','급여',2400000,'급여',15,'2026-10',1,'')")
conn.execute("UPDATE ledger SET linkedRecurringId=1, linkedPlanMonth='2026-10' WHERE id=14")
check(conn.execute('SELECT linkedPlanMonth FROM ledger WHERE id=14').fetchone()[0]=='2026-10','link salary')
conn.execute('UPDATE recurring_plans SET active=0 WHERE id=1')
check(conn.execute('SELECT amount FROM ledger WHERE id=14').fetchone()[0] == 2400000,'deactivate preserves ledger')
check(conn.execute('PRAGMA integrity_check').fetchone()[0] == 'ok','integrity')
check([r[1] for r in conn.execute('PRAGMA table_info(recurring_plans)')] == ['id','kind','title','amount','category','dayOfMonth','startMonth','active','memo'],'columns')
print(f'PASS: {checks} SQLite v3→v4 example migration checks')
