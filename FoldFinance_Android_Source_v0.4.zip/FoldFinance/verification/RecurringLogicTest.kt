import kr.personal.foldfinance.domain.*
import java.time.LocalDate
import java.time.YearMonth

fun main() {
    var passed = 0
    fun check(name: String, test: () -> Unit) { test(); println("PASS $name"); passed++ }
    val salary = MonthlyPlan(1, "INCOME", "급여", 2_400_000, 15, YearMonth.of(2026, 10), true)
    val fixed = MonthlyPlan(2, "EXPENSE", "통신비", 55_000, 20, YearMonth.of(2026, 10), true)
    val w = DateWindow(LocalDate.parse("2026-10-15"), LocalDate.parse("2026-11-15"))
    val base = RecurringMath.occurrences(listOf(salary, fixed), emptyList(), w)
    check("급여 주기별 예정 생성") { assert(base.map { it.dueDate.toString() } == listOf("2026-10-15", "2026-10-20")) }
    check("수입 예정은 확정 실적 아님") { assert(base[0].actualAmount == 0L && base[0].status == "EXPECTED") }
    check("전월 근무 급여 귀속") { assert(base[0].incomeWorkMonth.toString() == "2026-09") }
    check("고정지출 예정 별도") { assert(base[1].plannedAmount == 55000L && base[1].actualAmount == 0L) }
    val p = PlanPayment(1, YearMonth.of(2026,10), "INCOME", 2_400_000, "CONFIRMED", LocalDate.parse("2026-10-14"))
    check("실제 입금일이 달라도 명시 연결") { assert(RecurringMath.occurrences(listOf(salary), listOf(p), w).single().status == "PAID") }
    check("검토 중인 수입은 미확정") { assert(RecurringMath.occurrences(listOf(salary), listOf(p.copy(status="REVIEW")), w).single().actualAmount == 0L) }
    check("예정 수입은 미확정") { assert(RecurringMath.occurrences(listOf(salary), listOf(p.copy(status="EXPECTED")), w).single().actualAmount == 0L) }
    check("부분 입금 상태") { assert(RecurringMath.occurrences(listOf(salary), listOf(p.copy(amount=500000)), w).single().pendingAmount == 1900000L) }
    check("복수 확인 입금 합산") {
        val two = listOf(p.copy(amount=1_000_000), p.copy(amount=1_400_000))
        assert(RecurringMath.occurrences(listOf(salary),two,w).single().status=="PAID")
    }
    check("초과 지급 상태") { assert(RecurringMath.occurrences(listOf(salary), listOf(p.copy(amount=2_500_000)), w).single().status == "OVERPAID") }
    check("중단한 계획은 표시 안 함") { assert(RecurringMath.occurrences(listOf(salary.copy(active=false)),emptyList(),w).isEmpty()) }
    check("급여 주기 걸친 첫날") {
        val next = DateWindow(LocalDate.parse("2026-11-15"), LocalDate.parse("2026-12-15"))
        assert(RecurringMath.occurrences(listOf(salary),emptyList(),next).single().incomeWorkMonth.toString()=="2026-10")
    }
    check("연말 급여 주기 경계") {
        val next = DateWindow(LocalDate.parse("2026-12-15"),LocalDate.parse("2027-01-15"))
        assert(RecurringMath.occurrences(listOf(salary),emptyList(),next).single().dueDate.toString()=="2026-12-15")
    }
    check("월별 보기에는 해당 월 계획만") {
        val next = DateWindow(LocalDate.parse("2026-11-01"),LocalDate.parse("2026-12-01"))
        assert(RecurringMath.occurrences(listOf(salary, fixed), emptyList(), next).size == 2)
    }
    check("정확한 예정월 문자열만") { assert(RecurringMath.validMonth("2026-10") && !RecurringMath.validMonth("2026-13") && !RecurringMath.validMonth("2026-1")) }
    check("다른 예정월 입금은 중복 집계하지 않음") {
        assert(RecurringMath.occurrences(listOf(salary), listOf(p.copy(planMonth=YearMonth.of(2026,11))), w).single().actualAmount == 0L)
    }
    check("음수 입금 방어") {
        assert(runCatching { RecurringMath.occurrences(listOf(salary), listOf(p.copy(amount=-1)), w) }.isFailure)
    }
    check("다른 유형 매칭 거부") {
        assert(runCatching { RecurringMath.occurrences(listOf(salary), listOf(p.copy(kind="EXPENSE")), w) }.isFailure)
    }
    check("월말 계획 제한 1..28") {
        assert(runCatching { RecurringMath.occurrences(listOf(salary.copy(day=31)), emptyList(),w) }.isFailure)
    }
    check("계획 중복 ID 방어") {
        assert(runCatching { RecurringMath.occurrences(listOf(salary, salary),emptyList(),w) }.isFailure)
    }
    check("actualFor 미확정 제외") {
        assert(RecurringMath.actualFor(listOf(p.copy(status="EXPECTED")),1,YearMonth.of(2026,10)) == 0L)
    }
    println("RecurringMath tests passed: $passed")
}
