# FoldFinance v0.2 테스트 결과

실행일: 2026-10-19

| 테스트 집합 | 도구 | 점검 | 결과 |
|---|---|---:|---|
| FinanceLogicTest.kt | Kotlin 1.9.0 / JVM 21 | 36 | 모두 통과 |
| TransitReconcileTest.kt | Kotlin 1.9.0 / JVM 21 | 20 | 모두 통과 |
| MerchantRulesTest.kt | Kotlin 1.9.0 / JVM 21 | 16 | 모두 통과 |
| sqlite_migration_check.py | Python SQLite 메모리 DB | 11 | 모두 통과 |
| XML 구문 분석 | Python ElementTree | 5개 파일 | 모두 통과 |

확인 항목: 급여 주기·연말 경계, 수입/저축/지출 구분, K-패스 gross/net, 티머니 기간 총액 vs 일별 확정액, 0원/음수/오버플로 처리, 가맹점 정확 일치, 사용자 설정 없는 자동확정 차단, 취소/중복 검토, SQL로 기존 예시 원장 보존 및 신규 테이블 생성.

중요한 한계:

- 실제 Android SDK/Gradle 빌드가 불가능하여 **Android 앱 코드 전체 컴파일을 완료하지 못함**.
- **Room 자동 검증, Android 기기 데이터 마이그레이션, JSON 백업/복원 실제 테스트 미완료**.
- 알림 수집 권한, 위젯, 폴드 화면 전환, 시스템 글자 크기 대응 및 삼성월렛 이용내역은 실기기 확인이 필요함.
- SQL 테스트는 샘플 v1 DB에 신규 테이블 DDL을 실행한 테스트이며 Room이 생성한 전체 스키마와의 비교가 아님.
- 어떠한 APK 파일도 이 패키지에서 제공되지 않음.
