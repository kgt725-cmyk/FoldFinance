# FoldFinance v0.4 검증 결과 (2026-10-19)

| 구분 | 검증 | 결과 |
|---|---|---|
| 기존 순수 Kotlin | FinanceLogic 36 / TransitReconcile 20 / MerchantRules 16 / EventExpenseMatcher 25 / NotificationIdentity 12 | 총 109건 통과 (중단되었던 통합 실행 외, 개별 테스트 결과 및 v0.3 결과 포함) |
| 신규 순수 Kotlin | RecurringLogicTest.kt | **21/21 통과** |
| 기존 SQLite 예시 | v1→v2 11건 / v2→v3 10건 | **21/21 통과** |
| 신규 SQLite 예시 | v3→v4 실제 코드 SQL 추출 후 v3 샘플 적용 | **13/13 통과** |
| Android XML | Manifest + XML 리소스 | **5개 구문 파싱 통과** |
| Kotlin 스텁 타입 검사 | Entities.kt / FinanceBackup.kt + RecurringLogic.kt | **컴파일 통과** (Room과 org.json 실제 라이브러리가 아닌 검사용 스텁) |
| 실제 Android 앱 | Gradle Android assembleDebug, SDK 35, 폴드8 실행 | **미실시 / 성공 미확인** |

**총 독립 Kotlin 점검 130건, SQLite 예시 점검 34건, XML 5개 구문 검사 통과.** 이는 Android 앱 빌드/실행/사용 검증을 의미하지 않습니다.

## 검증해 본 시나리오

- 매월 15일 급여예정, 전월 귀속월, 실제 입금일이 14일인 경우도 명시된 예정월로 연결.
- 예정 수입/미확정 거래는 실제 금액에 포함하지 않음. 부분 입금, 같은 예정월 복수 입금, 초과 입금 대조.
- 12월~1월 급여 주기, 월간과 급여주기별 예정 생성의 구분.
- 고정지출 예정과 실제 확정 금액 구분, 일시 중단한 계획의 실제 원장 기록 보존.
- v3 샘플 DB에 v4 SQL 적용 후 원장·이벤트·가맹점 규칙 유지, 새 연결컬럼/정기계획 테이블 생성 및 SQLite integrity.
- JSON 백업 소스가 Android·JSON 스텁을 대상으로 Kotlin 타입 검사를 통과했는지 확인.

## 여전히 별도 검증이 필요한 것

- Android Studio의 Gradle Sync, Room annotation processing, Compose UI 전체 컴파일.
- Android Room의 실제 마이그레이션 스키마 검증(MigrationTestHelper 포함), 서비스 권한, 위젯.
- Android 실제 JSON export/import 호환성(v1~v4)의 동작·실제 파일 쓰기·복원 트랜잭션 검증.
- 갤럭시 Z 폴드8 커버/내부 화면, 글꼴 확대, 분할 화면, 앱 재시작 시 상태 복원.
- 사용자의 실제 결제 알림 파싱 적합성, 후불 티머니 이용내역 수동대조.
