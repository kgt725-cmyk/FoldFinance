import kr.personal.foldfinance.domain.NotificationIdentity

fun main() {
 var count = 0
 fun checkThat(value: Boolean, why:String) { check(value){why}; count++ }
 val a = NotificationIdentity.fingerprint("com.example.bank", "notification-1", 1_800_000L, "카페", 12000)
 val same = NotificationIdentity.fingerprint("com.example.bank", "notification-1", 1_800_000L, "카페", 12000)
 val distinctInMinute = NotificationIdentity.fingerprint("com.example.bank", "notification-2", 1_800_030L, "카페", 12000)
 checkThat(a == same,"repeated same notification stable")
 checkThat(a != distinctInMinute,"two distinct purchases inside same 3m bucket")
 checkThat(a != NotificationIdentity.fingerprint("com.example.bank", "notification-1", 1_800_030L, "카페", 12000),"different posting time")
 checkThat(a != NotificationIdentity.fingerprint("com.example.other", "notification-1", 1_800_000L, "카페", 12000),"source namespace")
 checkThat(a != NotificationIdentity.fingerprint("com.example.bank", "notification-1", 1_800_000L, "카페", 12500),"amount changed")
 checkThat(a != NotificationIdentity.fingerprint("com.example.bank", "notification-1", 1_800_000L, "다른카페", 12000),"merchant changed")
 checkThat(a.length==64 && a.all { it in "0123456789abcdef" },"64 lowercase hexadecimal")
 checkThat(!a.contains("com.example") && !a.contains("카페"),"no raw payload in key")
 checkThat(a == NotificationIdentity.fingerprint("com.example.bank", "notification-1", 1_800_000L, "카페", 12000), "deterministic")
 checkThat(runCatching { NotificationIdentity.fingerprint("", "k", 1L, "카페", 1L) }.isFailure,"blank source")
 checkThat(runCatching { NotificationIdentity.fingerprint("pkg", "", 1L, "카페", 1L) }.isFailure,"blank event key")
 checkThat(runCatching { NotificationIdentity.fingerprint("pkg", "key", 1L, "", 1L) }.isFailure,"blank merchant")
 println("PASS: $count notification identity checks")
}
