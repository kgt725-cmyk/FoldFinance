"""v0.1 예시 DB에 v0.2 SQL을 적용하고 기존 기록 및 새 테이블 제약을 검증한다.

Room 마이그레이션 API와 Room 스키마 검증을 대체하지 않는다.
"""
from pathlib import Path
import sqlite3
import re

root = Path(__file__).resolve().parents[1]
source = (root / 'app/src/main/java/kr/personal/foldfinance/data/FinanceDatabase.kt').read_text()
section = source.split('private val MIGRATION_1_2')[1].split('val MIGRATION_2_3')[0]
statements = re.findall(r'db\.execSQL\("""(CREATE TABLE IF NOT EXISTS.+?)"""\.trimIndent\(\)\)', section, re.S)
assert len(statements) == 2, f'expected 2 migration SQL statements; got {len(statements)}'

connection = sqlite3.connect(':memory:')
connection.execute('PRAGMA user_version=1')
connection.execute('CREATE TABLE ledger (id INTEGER PRIMARY KEY, kind TEXT, amount INTEGER, date TEXT)')
connection.execute('CREATE TABLE transit_bills (id INTEGER PRIMARY KEY, amount INTEGER)')
connection.execute("INSERT INTO ledger VALUES (1, 'EXPENSE', 3900, '2026-10-15')")
connection.execute('INSERT INTO transit_bills VALUES (2, 3900)')
for statement in statements:
    connection.execute(statement)
connection.execute('PRAGMA user_version=2')
checks = 0

def assert_check(condition, message):
    global checks
    assert condition, message
    checks += 1

assert_check(connection.execute('SELECT amount FROM ledger WHERE id=1').fetchone()[0] == 3900, '기존 원장 보존')
assert_check(connection.execute('SELECT amount FROM transit_bills WHERE id=2').fetchone()[0] == 3900, '기존 청구서 보존')
assert_check(connection.execute('PRAGMA user_version').fetchone()[0] == 2, '업그레이드 버전')
assert_check(all(connection.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone() for name in ['transit_statements', 'merchant_rules']), '테이블 생성')
connection.execute("INSERT INTO transit_statements(startDate,endDate,amount,memo) VALUES ('2026-10-15','2026-11-14',20000,'일별 미확인')")
assert_check(connection.execute('SELECT amount FROM transit_statements').fetchone()[0] == 20000, '기간 대조 기록')
assert_check(connection.execute('SELECT count(*) FROM ledger').fetchone()[0] == 1, '정산 금액 원장 중복 미생성')
connection.execute("INSERT INTO merchant_rules VALUES ('스타벅스','카페·커피','데이트',0)")
assert_check(connection.execute('SELECT category FROM merchant_rules').fetchone()[0] == '카페·커피', '가맹점 분류 저장')
assert_check(connection.execute('SELECT autoConfirm FROM merchant_rules').fetchone()[0] == 0, '자동 확정 기본 비활성')
try:
    connection.execute("INSERT INTO merchant_rules VALUES ('스타벅스','기타','',1)")
    raise AssertionError('복제 규칙 거절 실패')
except sqlite3.IntegrityError:
    checks += 1
for name, expected in {'transit_statements': ['id','startDate','endDate','amount','memo'], 'merchant_rules': ['merchantKey','category','tags','autoConfirm']}.items():
    columns = [row[1] for row in connection.execute(f'PRAGMA table_info({name})')]
    assert_check(columns == expected, f'{name} 컬럼 구조')
print(f'PASS: {checks} SQLite migration SQL checks')
