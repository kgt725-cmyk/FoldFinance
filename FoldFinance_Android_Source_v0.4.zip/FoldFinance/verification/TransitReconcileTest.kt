import kr.personal.foldfinance.domain.*
import java.time.LocalDate

fun main() {
    var checks = 0
    fun test(ok: Boolean, description: String) { check(ok) { description }; checks++ }
    fun d(date: String) = LocalDate.parse(date)
    val sample = listOf(
        ConfirmedTransitUse(d("2026-10-14"), 1500),
        ConfirmedTransitUse(d("2026-10-15"), 1500),
        ConfirmedTransitUse(d("2026-10-16"), 3200),
        ConfirmedTransitUse(d("2026-10-20"), 1500),
        ConfirmedTransitUse(d("2026-11-15"), 2100)
    )
    val match = TransitReconcile.compare(d("2026-10-15"), d("2026-11-14"), 6200, sample)
    test(match.knownDatedAmount == 6200L, "급여 주기 확정 내역 대조")
    test(match.amountMatches, "금액 일치")
    test(match.datedDays == 3, "확정일 수")
    test(match.difference == 0L, "차이 0")
    test(match.start == d("2026-10-15") && match.endInclusive == d("2026-11-14"), "기간 경계")
    val shortage = TransitReconcile.compare(d("2026-10-15"), d("2026-11-14"), 10000, sample)
    test(shortage.difference == 3800L && shortage.requiresReview, "총액이 크면 남은 확인액")
    val over = TransitReconcile.compare(d("2026-10-15"), d("2026-11-14"), 4000, sample)
    test(over.difference == -2200L, "확정 내역 초과 경고")
    test(TransitReconcile.compare(d("2026-10-15"), d("2026-10-15"), 1500, sample).amountMatches, "단일 날짜")
    test(TransitReconcile.compare(d("2026-10-17"), d("2026-10-19"), 0L, sample).amountMatches, "기록 없는 기간 0원")
    test(TransitReconcile.compare(d("2026-12-15"), d("2027-01-14"), 3000L, sample).difference == 3000L, "연도 넘는 기간")
    val two = listOf(ConfirmedTransitUse(d("2026-10-15"), 1000), ConfirmedTransitUse(d("2026-10-15"), 500))
    test(TransitReconcile.compare(d("2026-10-15"), d("2026-10-15"), 1500, two).datedDays == 1, "당일 여러 확정 거래")
    test(runCatching { TransitReconcile.compare(d("2026-10-20"), d("2026-10-19"), 500, sample) }.isFailure, "역전 기간 거절")
    test(runCatching { TransitReconcile.compare(d("2026-10-15"), d("2026-11-14"), -1, sample) }.isFailure, "음수 신고 거절")
    test(runCatching { TransitReconcile.compare(d("2026-10-15"), d("2026-11-14"), 30, listOf(ConfirmedTransitUse(d("2026-10-16"), -1))) }.isFailure, "음수 확정 거절")
    test(runCatching { TransitReconcile.compare(d("2026-10-15"), d("2026-11-14"), Long.MAX_VALUE, sample) }.isSuccess, "차이 계산 범위")
    test(runCatching { TransitReconcile.compare(d("2026-10-15"), d("2026-11-14"), 3000, listOf(ConfirmedTransitUse(d("2026-10-16"), Long.MAX_VALUE), ConfirmedTransitUse(d("2026-10-17"), 1000))) }.isFailure, "합계 오버플로 차단")
    // 기간 총액만 확인된 경우, 원장 집계와는 분리한다.
    val financial = listOf(FinancialEntry(d("2026-10-16"), "EXPENSE", 3200))
    test(FinanceMath.totals(financial, FinancePeriod.of(d("2026-10-20"), WindowMode.PAYDAY)).expense == 3200L, "대조용 총액은 지출로 가산되지 않음")
    // Kpass 환급은 확정 총지출이 아닌 별도 필드로 저장된다.
    val withRefund = financial + FinancialEntry(d("2026-10-21"), "KPASS_REBATE", 300)
    val totals = FinanceMath.totals(withRefund, FinancePeriod.of(d("2026-10-20"), WindowMode.PAYDAY))
    test(totals.expense == 3200L && totals.rebate == 300L, "K패스 gross/net 분리")
    test(FinanceMath.availableBudget(100_000, totals.expense) == 96_800L, "생활비는 gross 지출 기준")
    test(TransportMath.netFare(totals.expense, totals.rebate) == 2900L, "실질 교통비는 환급 차감")
    println("PASS: $checks transit reconciliation checks")
}
