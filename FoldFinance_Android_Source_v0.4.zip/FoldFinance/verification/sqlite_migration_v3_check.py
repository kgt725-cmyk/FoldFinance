"""v2 → v3 sample SQLite migration checks (not Room's official schema validation)."""
from pathlib import Path
import re
import sqlite3

root = Path(__file__).resolve().parents[1]
source = (root / 'app/src/main/java/kr/personal/foldfinance/data/FinanceDatabase.kt').read_text()
section = source.split('val MIGRATION_2_3')[1].split('val MIGRATION_3_4')[0]
statements = re.findall(r'db\.execSQL\("([^"]+)"\)', section)
assert len(statements) == 2, statements
conn = sqlite3.connect(':memory:')
conn.executescript('''
CREATE TABLE ledger (
 id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
 kind TEXT NOT NULL, amount INTEGER NOT NULL, date TEXT NOT NULL,
 category TEXT NOT NULL, merchant TEXT NOT NULL, memo TEXT NOT NULL,
 status TEXT NOT NULL, source TEXT NOT NULL, dedupeKey TEXT,
 transitDate TEXT, workMonth TEXT, createdAt INTEGER NOT NULL, tags TEXT NOT NULL
);
CREATE UNIQUE INDEX index_ledger_dedupeKey ON ledger (dedupeKey);
CREATE UNIQUE INDEX index_ledger_transitDate ON ledger (transitDate);
CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, date TEXT NOT NULL, title TEXT NOT NULL, start TEXT NOT NULL, end TEXT NOT NULL, note TEXT NOT NULL, budget INTEGER NOT NULL);
CREATE TABLE merchant_rules(merchantKey TEXT NOT NULL PRIMARY KEY, category TEXT NOT NULL, tags TEXT NOT NULL, autoConfirm INTEGER NOT NULL);
INSERT INTO ledger(id,kind,amount,date,category,merchant,memo,status,source,createdAt,tags)
VALUES (11,'EXPENSE',21000,'2026-10-24','개인 식비','식당','식사','CONFIRMED','MANUAL',0,'');
INSERT INTO events VALUES(8,'2026-10-24','데이트','14:00','22:00','',60000);
INSERT INTO merchant_rules VALUES('식당','개인 식비','데이트',0);
PRAGMA user_version = 2;
''')
for ddl in statements: conn.execute(ddl)
conn.execute('PRAGMA user_version = 3')
cnt=0
def verify(cond, msg):
 global cnt
 assert cond, msg; cnt+=1
verify(conn.execute('PRAGMA user_version').fetchone()[0]==3,'version')
verify([r[1] for r in conn.execute('PRAGMA table_info(ledger)')][-2:]==['occurredAtTime','linkedEventId'],'new columns')
verify(conn.execute('SELECT amount, date, status FROM ledger WHERE id=11').fetchone()==(21000,'2026-10-24','CONFIRMED'),'ledger preserved')
verify(conn.execute('SELECT occurredAtTime, linkedEventId FROM ledger WHERE id=11').fetchone()==(None,None),'new fields nullable')
verify(conn.execute('SELECT title FROM events WHERE id=8').fetchone()[0]=='데이트','event preserved')
verify(conn.execute('SELECT tags FROM merchant_rules').fetchone()[0]=='데이트','rules preserved')
conn.execute("UPDATE ledger SET occurredAtTime='19:05', linkedEventId=8 WHERE id=11")
verify(conn.execute('SELECT occurredAtTime, linkedEventId FROM ledger WHERE id=11').fetchone()==('19:05',8),'linked expense')
conn.execute('BEGIN') if not conn.in_transaction else None
conn.execute('UPDATE ledger SET linkedEventId=NULL WHERE linkedEventId=8')
conn.execute('DELETE FROM events WHERE id=8')
verify(conn.execute('SELECT linkedEventId FROM ledger WHERE id=11').fetchone()[0] is None, 'delete unlink transaction SQL')
verify(conn.execute('SELECT count(*) FROM ledger').fetchone()[0] == 1,'unlink does not delete spend')
verify(conn.execute('SELECT amount FROM ledger').fetchone()[0] == 21000,'unlink does not change sum')
print(f'PASS: {cnt} SQLite v2→v3 sample migration checks')
