# FoldFinance v0.3 개발 검증 기록 — 2026-10-19

| 검증 코드 | 방법 | 결과 |
|---|---|---|
| FinanceLogicTest.kt | Kotlin 1.9.0 CLI/JVM 21 | 36/36 통과 |
| TransitReconcileTest.kt | Kotlin 1.9.0 CLI/JVM 21 | 20/20 통과 |
| MerchantRulesTest.kt | Kotlin 1.9.0 CLI/JVM 21 | 16/16 통과 |
| EventExpenseMatcherTest.kt | Kotlin 1.9.0 CLI/JVM 21 | 25/25 통과 |
| NotificationIdentityTest.kt | Kotlin 1.9.0 CLI/JVM 21 | 12/12 통과 |
| sqlite_migration_check.py | Python SQLite 예시 v1→v2 | 11/11 통과 |
| sqlite_migration_v3_check.py | Python SQLite 예시 v2→v3 | 10/10 통과 |
| AndroidManifest 및 4개 XML 리소스 | Python XML 구문 파서 | 5/5 통과 |
| Entities.kt + FinanceBackup.kt | 최소 Android/JSON API 스텁을 이용한 Kotlin 정적 타입 검사 | 통과 (실제 API 검증 아님) |

**총 순수 Kotlin 109개, SQL 예시 점검 21개, XML 파일 5개 통과.** 테스트는 기능 묶음별 명시적 검증 건수이며 실제 안드로이드 계측 테스트 건수가 아닙니다.

검증한 핵심: 급여일 15일/연말 경계, 실수입·저축 납입액·확정 지출 구분, 환불 음수, 교통비 예정/확정/기간대조/후불 청구 분리, 가맹점 규칙, 실결제 시각 없는 일정 추천 금지, 겹치는 일정 후보 보존, 사용자 직접 태그 적용, 알림 해시 식별에서 동일 금액 복수 결제 유실 방지.

## 미검증

- SDK/Gradle/저장소 접근이 이 실행 환경에 없어 **Gradle Sync, 앱 전체 컴파일, APK 생성 불가**. Gradle 설치 및 SDK 라이선스 동의 등은 외부 인터넷 연결 환경에서 수행해야 함.
- 실제 Room 2.7.1 schema validation 및 0.1/0.2 실데이터로의 업그레이드 검증 **미실시**. 예시 SQLite 변경 쿼리 검사는 이를 대신하지 않음.
- v1, v2, v3 JSON 백업·복원 Android `org.json`, DataStore, Room 통합 동작 **미실시**. 최소 스텁 타입 검사는 참조 코드의 Kotlin 타입 오류 여부 일부만 확인한 것임.
- Android notification binding 및 원문 파싱 실기기 QA, 교통카드/삼성월렛 직접 확인, 위젯 업데이트, 접힘/펼침·멀티윈도우 **미실시**.

공식 구현 참고: [NotificationListenerService](https://developer.android.com/reference/android/service/notification/NotificationListenerService), [Room MigrationTestHelper](https://developer.android.com/reference/androidx/room/testing/MigrationTestHelper), [Adaptive layouts](https://developer.android.com/develop/adaptive-apps/guides/get-started-with-adaptive-apps).
