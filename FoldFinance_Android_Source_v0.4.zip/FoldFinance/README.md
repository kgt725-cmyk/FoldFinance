# 내 자산 (FoldFinance) Android 개발 프로젝트 v0.4.0

**현재 산출물은 Android Studio용 소스코드입니다.** 이 환경에는 Android SDK 및 Gradle 빌드 도구가 없어 전체 Android 컴파일, APK 생성, 기기 설치 및 실행은 아직 검증되지 않았습니다. 순수 Kotlin/SQLite 테스트 통과는 APK 동작을 보장하지 않습니다. 소스를 실기기 금융기록에 사용하기 전에 아래 절차에 따라 빌드와 QA를 마쳐야 합니다.

## v0.4 변경 요약

- **정기 관리 화면 신설**: 매월 수입(급여) 및 고정지출(통신비·구독 등) 계획을 별도 Room 테이블에 기록. 기본 재무 설정의 240만 원/15일을 정기 급여 등록 시 제안합니다. 등록 후 계획일부터 반복 예정 건을 **가상 계산**합니다. 자동으로 수입·지출 원장을 채우지는 않습니다.
- **급여 귀속월**: 10월 15일 지급 예정 급여는 자동으로 `2026-09` 귀속으로 표시. 실제 입금일이 휴일 등으로 바뀌면 개별 거래의 실제 입금 날짜만 변경하면 됩니다.
- **예정/실제 연결**: 사용자가 계획 화면에서 실제 입금·결제를 명시적으로 확인하여 거래를 입력하거나, 이미 수집한 금융 알림·수기 거래를 수입/지출 편집에서 정기 계획과 예정월에 연결합니다. 정기 계획은 실거래 합계에 재산입하지 않습니다. 일부 입금·과납 등은 예정액 대비 별도 상태로 표시합니다.
- **오류 예방**: 검토 중(`REVIEW`)인 금융 지출을 편집하는 것만으로 확정 처리하던 위험을 개선하고, 명시적 확인 체크를 거치도록 했습니다.
- **기존 기록 보존**: DB v3→v4 마이그레이션에서 ledger에 `linkedRecurringId`, `linkedPlanMonth` 2개 컬럼을 추가하고 `recurring_plans` 테이블을 추가합니다. 비활성화한 반복 계획도 DB에 보존되고 원장 거래는 유지됩니다.
- **백업 JSON schema v4**: 반복 계획 및 거래 연결 키 포함. 과거 v1·v2·v3 형식의 코드는 읽을 수 있도록 유지했습니다. 거래 금액/상태 및 연결 계획 참조를 복원 전에 검증합니다. 백업은 아직 **암호화되지 않은 JSON**입니다.
- **GitHub Actions 빌드 워크플로 추가**: `.github/workflows/build-debug-apk.yml`. Android SDK 35, Gradle 8.11.1, JDK 17을 준비해 debug APK를 생성하고 다운로드 아티팩트로 올리도록 작성했습니다. **실제 워크플로 실행 결과는 아직 없습니다.**

## 시스템 구조

- Android Kotlin, Compose Material 3, Room 2.7.1, DataStore, NotificationListenerService, AppWidget.
- 라이브러리 버전: AGP 8.9.2 / Kotlin 2.0.21 / Gradle 8.11.1 / API 35 / JDK 17.
- `data/Entities.kt`, `data/AppDao.kt`, `data/FinanceDatabase.kt`: 원장/반복계획/교통비 원천데이터.
- `domain/RecurringLogic.kt`: Android 의존성 없는 반복 예정 생성 및 예정-실제 대조 로직.
- `ui/RecurringScreen.kt`: 계획 추가/중단/예정액 보기/실제 결제 수동확인 화면.
- `ui/FinanceForms.kt`: 실제 수입·지출을 계획에 연결하는 편집기.
- `data/FinanceBackup.kt`: 전체 JSON 백업 schema 4 및 기존 schema 1~3 로더.
- `verification/`: 독립 테스트 및 샘플 SQLite 데이터 마이그레이션 검사.

## Android Studio 로컬 빌드 방법

1. 인터넷 가능한 Windows 또는 macOS에 Android Studio 설치. JDK 17, Android SDK Platform API 35, Build Tools 35.0.0 설치.
2. ZIP 해제 후 **`FoldFinance` 폴더**(`settings.gradle.kts`가 위치)를 Android Studio에서 Open.
3. 프로젝트에 **Gradle Wrapper JAR가 포함되지 않았습니다**. 시스템에 Gradle 8.11.1을 설치한 경우 프로젝트 폴더 터미널에서 다음 명령을 사용하세요:

   ```powershell
   gradle --no-daemon :app:assembleDebug
   ```

4. 빌드 성공 시 `app/build/outputs/apk/debug/app-debug.apk` 생성. USB 디버깅 기기에서는 `adb install -r app-debug.apk`로 설치하거나 해당 APK를 폰으로 전송한 뒤 열어 설치합니다. 현재 제공된 ZIP에는 APK가 포함되지 않았습니다.
5. Gradle Sync나 컴파일 오류 발생 시 오류 로그를 확인하여 소스와 라이브러리 호환성 문제부터 수정해야 합니다. **빌드가 성공했다고 알려진 상태가 아닙니다.**

## GitHub Actions에서 APK 빌드하는 대안

1. 새로운 **비공개** GitHub 저장소를 생성하고 ZIP 안의 `FoldFinance` **하위 파일 전체**를 저장소 루트에 업로드하세요 (`.github` 폴더 포함).
2. 저장소 Actions 탭 → **Build debug APK** 워크플로 → **Run workflow**. `main` 등 소스가 있는 브랜치를 선택합니다.
3. 워크플로가 성공한 경우만 해당 실행 페이지 하단 Artifacts에서 `FoldFinance-v0.4-debug-apk`를 받습니다. 그 안에 `app-debug.apk`가 있습니다.
4. Actions가 실패하면 로그(특히 `:app:compileDebugKotlin`, `kapt`, `:app:assembleDebug`)를 이용해 오류를 수정해야 합니다. **GitHub에 업로드하거나 Actions를 실행한 적은 없습니다.**
5. debug APK는 개인 개발 테스트 전용으로 취급하세요. 개인 금융 내역을 입력하기 전 테스트 데이터로 수입·저축·지출 CRUD, 앱 재시작, 백업/복원, 위젯, 폴드 접힘/펼침, 알림 권한 동작을 확인하세요.

## 반복 계획 사용법

1. 앱 → **더보기** → **정기 관리** → **정기 계획 추가**.
2. **정기 수입** 버튼을 선택하면 `급여/2400000/15일`을 제안합니다. 실제 지급예정일/금액과 시작월을 확인한 뒤 등록합니다. 10월 15일 예정 급여의 귀속월은 9월입니다.
3. 통신비, 넷플릭스, 보험 등은 **고정지출**로 추가합니다. 금액 및 청구예정일은 사용자가 입력합니다.
4. 실제 입금/지출이 발생하면 정기 관리에서 해당 월 **실제 거래 직접 확인** 후 실제 금액·실제 입금/결제일을 입력하거나, 이미 수집된 거래를 수입/지출의 **수정 → 정기 계획 연결 → 예정월**로 연결합니다. 이미 수집된 알림 거래가 있다면 **새 거래를 또 추가하지 마세요.**
5. 예정 실적은 홈과 통계의 실제 합계에 들어가지 않습니다. 같은 고정지출의 별도 카드 청구·알림이 들어왔다면 검토 후 원천 거래 하나만 남기고 연결을 수정하세요.
6. 계획 중단 버튼은 앞으로 해당 계획이 보이지 않도록 설정하는 동작입니다. 기존 실제 거래는 삭제되지 않습니다. 현재 버전은 비활성화한 계획의 과거 예정 목록을 보존해서 표시하는 기능까지는 없습니다.

## 오프라인 검증 재현

JDK+Kotlin CLI+Python3가 있는 환경에서 다음을 실행합니다:

```bash
bash verification/verify_local.sh
bash verification/typecheck_data_backup.sh
```

이 두 검증은 Android SDK가 필요하지 않지만 APK 빌드와 데이터베이스 생성 테스트를 대신하지 않습니다. 프로젝트의 Android 관련 의존성은 CLI 스텁 검사에서 실제로 평가하지 않았습니다.

## 보안과 남은 미구현

- JSON 및 CSV 백업 **평문**. 잠금/생체인증/암호화 미구현이므로 실제 민감정보를 대량 넣지 마세요.
- 삼성월렛 티머니의 비공개 내부 데이터는 읽지 않습니다. 교통비는 일별 실제 확인과 이용기간 총액 대조 방식. 청구액 재합산 방지.
- SMS 직접 읽기, 금융계좌 직접 연결, 외부 인터넷 전송은 구현하지 않았습니다.
- 미완료: Android 전체 컴파일/실기기 검증, Room MigrationTestHelper 테스트, 반복계획 수정 UI·계획 종료월 관리, 자동 고정지출 원결제 대조, 환불 원거래 연결, 태그/카테고리 전체 CRUD, 암호화/생체잠금, 다른 위젯과 폴드8 실기기 QA, 전체 백업 실물 복원 테스트, 직접 XLSX 내보내기.

참고: 정기 관리 화면에서 동일 계획·예정월·실제 날짜·금액의 수동 확정 거래를 다시 저장하면 중복 키 때문에 두 번째 저장은 무시하도록 설계했습니다. 서로 다른 실거래인데 조건이 완전히 같은 경우에는 일반 수입/지출 화면에 수동 기록 후 해당 계획을 연결해야 합니다. 이 중복 방지 동작은 Android Room 통합 테스트를 아직 수행하지 않았습니다.
