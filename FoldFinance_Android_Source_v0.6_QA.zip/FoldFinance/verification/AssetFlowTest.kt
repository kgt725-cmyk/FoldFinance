import kr.personal.foldfinance.domain.*
import java.time.LocalDate

fun main() {
    fun d(s: String) = LocalDate.parse(s)
    var n = 0
    fun check(v: Boolean, desc: String) { require(v) { "FAIL: $desc" }; n++ }
    val accounts = listOf(AssetOpening(1, "통장", "BANK", d("2026-10-01"), 5_000_000, true),
                          AssetOpening(2, "주식", "STOCK", d("2026-10-01"), 1_000_000, true))
    val postings = listOf(
        AssetPosting(d("2026-10-15"), "INCOME", 2_400_000, "CONFIRMED", 1, null),
        AssetPosting(d("2026-10-16"), "SAVING", 1_400_000, "CONFIRMED", 1, 2),
        AssetPosting(d("2026-10-17"), "EXPENSE", 100_000, "CONFIRMED", 1, null),
        AssetPosting(d("2026-10-18"), "EXPENSE", -20_000, "CONFIRMED", 1, null),
        AssetPosting(d("2026-10-19"), "KPASS_REBATE", 15_000, "CONFIRMED", 1, null),
        AssetPosting(d("2026-10-19"), "EXPENSE", 50_000, "REVIEW", 1, null),
        AssetPosting(d("2026-10-20"), "INCOME", 30_000, "EXPECTED", 1, null)
    )
    val transfers = listOf(AssetTransferPosting(d("2026-10-20"), 2, 1, 100_000))
    val adj = listOf(AssetAdjustmentPosting(d("2026-10-20"), 2, 50_000))
    val v = AssetFlow.calculate(accounts, postings, transfers, adj, d("2026-10-21"))
    check(v.positions[0].balance == 6_035_000L, "cash balance after income, saving, spending, refund, rebate, transfer")
    check(v.positions[1].balance == 2_350_000L, "stock after saving, transfer, valuation")
    check(v.total == 8_385_000L, "asset total; savings and internal transfers zero-sum")
    check(v.liquid == 6_035_000L, "liquid excludes stocks")
    check(v.unassignedConfirmedCount == 0, "all confirmed linked")
    val before = AssetFlow.calculate(accounts, postings, transfers, adj, d("2026-10-18"))
    check(before.total == 8_320_000L, "as-of excludes later events")
    val unlinked = AssetFlow.calculate(accounts, postings + AssetPosting(d("2026-10-19"), "EXPENSE", 25000, "CONFIRMED", null, null), transfers, adj, d("2026-10-21"))
    check(unlinked.total == v.total && unlinked.unassignedConfirmedCount == 1, "unlinked spending not guessed")
    val incompleteSaving = AssetFlow.calculate(accounts, postings + AssetPosting(d("2026-10-19"), "SAVING", 500_000, "CONFIRMED", 1, null), transfers, adj, d("2026-10-21"))
    check(incompleteSaving.total == v.total && incompleteSaving.unassignedConfirmedCount == 1, "incomplete saving does not create phantom values")
    val old = AssetFlow.calculate(accounts, listOf(AssetPosting(d("2026-09-30"), "INCOME", 300_000, "CONFIRMED", 1, null)), emptyList(), emptyList(), d("2026-10-21"))
    check(old.total == 6_000_000L, "opening date excludes historical entry")
    val futureAccount = AssetFlow.calculate(listOf(AssetOpening(3, "미래 계좌", "BANK", d("2026-10-22"), 500_000, true)), emptyList(), emptyList(), emptyList(), d("2026-10-21"))
    check(futureAccount.total == 0L, "future opening excluded from past overview")
    check(AssetFlow.isLiquid("CASH") && !AssetFlow.isLiquid("HOUSING"), "asset liquidity")
    val win = FinancePeriod.of(d("2026-10-19"), WindowMode.PAYDAY)
    val totals = FinanceMath.totals(postings.map { FinancialEntry(it.date, it.kind, it.amount, it.status) }, win)
    check(totals.income == 2_415_000L && totals.rebate == 15_000L, "rebate included in income once")
    check(totals.remainingAfterSpending == 935_000L, "cash flow no doubled rebate")
    check(totals.expense == 80_000L && totals.savings == 1_400_000L, "savings and spending remain separate")
    val predictedRefund = AssetPosting(d("2026-10-19"), "KPASS_REBATE", 18_000L, "EXPECTED", 1, null)
    val predictedBalance = AssetFlow.calculate(accounts, postings + predictedRefund, transfers, adj, d("2026-10-21"))
    check(predictedBalance.total == v.total, "anticipated K-PASS refund does not increase assets")
    val predictedTotals = FinanceMath.totals((postings + predictedRefund).map { FinancialEntry(it.date, it.kind, it.amount, it.status) }, win)
    check(predictedTotals.income == totals.income, "anticipated K-PASS refund is not realized income")
    println("PASS: $n asset and K-PASS business logic tests")
}
