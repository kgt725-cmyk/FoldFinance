import kr.personal.foldfinance.domain.*
import java.time.LocalDate

fun main() {
    fun d(s: String) = LocalDate.parse(s)
    var checked = 0
    fun verify(ok: Boolean, message: String) { if(!ok) error("FAIL: $message"); checked++ }

    val pay = FinancePeriod.of(d("2026-10-19"), WindowMode.PAYDAY, 15)
    verify(pay.start == d("2026-10-15") && pay.endExclusive == d("2026-11-15"), "급여 주기 기본")
    verify(!pay.contains(d("2026-11-15")) && pay.contains(d("2026-11-14")), "경계에 중복 없음")
    val dec = FinancePeriod.of(d("2026-12-30"), WindowMode.PAYDAY, 15)
    verify(dec.start == d("2026-12-15") && dec.endExclusive == d("2027-01-15"), "연도 경계")
    verify(FinancePeriod.of(d("2026-10-14"), WindowMode.PAYDAY, 15).start == d("2026-09-15"), "급여일 전날")
    verify(FinancePeriod.of(d("2026-10-19"), WindowMode.MONTH).start == d("2026-10-01"), "달력 월")
    verify(FinancePeriod.of(d("2026-10-19"), WindowMode.YEAR).endExclusive == d("2027-01-01"), "달력 연간")

    val entries = listOf(
        FinancialEntry(d("2026-10-15"), "INCOME", 2_400_000),
        FinancialEntry(d("2026-10-16"), "SAVING", 1_400_000),
        FinancialEntry(d("2026-10-17"), "EXPENSE", 125_000),
        FinancialEntry(d("2026-10-18"), "EXPENSE", -20_000),
        FinancialEntry(d("2026-10-18"), "KPASS_REBATE", 5_000),
        FinancialEntry(d("2026-10-18"), "EXPENSE", 10_000, "REVIEW"),
        FinancialEntry(d("2026-10-21"), "EXPENSE", 15_000, "EXPECTED"),
        FinancialEntry(d("2026-11-15"), "EXPENSE", 17_000)
    )
    val sum = FinanceMath.totals(entries, pay)
    verify(sum.income == 2_405_000L && sum.savings == 1_400_000L, "실제 수입 저축")
    verify(sum.expense == 105_000L, "취소 환불 차감")
    verify(sum.rebate == 5_000L, "K패스 별도 집계")
    verify(sum.remainingAfterSpending == 900_000L, "환급 포함 수입-저축-지출")
    verify(FinanceMath.availableBudget(1_000_000, sum.expense) == 895_000L, "예산 잔액")
    verify(FinanceMath.suggestedDailyBudget(120_000, 6) == 20_000L, "일일 예산")
    verify(FinanceMath.percent(350_000, 1_400_000) == 25, "저축 목표 달성")

    val wk = DateWindow(d("2026-10-19"), d("2026-10-26"))
    val rides = TransportMath.projectedDays(
        wk, 31, 1_500, 2, mapOf(d("2026-10-20") to false, d("2026-10-24") to true),
        mapOf(d("2026-10-19") to 2_900L)
    )
    verify(rides.size == 7, "일별 계획 생성")
    verify(rides.first().status == "CONFIRMED" && rides.first().actual == 2_900L, "실제 확정 우선")
    verify(rides[1].planned == 0L, "휴무 반영")
    verify(rides[5].planned == 3_000L, "주말 추가출근")
    verify(TransportMath.confirmedTotal(rides) == 2_900L, "확정 운임 합")
    verify(TransportMath.expectedUnconfirmed(rides) == 12_000L, "미확정 예상 따로")
    verify(TransportMath.projectedTotal(rides) == 14_900L, "확정 + 미확정 예상")
    verify(TransportMath.netFare(10_000, 2_000) == 8_000L, "K패스 실질 교통비")
    verify(ScheduleMatch.score(900, 840, 1320, true) == 65, "일정 내 음식점 거래 추천")
    verify(ScheduleMatch.score(800, 840, 1320, true) == 0, "일정 외 거래 제외")

    val n = BankNoticeParser.parse("[KB카드] 12,000원 승인\n가맹점: 스타벅스")
    verify(n?.amount == 12_000L && n.merchant == "스타벅스", "명시된 가맹점 알림 파싱")
    verify(BankNoticeParser.parse("카드 대금 청구서 12000원 승인 가맹점:은행") == null, "청구 알림 중복 차단")
    verify(BankNoticeParser.parse("12000원 승인") == null, "가맹점 누락은 추측하지 않음")
    verify(BankNoticeParser.parse("[KB카드] 5,000원 승인취소\n가맹점:카페")?.amount == -5000L, "취소 음수")

    verify(FinancePeriod.of(d("2027-01-02"), WindowMode.PAYDAY, 15).start == d("2026-12-15"), "1월 초 연말 급여주기")
    verify(FinancePeriod.of(d("2026-11-14"), WindowMode.PAYDAY, 15, 1).start == d("2026-11-15"), "주기 이동")
    verify(FinancePeriod.of(d("2026-10-19"), WindowMode.MONTH, 15, -1).start == d("2026-09-01"), "지난달 이동")
    verify(FinancePeriod.of(d("2026-10-19"), WindowMode.YEAR, 15, 1).start == d("2027-01-01"), "다음 연간 이동")
    verify(FinanceMath.totals(entries, FinancePeriod.of(d("2026-11-15"), WindowMode.PAYDAY, 15)).expense == 17_000L, "다음 주기의 거래만")
    verify(FinanceMath.percent(0, 0) == 0, "목표 0 나누기 방지")
    verify(FinanceMath.suggestedDailyBudget(-300L, 5) == 0L, "초과 예산 음수 권장 방지")
    verify(TransportMath.projectedDays(wk, 31, 1500, 2, emptyMap(), emptyMap(), d("2026-10-26"))[0].status == "NEEDS_REVIEW", "지나간 예상 교통비 확인 필요")
    verify(BankNoticeParser.parse("[KB카드] 7,000원 후불교통 승인\n가맹점:티머니") == null, "교통 후불 청구 차단")
    println("PASS: $checked pure Kotlin checks")
}
