#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
kotlinc verification/stubs/*.kt \
  app/src/main/java/kr/personal/foldfinance/data/{Entities,FinanceBackup}.kt \
  app/src/main/java/kr/personal/foldfinance/domain/{FinanceLogic,RecurringLogic,AssetFlow}.kt \
  -d "$TMP/typecheck.jar"
echo "PASS: entity and backup type check with Android/JSON stand-ins (NOT an Android build)"
