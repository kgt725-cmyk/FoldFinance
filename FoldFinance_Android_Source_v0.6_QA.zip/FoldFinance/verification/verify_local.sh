#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT
BASE=app/src/main/java/kr/personal/foldfinance/domain
kotlinc "$BASE/FinanceLogic.kt" "$BASE/BankNoticeParser.kt" verification/FinanceLogicTest.kt -include-runtime -d "$TEMP_DIR/finance.jar"
java -jar "$TEMP_DIR/finance.jar"
kotlinc "$BASE/FinanceLogic.kt" "$BASE/TransitReconciliation.kt" verification/TransitReconcileTest.kt -include-runtime -d "$TEMP_DIR/transit.jar"
java -jar "$TEMP_DIR/transit.jar"
kotlinc "$BASE/MerchantRules.kt" verification/MerchantRulesTest.kt -include-runtime -d "$TEMP_DIR/rules.jar"
java -jar "$TEMP_DIR/rules.jar"
kotlinc "$BASE/EventExpenseMatcher.kt" verification/EventExpenseMatcherTest.kt -include-runtime -d "$TEMP_DIR/events.jar"
java -jar "$TEMP_DIR/events.jar"
kotlinc "$BASE/NotificationIdentity.kt" verification/NotificationIdentityTest.kt -include-runtime -d "$TEMP_DIR/notifications.jar"
java -jar "$TEMP_DIR/notifications.jar"
python3 verification/sqlite_migration_check.py
python3 verification/sqlite_migration_v3_check.py
python3 - <<'PY'
from pathlib import Path
from xml.etree import ElementTree as ET
p = Path('app/src/main')
files = [p/'AndroidManifest.xml', *list((p/'res').rglob('*.xml'))]
for file in files:
    ET.parse(file)
print(f'PASS: {len(files)} Android XML file parse checks')
PY
kotlinc "$BASE/FinanceLogic.kt" "$BASE/RecurringLogic.kt" verification/RecurringLogicTest.kt -include-runtime -d "$TEMP_DIR/recurring.jar"
java -jar "$TEMP_DIR/recurring.jar"
python3 verification/sqlite_migration_v4_check.py
kotlinc "$BASE/FinanceLogic.kt" "$BASE/LedgerAudit.kt" verification/LedgerAuditTest.kt -include-runtime -d "$TEMP_DIR/audit.jar"
java -jar "$TEMP_DIR/audit.jar"

kotlinc "$BASE/FinanceLogic.kt" "$BASE/AssetFlow.kt" verification/AssetFlowTest.kt -include-runtime -d "$TEMP_DIR/asset.jar"
java -jar "$TEMP_DIR/asset.jar"
python3 verification/sqlite_migration_v5_check.py
