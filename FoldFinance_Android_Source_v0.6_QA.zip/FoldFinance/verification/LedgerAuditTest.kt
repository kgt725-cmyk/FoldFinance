import kr.personal.foldfinance.domain.*
import java.time.LocalDate

fun main() {
    var n = 0
    fun ok(condition: Boolean, name: String) { check(condition) { name }; n++ }
    val base = AuditTransaction(1, "2026-10-19", "EXPENSE", 12000, "CONFIRMED", "식비", "k-1", null, 7, 9, "2026-10")
    val ev = listOf(AuditEvent(7, "2026-10-19"))
    val pl = listOf(AuditPlan(9, "EXPENSE"))
    val valid = LedgerAudit.check(listOf(base), ev, pl)
    ok(valid.findings.isEmpty(), "정상 거래")
    ok(valid.transactionCount == 1 && valid.confirmedCount == 1 && valid.pendingCount == 0, "확정 카운트")
    ok(LedgerAudit.check(listOf(base.copy(status = "REVIEW")), ev, pl).pendingCount == 1, "검토 분리")
    ok(LedgerAudit.check(listOf(base, base.copy(id=2)), ev, pl).findings.any { it.title.contains("알림 중복") }, "알림 중복")
    ok(LedgerAudit.check(listOf(base.copy(id=3, transitDate="2026-10-19"), base.copy(id=4, transitDate="2026-10-19")), ev, pl).findings.any { it.title.contains("교통비 날짜 중복") }, "교통비 중복")
    ok(LedgerAudit.check(listOf(base.copy(date="2026-10-20")), ev, pl).findings.any { it.title == "일정 연결 오류" }, "일정 날짜 불일치")
    ok(LedgerAudit.check(listOf(base.copy(linkedRecurringId=999)), ev, pl).findings.any { it.title == "정기 계획 연결 오류" }, "계획 유실")
    ok(LedgerAudit.check(listOf(base.copy(linkedPlanMonth="2026-13")), ev, pl).findings.any { it.title == "정기 계획 연결 오류" }, "계획월 오류")
    ok(LedgerAudit.check(listOf(base.copy(amount=-5000,kind="INCOME",linkedEventId=null,linkedRecurringId=null,linkedPlanMonth=null)), ev, pl).findings.any { it.title == "금액 부호 오류" }, "수입 음수 거절")
    ok(LedgerAudit.check(listOf(base.copy(date="2026-19-50",linkedEventId=null,linkedRecurringId=null,linkedPlanMonth=null)), ev, pl).findings.any { it.title == "날짜 형식 오류" }, "날짜 유효성")
    ok(LedgerAudit.check(listOf(base.copy(amount=0,linkedEventId=null,linkedRecurringId=null,linkedPlanMonth=null)), ev, pl).findings.any { it.title == "금액 0원" }, "비교통 0원")
    ok(LedgerAudit.check(listOf(base.copy(amount=0,transitDate=base.date,linkedEventId=null,linkedRecurringId=null,linkedPlanMonth=null)), ev, pl).findings.isEmpty(), "교통 0원 허용")
    ok(FinanceMath.periodTarget(1_000_000, WindowMode.PAYDAY) == 1_000_000L, "급여 기준 월 예산")
    ok(FinanceMath.periodTarget(1_000_000, WindowMode.MONTH) == 1_000_000L, "달력 기준 월 예산")
    ok(FinanceMath.periodTarget(1_000_000, WindowMode.YEAR) == 12_000_000L, "연간 생활비 예산")
    ok(FinanceMath.periodTarget(1_400_000, WindowMode.YEAR) == 16_800_000L, "연간 저축 목표")
    ok(FinanceMath.availableBudget(FinanceMath.periodTarget(1_000_000,WindowMode.YEAR),1_800_000)==10_200_000L, "연간 잔여액")
    ok(FinanceMath.totals(listOf(FinancialEntry(LocalDate.parse("2026-10-19"),"EXPENSE",10_000,"REVIEW")),
        FinancePeriod.of(LocalDate.parse("2026-10-19"),WindowMode.PAYDAY)).expense == 0L,"미확정 제외")
    println("PASS: $n audit & period checks")
}
