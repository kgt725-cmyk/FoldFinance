"""SQLite simulation with actual MIGRATION_4_5 statements (not Room generated-schema test)."""
import sqlite3, re
from pathlib import Path
source = (Path(__file__).resolve().parents[1]/'app/src/main/java/kr/personal/foldfinance/data/FinanceDatabase.kt').read_text()
section = source.split('val MIGRATION_4_5',1)[1].split('@Volatile',1)[0]
statements = re.findall(r'db\.execSQL\("([^"\n]+)"\)', section)
statements += [s.strip() for s in re.findall(r'db\.execSQL\("""(.*?)"""\.trimIndent\(\)\)', section,re.S)]
assert len(statements) == 6, statements
conn = sqlite3.connect(':memory:')
conn.execute('''CREATE TABLE ledger(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,kind TEXT NOT NULL,amount INTEGER NOT NULL,date TEXT NOT NULL,category TEXT NOT NULL,merchant TEXT NOT NULL,memo TEXT NOT NULL,status TEXT NOT NULL,source TEXT NOT NULL,dedupeKey TEXT,transitDate TEXT,workMonth TEXT,createdAt INTEGER NOT NULL,tags TEXT NOT NULL,occurredAtTime TEXT,linkedEventId INTEGER,linkedRecurringId INTEGER,linkedPlanMonth TEXT)''')
conn.execute("INSERT INTO ledger (id,kind,amount,date,category,merchant,memo,status,source,createdAt,tags) VALUES (11,'INCOME',2400000,'2026-10-15','급여','','','CONFIRMED','MANUAL',1,'')")
n=0
def check(result, name):
    global n
    assert result,name
    n+=1
for stmt in statements: conn.execute(stmt)
cols = [x[1] for x in conn.execute('PRAGMA table_info(ledger)')]
check(cols[-3:] == ['accountId','destinationAccountId','rebateForMonth'],'added 3 columns')
check(conn.execute('SELECT amount FROM ledger WHERE id=11').fetchone()[0] == 2400000,'old ledger kept')
check(conn.execute('SELECT accountId FROM ledger WHERE id=11').fetchone()[0] is None,'old refs nullable')
for table in ('asset_accounts','asset_transfers','asset_adjustments'):
    check(conn.execute(f'SELECT count(*) FROM {table}').fetchone()[0]==0, f'empty {table}')
conn.execute("INSERT INTO asset_accounts(id,name,type,openingDate,openingBalance,active) VALUES(1,'통장','BANK','2026-10-19',500000,1)")
conn.execute("INSERT INTO asset_accounts(id,name,type,openingDate,openingBalance,active) VALUES(2,'주식','STOCK','2026-10-19',400000,1)")
conn.execute("INSERT INTO asset_transfers(id,date,sourceAccountId,destinationAccountId,amount,memo) VALUES(1,'2026-10-20',1,2,10000,'')")
conn.execute("INSERT INTO asset_adjustments(id,date,accountId,amountDelta,reason,memo) VALUES(1,'2026-10-20',2,12000,'VALUATION','')")
check(conn.execute('SELECT sum(openingBalance) FROM asset_accounts').fetchone()[0] == 900000,'opening assets')
check(conn.execute('SELECT amountDelta FROM asset_adjustments').fetchone()[0] == 12000,'adjustment')
check(conn.execute('SELECT count(*) FROM asset_transfers').fetchone()[0] == 1,'transfer')
check(conn.execute('PRAGMA integrity_check').fetchone()[0] == 'ok','integrity')
print(f'PASS: {n} v4→v5 SQLite migration example checks')
