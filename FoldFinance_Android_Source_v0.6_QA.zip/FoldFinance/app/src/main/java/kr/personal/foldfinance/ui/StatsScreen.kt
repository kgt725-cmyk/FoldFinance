package kr.personal.foldfinance.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kr.personal.foldfinance.data.FinanceSettings
import kr.personal.foldfinance.data.LedgerEntry
import kr.personal.foldfinance.domain.*

@Composable
private fun StatsBar(name: String, amount: Long, maxAmount: Long, color: Color) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row {
            Text(name, Modifier.weight(1f), fontSize = 12.sp)
            Text(formatWon(amount), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { (amount.toFloat() / maxAmount.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f) },
            color = color, trackColor = LightBg, modifier = Modifier.fillMaxWidth().height(8.dp)
        )
    }
}

@Composable
internal fun StatsPage(ledger: List<LedgerEntry>, totals: Totals, s: FinanceSettings, window: DateWindow, openPage: (String) -> Unit) {
    val confirmed = ledger.filter { it.status in listOf("CONFIRMED", "SETTLED") && tryDate(it.date)?.let(window::contains) == true }
    val expenseGroups = confirmed.filter { it.kind == "EXPENSE" }.groupBy { it.category }.mapValues { (_, records) -> records.sumOf { it.amount } }
        .toList().sortedByDescending { it.second }
    val savingGroups = confirmed.filter { it.kind == "SAVING" }.groupBy { it.category }.mapValues { (_, records) -> records.sumOf { it.amount } }
        .toList().sortedByDescending { it.second }
    val nextMonths = (12 - window.start.monthValue).coerceAtLeast(0)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(15.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("기간별 확정 실적", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Metric("수입", formatWon(totals.income), Blue)
            Spacer(Modifier.height(9.dp))
            Metric("저축", formatWon(totals.savings), Green, "선택 기간 목표 ${formatWon(FinanceMath.periodTarget(s.savingsGoal, if (window.days() > 32) WindowMode.YEAR else WindowMode.MONTH))}")
            Spacer(Modifier.height(9.dp))
            Metric("지출", formatWon(totals.expense), Pink, "K-패스 실제 환급 ${formatWon(totals.rebate)}는 수입에 포함")
        }
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("카테고리별 지출", fontWeight = FontWeight.Bold)
            if(expenseGroups.isEmpty()) Text("확정 지출 내역 없음", fontSize = 12.sp)
            expenseGroups.forEach { (name, amount) -> StatsBar(name, amount, expenseGroups.maxOf { it.second }, Pink) }
        }
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("일정·태그 소비 (별도 집계, 전체 지출에 중복 합산하지 않음)", fontWeight = FontWeight.Bold)
            val dateTagged = confirmed.filter { it.kind == "EXPENSE" && it.tags.split(',').any { tag -> tag.trim() == "데이트" } }
            val eventLinked = confirmed.filter { it.kind == "EXPENSE" && it.linkedEventId != null }
            Text("#데이트 태그 사용 ${formatWon(dateTagged.sumOf { it.amount })} · ${dateTagged.size}건", fontSize = 13.sp)
            Text("일정 연결된 거래 ${formatWon(eventLinked.sumOf { it.amount })} · ${eventLinked.size}건", fontSize = 13.sp)
            Text("한 거래가 두 집계에 동시에 표시될 수 있으나 전체 지출 합계에는 한 번만 포함됩니다.", fontSize = 11.sp, color = Color.Gray)
        }
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("카테고리별 저축", fontWeight = FontWeight.Bold)
            if(savingGroups.isEmpty()) Text("확정 저축 내역 없음", fontSize = 12.sp)
            savingGroups.forEach { (name, amount) -> StatsBar(name, amount, savingGroups.maxOf { it.second }, Green) }
        }
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("단순 저축 목표 예측", fontWeight = FontWeight.Bold)
            Text("1년 목표 ${formatWon(s.savingsGoal * 12)}", fontSize = 13.sp)
            Text("3년 목표 ${formatWon(s.savingsGoal * 36)} · 5년 목표 ${formatWon(s.savingsGoal * 60)}", fontSize = 13.sp)
            Text("실제 납입 실적과 별개입니다. 월 목표를 그대로 달성한다는 가정이며 투자 수익률은 0%로 가정합니다.", color = Color.Gray, fontSize = 11.sp)
        }
        Spacer(Modifier.height(18.dp))
    }
}
