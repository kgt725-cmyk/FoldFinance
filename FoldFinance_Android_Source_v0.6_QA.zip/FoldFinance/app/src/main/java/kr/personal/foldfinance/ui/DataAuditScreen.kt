package kr.personal.foldfinance.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kr.personal.foldfinance.data.CalendarEvent
import kr.personal.foldfinance.data.LedgerEntry
import kr.personal.foldfinance.data.RecurringPlan
import kr.personal.foldfinance.domain.*

@Composable
internal fun DataAuditPage(
    records: List<LedgerEntry>, events: List<CalendarEvent>, plans: List<RecurringPlan>,
    window: DateWindow, totals: Totals
) {
    val audit = LedgerAudit.check(
        records.map { e -> AuditTransaction(
            e.id, e.date, e.kind, e.amount, e.status, e.category,
            e.dedupeKey, e.transitDate, e.linkedEventId, e.linkedRecurringId, e.linkedPlanMonth
        ) },
        events.map { AuditEvent(it.id, it.date) },
        plans.map { AuditPlan(it.id, it.kind) }
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("로컬 기록 정합성 점검", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Text("기록 삭제·수정 없이 읽기만 합니다. 이 점검이 통과해도 모든 실제 거래의 정확성을 보장하지는 않습니다.", fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Text("전체 거래 ${audit.transactionCount}건 · 확정 ${audit.confirmedCount}건 · 확인 대기 ${audit.pendingCount}건", fontSize = 13.sp)
            Text(if (audit.findings.isEmpty()) "기본 구조 점검: 특이사항 없음" else "점검 필요 항목 ${audit.findings.size}건",
                color = if (audit.findings.isEmpty()) Green else Pink, fontWeight = FontWeight.SemiBold)
        }
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("현재 선택 기간 집계", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("${window.start} ~ ${window.endExclusive.minusDays(1)}", fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            Text("확정 수입  ${formatWon(totals.income)}", fontSize = 13.sp)
            Text("확정 저축  ${formatWon(totals.savings)}", fontSize = 13.sp)
            Text("확정 지출  ${formatWon(totals.expense)}", fontSize = 13.sp)
            Text("K-패스 환급  ${formatWon(totals.rebate)}", fontSize = 13.sp)
            Text("예정·검토 거래는 확정 합계에서 제외됩니다.", fontSize = 11.sp)
        }
        audit.findings.take(30).forEach { finding ->
            RoundedCard(Modifier.fillMaxWidth()) {
                Text(finding.title, color = Pink, fontWeight = FontWeight.Medium)
                Text(finding.detail, fontSize = 12.sp)
            }
        }
        if (audit.findings.size > 30) Text("추가 점검 항목 ${audit.findings.size - 30}건은 표시를 생략했습니다.", fontSize = 11.sp)
        Spacer(Modifier.height(20.dp))
    }
}
