package kr.personal.foldfinance.domain

/** 앱 내부 기록 정합성 점검. 데이터 삭제·수정을 하지 않는 읽기 전용 규칙. */
data class AuditTransaction(
    val id: Long, val date: String, val kind: String, val amount: Long, val status: String,
    val category: String, val dedupeKey: String?, val transitDate: String?,
    val linkedEventId: Long?, val linkedRecurringId: Long?, val linkedPlanMonth: String?
)
data class AuditEvent(val id: Long, val date: String)
data class AuditPlan(val id: Long, val kind: String)
data class AuditFinding(val title: String, val detail: String)
data class AuditReport(
    val transactionCount: Int,
    val confirmedCount: Int,
    val pendingCount: Int,
    val findings: List<AuditFinding>
)

object LedgerAudit {
    fun check(records: List<AuditTransaction>, events: List<AuditEvent>, plans: List<AuditPlan>): AuditReport {
        val findings = mutableListOf<AuditFinding>()
        val eventById = events.associateBy { it.id }
        val planById = plans.associateBy { it.id }
        val duplicateIds = records.groupBy { it.id }.filter { (id, list) -> id > 0 && list.size > 1 }
        if (duplicateIds.isNotEmpty()) findings += AuditFinding("거래 식별자 중복", "${duplicateIds.size}개 거래 ID")
        for ((name, values) in listOf(
            "알림 중복 키" to records.mapNotNull { it.dedupeKey?.takeIf(String::isNotBlank) },
            "교통비 날짜" to records.mapNotNull { it.transitDate?.takeIf(String::isNotBlank) }
        )) {
            val duplicates = values.groupingBy { it }.eachCount().count { it.value > 1 }
            if (duplicates > 0) findings += AuditFinding("$name 중복", "중복 값 ${duplicates}개")
        }
        for (e in records) {
            val prefix = "거래 ${e.id} (${e.date})"
            if (tryDate(e.date) == null) findings += AuditFinding("날짜 형식 오류", prefix)
            if (e.kind !in setOf("INCOME", "SAVING", "EXPENSE", "KPASS_REBATE"))
                findings += AuditFinding("거래 종류 오류", prefix)
            if (e.status !in setOf("EXPECTED", "REVIEW", "CONFIRMED", "SETTLED"))
                findings += AuditFinding("상태 오류", prefix)
            if (e.category.isBlank()) findings += AuditFinding("카테고리 없음", prefix)
            if (e.amount < 0 && e.kind != "EXPENSE") findings += AuditFinding("금액 부호 오류", prefix)
            if (e.amount == 0L && !(e.kind == "EXPENSE" && e.transitDate != null))
                findings += AuditFinding("금액 0원", prefix)
            if (e.transitDate != null && (e.kind != "EXPENSE" || e.date != e.transitDate))
                findings += AuditFinding("교통비 날짜 연결 오류", prefix)
            if (e.linkedEventId != null) {
                val linked = eventById[e.linkedEventId]
                if (e.kind != "EXPENSE" || linked == null || linked.date != e.date)
                    findings += AuditFinding("일정 연결 오류", prefix)
            }
            if (e.linkedRecurringId != null || e.linkedPlanMonth != null) {
                val linked = e.linkedRecurringId?.let(planById::get)
                val monthValid = e.linkedPlanMonth?.matches(Regex("\\d{4}-(0[1-9]|1[0-2])")) == true
                if (linked == null || linked.kind != e.kind || !monthValid)
                    findings += AuditFinding("정기 계획 연결 오류", prefix)
            }
        }
        return AuditReport(
            transactionCount = records.size,
            confirmedCount = records.count { it.status == "CONFIRMED" || it.status == "SETTLED" },
            pendingCount = records.count { it.status == "EXPECTED" || it.status == "REVIEW" },
            findings = findings
        )
    }
}
