package kr.personal.foldfinance.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kr.personal.foldfinance.domain.tryDate
import kr.personal.foldfinance.domain.MerchantCategorizer
import kr.personal.foldfinance.domain.RecurringMath
import kr.personal.foldfinance.widget.BudgetWidget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FinanceViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = FinanceDatabase.get(application).dao()
    private val settingsStore = SettingsStore(application)
    val entries: Flow<List<LedgerEntry>> = dao.watchLedger()
    val events: Flow<List<CalendarEvent>> = dao.watchEvents()
    val overrides: Flow<List<WorkdayOverride>> = dao.watchOverrides()
    val bills: Flow<List<TransitBill>> = dao.watchBills()
    val statements: Flow<List<TransitStatement>> = dao.watchStatements()
    val rules: Flow<List<MerchantRule>> = dao.watchRules()
    val plans: Flow<List<RecurringPlan>> = dao.watchPlans()
    val accounts: Flow<List<AssetAccount>> = dao.watchAccounts()
    val transfers: Flow<List<AssetTransfer>> = dao.watchTransfers()
    val adjustments: Flow<List<AssetAdjustment>> = dao.watchAdjustments()
    val settings: Flow<FinanceSettings> = settingsStore.state

    private fun execute(block: suspend () -> Unit) = viewModelScope.launch(Dispatchers.IO) {
        block()
        BudgetWidget.updateAll(getApplication())
    }

    fun addEntry(entry: LedgerEntry) = execute {
        require(tryDate(entry.date) != null && entry.amount != 0L)
        validateAccountsForEntry(entry)
        dao.insertLedger(entry)
    }
    fun setStatus(entry: LedgerEntry, status: String) = execute { dao.updateLedger(entry.copy(status = status)) }
    fun updateEntry(entry: LedgerEntry) = execute { validateAccountsForEntry(entry); dao.updateLedger(entry) }
    private suspend fun validateAccountsForEntry(entry: LedgerEntry) {
        val accounts = dao.allAccounts().associateBy { it.id }
        listOfNotNull(entry.accountId, entry.destinationAccountId).forEach { id ->
            val account = requireNotNull(accounts[id]) { "없는 자산 계좌입니다." }
            require(entry.date >= account.openingDate) { "잔액 기준일 이전 거래를 연결할 수 없습니다." }
        }
        require(entry.destinationAccountId == null || (entry.kind == "SAVING" && entry.accountId != entry.destinationAccountId))
    }
    fun deleteEntry(id: Long) = execute { dao.deleteLedger(id) }
    fun addEvent(e: CalendarEvent) = execute { dao.insertEvent(e) }
    fun deleteEvent(id: Long) = execute { dao.deleteEvent(id) }
    fun overrideDay(date: String, workday: Boolean?) = execute {
        if (workday == null) dao.deleteOverride(date)
        else dao.putOverride(WorkdayOverride(date, workday))
    }
    fun confirmTransitDay(date: String, amount: Long, accountId: Long? = null) = execute {
        require(amount >= 0)
        val old = dao.transitOn(date)
        if (old != null) dao.updateLedger(old.copy(amount = amount, status = "CONFIRMED", accountId = accountId ?: old.accountId))
        else dao.insertLedger(LedgerEntry(
            kind = "EXPENSE", amount = amount, date = date, category = "교통", merchant = "티머니 후불교통",
            memo = "실제 이용내역 확인 · 해당일 합계", status = "CONFIRMED", source = "TRANSIT_MANUAL", transitDate = date, accountId = accountId
        ))
    }
    fun addAccount(account: AssetAccount) = execute {
        require(account.name.isNotBlank() && account.type in kr.personal.foldfinance.domain.AssetFlow.accountTypes)
        require(tryDate(account.openingDate) != null && account.openingBalance >= 0)
        dao.insertAccount(account)
    }
    fun setAccountActive(id: Long, active: Boolean) = execute { dao.setAccountActive(id, active) }
    fun addAssetTransfer(t: AssetTransfer) = execute {
        require(t.amount > 0 && t.sourceAccountId != t.destinationAccountId && tryDate(t.date) != null)
        val ids = dao.allAccounts().map { it.id }.toSet()
        require(t.sourceAccountId in ids && t.destinationAccountId in ids)
        val accounts = dao.allAccounts().associateBy { it.id }
        require(t.date >= accounts.getValue(t.sourceAccountId).openingDate &&
                t.date >= accounts.getValue(t.destinationAccountId).openingDate) { "이체일은 두 자산의 잔액 기준일 이후여야 합니다." }
        dao.insertTransfer(t)
    }
    fun deleteAssetTransfer(id: Long) = execute { dao.deleteTransfer(id) }
    fun addAssetAdjustment(a: AssetAdjustment) = execute {
        require(a.amountDelta != 0L && a.reason in setOf("VALUATION", "CORRECTION") && tryDate(a.date) != null)
        require(dao.allAccounts().any { it.id == a.accountId && a.date >= it.openingDate })
        dao.insertAdjustment(a)
    }
    fun deleteAssetAdjustment(id: Long) = execute { dao.deleteAdjustment(id) }
    fun addBill(b: TransitBill) = execute { dao.insertBill(b) }
    fun putRule(rawMerchant: String, category: String, tags: String, autoConfirm: Boolean) = execute {
        val key = MerchantCategorizer.key(rawMerchant)
        require(key.length in 2..100 && category.isNotBlank())
        dao.putRule(MerchantRule(key, category.trim(), tags.split(',').map { it.trim().removePrefix("#") }
            .filter { it.isNotBlank() }.distinct().joinToString(","), autoConfirm))
    }
    fun deleteRule(key: String) = execute { dao.deleteRule(key) }
    fun addPlan(plan: RecurringPlan) = execute {
        require(plan.kind in setOf("INCOME", "EXPENSE") && plan.title.isNotBlank() && plan.category.isNotBlank())
        require(plan.amount > 0 && plan.dayOfMonth in 1..28 && RecurringMath.validMonth(plan.startMonth))
        dao.insertPlan(plan)
    }
    fun setPlanActive(id: Long, active: Boolean) = execute { dao.setPlanActive(id, active) }
    fun addStatement(s: TransitStatement) = execute {
        require(tryDate(s.startDate) != null && tryDate(s.endDate) != null && s.endDate >= s.startDate && s.amount >= 0)
        dao.insertStatement(s)
    }
    fun deleteStatement(id: Long) = execute { dao.deleteStatement(id) }
    fun saveSettings(s: FinanceSettings) = execute { settingsStore.update(s) }
    fun getAllowedPackages() = BankPackageAllowlist.get(getApplication()).joinToString(", ")
    fun saveAllowedPackages(raw: String) = BankPackageAllowlist.set(getApplication(), raw)

    suspend fun exportBackup(): String = withContext(Dispatchers.IO) {
        FinanceBackup.export(dao.allLedger(), dao.allEvents(), dao.allOverrides(), dao.allBills(), dao.allStatements(), dao.allRules(), dao.allPlans(), settingsStore.current(),
            dao.allAccounts(), dao.allTransfers(), dao.allAdjustments())
    }
    suspend fun exportCsv(): String = withContext(Dispatchers.IO) {
        fun cell(value: String): String {
            // Excel에서 값이 수식으로 실행되지 않도록 문자열 셀 보호
            val guarded = if (value.startsWith('=') || value.startsWith('+') || value.startsWith('-') || value.startsWith('@')) "'" + value else value
            return "\"" + guarded.replace("\"", "\"\"") + "\""
        }
        val header = "거래일,구분,금액,카테고리,가맹점,메모,상태,수집출처,태그,자산ID,납입자산ID,환급귀속월"
        val lines = dao.allLedger().map { e ->
            listOf(e.date, e.kind, e.amount.toString(), e.category, e.merchant, e.memo, e.status, e.source, e.tags, e.accountId?.toString().orEmpty(),
                e.destinationAccountId?.toString().orEmpty(), e.rebateForMonth.orEmpty())
                .mapIndexed { i, v -> if (i == 2) v else cell(v) }.joinToString(",")
        }
        "\uFEFF" + (listOf(header) + lines).joinToString("\r\n")
    }

    suspend fun importBackup(content: String) = withContext(Dispatchers.IO) {
        // 먼저 전체 검증 및 파싱, DB 트랜잭션은 원자적으로 처리
        val imported = FinanceBackup.parse(content)
        dao.replaceAll(imported.ledger, imported.events, imported.overrides, imported.bills, imported.statements, imported.rules, imported.plans,
            imported.accounts, imported.transfers, imported.adjustments)
        settingsStore.update(imported.settings)
        BudgetWidget.updateAll(getApplication())
    }
}
