package kr.personal.foldfinance.domain

import java.time.LocalDate

/** Account balances are independent of spending/saving statistics: transfers are zero-sum. */
data class AssetOpening(val id: Long, val name: String, val type: String, val openingDate: LocalDate, val openingBalance: Long, val active: Boolean)
data class AssetPosting(val date: LocalDate, val kind: String, val amount: Long, val status: String, val sourceId: Long?, val destinationId: Long?)
data class AssetTransferPosting(val date: LocalDate, val sourceId: Long, val destinationId: Long, val amount: Long)
data class AssetAdjustmentPosting(val date: LocalDate, val accountId: Long, val amountDelta: Long)
data class AssetPosition(val account: AssetOpening, val balance: Long)
data class AssetOverview(val positions: List<AssetPosition>, val unassignedConfirmedCount: Int, val total: Long, val liquid: Long)

object AssetFlow {
    val accountTypes = setOf("BANK", "CASH", "SAVINGS", "STOCK", "HOUSING", "OTHER")
    fun isLiquid(type: String) = type == "BANK" || type == "CASH"

    fun calculate(
        openings: List<AssetOpening>, postings: List<AssetPosting>, transfers: List<AssetTransferPosting>,
        adjustments: List<AssetAdjustmentPosting>, asOf: LocalDate = LocalDate.now()
    ): AssetOverview {
        require(openings.map { it.id }.distinct().size == openings.size)
        val balances = openings.associate { it.id to (if (it.openingDate <= asOf) it.openingBalance else 0L) }.toMutableMap()
        val accountMap = openings.associateBy { it.id }
        fun change(id: Long?, date: LocalDate, delta: Long) {
            if (id == null) return
            val opening = accountMap[id] ?: return
            if (date >= opening.openingDate && date <= asOf)
                balances[id] = Math.addExact(balances.getValue(id), delta)
        }
        val confirmed = postings.filter { it.date <= asOf && it.status in setOf("CONFIRMED", "SETTLED") }
        var missing = 0
        confirmed.forEach { e ->
            val validFrom = e.sourceId?.let { it in accountMap } == true
            val validTo = e.destinationId?.let { it in accountMap } == true
            when (e.kind) {
                "INCOME", "KPASS_REBATE" -> { if (!validFrom) missing++; change(e.sourceId, e.date, e.amount) }
                "EXPENSE" -> { if (!validFrom) missing++; change(e.sourceId, e.date, Math.negateExact(e.amount)) }
                "SAVING" -> {
                    if (!validFrom || !validTo || e.sourceId == e.destinationId) missing++
                    // To prevent phantom assets, only post when BOTH ends are valid and different.
                    if (validFrom && validTo && e.sourceId != e.destinationId) {
                        change(e.sourceId, e.date, Math.negateExact(e.amount)); change(e.destinationId, e.date, e.amount)
                    }
                }
            }
        }
        transfers.filter { it.date <= asOf }.forEach { t ->
            require(t.amount > 0 && t.sourceId != t.destinationId)
            change(t.sourceId, t.date, -t.amount)
            change(t.destinationId, t.date, t.amount)
        }
        adjustments.filter { it.date <= asOf }.forEach { a -> change(a.accountId, a.date, a.amountDelta) }
        val positions = openings.map { AssetPosition(it, balances.getValue(it.id)) }
        return AssetOverview(positions, missing, positions.sumOf { it.balance }, positions.filter { isLiquid(it.account.type) }.sumOf { it.balance })
    }
}
