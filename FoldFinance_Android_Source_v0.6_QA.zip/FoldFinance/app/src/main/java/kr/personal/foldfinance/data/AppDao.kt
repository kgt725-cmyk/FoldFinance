package kr.personal.foldfinance.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM asset_accounts ORDER BY active DESC, id ASC")
    fun watchAccounts(): Flow<List<AssetAccount>>
    @Query("SELECT * FROM asset_accounts ORDER BY id ASC")
    suspend fun allAccounts(): List<AssetAccount>
    @Insert suspend fun insertAccount(account: AssetAccount): Long
    @Query("UPDATE asset_accounts SET active = :active WHERE id = :id")
    suspend fun setAccountActive(id: Long, active: Boolean)
    @Query("DELETE FROM asset_accounts") suspend fun clearAccounts()
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun putAllAccounts(items: List<AssetAccount>)

    @Query("SELECT * FROM asset_transfers ORDER BY date DESC, id DESC")
    fun watchTransfers(): Flow<List<AssetTransfer>>
    @Query("SELECT * FROM asset_transfers ORDER BY id ASC")
    suspend fun allTransfers(): List<AssetTransfer>
    @Insert suspend fun insertTransfer(record: AssetTransfer)
    @Query("DELETE FROM asset_transfers WHERE id = :id") suspend fun deleteTransfer(id: Long)
    @Query("DELETE FROM asset_transfers") suspend fun clearTransfers()
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun putAllTransfers(items: List<AssetTransfer>)

    @Query("SELECT * FROM asset_adjustments ORDER BY date DESC, id DESC")
    fun watchAdjustments(): Flow<List<AssetAdjustment>>
    @Query("SELECT * FROM asset_adjustments ORDER BY id ASC")
    suspend fun allAdjustments(): List<AssetAdjustment>
    @Insert suspend fun insertAdjustment(record: AssetAdjustment)
    @Query("DELETE FROM asset_adjustments WHERE id = :id") suspend fun deleteAdjustment(id: Long)
    @Query("DELETE FROM asset_adjustments") suspend fun clearAdjustments()
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun putAllAdjustments(items: List<AssetAdjustment>)

    @Query("SELECT * FROM recurring_plans ORDER BY active DESC, kind, dayOfMonth, id")
    fun watchPlans(): Flow<List<RecurringPlan>>
    @Query("SELECT * FROM recurring_plans ORDER BY id")
    suspend fun allPlans(): List<RecurringPlan>
    @Insert suspend fun insertPlan(plan: RecurringPlan): Long
    @Query("UPDATE recurring_plans SET active = :active WHERE id = :id")
    suspend fun setPlanActive(id: Long, active: Boolean)
    @Query("DELETE FROM recurring_plans") suspend fun clearPlans()
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun putAllPlans(plans: List<RecurringPlan>)

    @Query("SELECT * FROM ledger ORDER BY date DESC, id DESC")
    fun watchLedger(): Flow<List<LedgerEntry>>
    @Query("SELECT * FROM merchant_rules ORDER BY merchantKey ASC")
    fun watchRules(): Flow<List<MerchantRule>>
    @Query("SELECT * FROM merchant_rules ORDER BY merchantKey ASC")
    suspend fun allRules(): List<MerchantRule>
    @Query("SELECT * FROM merchant_rules WHERE merchantKey = :key LIMIT 1")
    suspend fun ruleFor(key: String): MerchantRule?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putRule(rule: MerchantRule)
    @Query("DELETE FROM merchant_rules WHERE merchantKey = :key")
    suspend fun deleteRule(key: String)
    @Query("DELETE FROM merchant_rules") suspend fun clearRules()
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun putAllRules(rules: List<MerchantRule>)
    @Query("SELECT * FROM ledger ORDER BY date DESC, id DESC")
    suspend fun allLedger(): List<LedgerEntry>
    @Query("SELECT * FROM events ORDER BY date ASC, start ASC")
    fun watchEvents(): Flow<List<CalendarEvent>>
    @Query("SELECT * FROM events ORDER BY date ASC, start ASC")
    suspend fun allEvents(): List<CalendarEvent>
    @Query("SELECT * FROM workday_overrides")
    fun watchOverrides(): Flow<List<WorkdayOverride>>
    @Query("SELECT * FROM workday_overrides")
    suspend fun allOverrides(): List<WorkdayOverride>
    @Query("SELECT * FROM transit_bills ORDER BY endDate DESC")
    fun watchBills(): Flow<List<TransitBill>>
    @Query("SELECT * FROM transit_statements ORDER BY endDate DESC, id DESC")
    fun watchStatements(): Flow<List<TransitStatement>>
    @Query("SELECT * FROM transit_statements ORDER BY endDate DESC, id DESC")
    suspend fun allStatements(): List<TransitStatement>
    @Insert suspend fun insertStatement(statement: TransitStatement)
    @Query("DELETE FROM transit_statements WHERE id = :id")
    suspend fun deleteStatement(id: Long)
    @Query("DELETE FROM transit_statements") suspend fun clearStatements()
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun putAllStatements(records: List<TransitStatement>)
    @Query("SELECT * FROM transit_bills ORDER BY endDate DESC")
    suspend fun allBills(): List<TransitBill>
    @Query("SELECT * FROM ledger WHERE transitDate = :date LIMIT 1")
    suspend fun transitOn(date: String): LedgerEntry?
    @Query("SELECT count(*) FROM ledger WHERE dedupeKey = :key")
    suspend fun keyCount(key: String): Int
    @Query("SELECT count(*) FROM ledger WHERE kind = 'EXPENSE' AND merchant = :merchant AND amount = :amount AND createdAt BETWEEN :from AND :to")
    suspend fun nearDuplicate(merchant: String, amount: Long, from: Long, to: Long): Int
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertLedger(entry: LedgerEntry): Long
    @Update suspend fun updateLedger(entry: LedgerEntry)
    @Query("DELETE FROM ledger WHERE id = :id")
    suspend fun deleteLedger(id: Long)
    @Insert suspend fun insertEvent(event: CalendarEvent): Long
    @Query("DELETE FROM events WHERE id = :id")
    suspend fun deleteEventOnly(id: Long)
    @Query("UPDATE ledger SET linkedEventId = NULL WHERE linkedEventId = :id")
    suspend fun unlinkEventFromLedger(id: Long)
    @Transaction
    suspend fun deleteEvent(id: Long) {
        unlinkEventFromLedger(id)
        deleteEventOnly(id)
    }
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putOverride(override: WorkdayOverride)
    @Query("DELETE FROM workday_overrides WHERE date = :date")
    suspend fun deleteOverride(date: String)
    @Insert suspend fun insertBill(bill: TransitBill)
    @Query("DELETE FROM ledger") suspend fun clearLedger()
    @Query("DELETE FROM events") suspend fun clearEvents()
    @Query("DELETE FROM workday_overrides") suspend fun clearOverrides()
    @Query("DELETE FROM transit_bills") suspend fun clearBills()
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun putAllLedger(records: List<LedgerEntry>)
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun putAllEvents(records: List<CalendarEvent>)
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun putAllOverrides(records: List<WorkdayOverride>)
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun putAllBills(records: List<TransitBill>)
    @Transaction
    suspend fun replaceAll(
        ledger: List<LedgerEntry>, events: List<CalendarEvent>, overrides: List<WorkdayOverride>,
        bills: List<TransitBill>, statements: List<TransitStatement>, rules: List<MerchantRule>, plans: List<RecurringPlan>,
        accounts: List<AssetAccount>, transfers: List<AssetTransfer>, adjustments: List<AssetAdjustment>
    ) {
        clearLedger(); clearEvents(); clearOverrides(); clearBills(); clearStatements(); clearRules(); clearPlans(); clearTransfers(); clearAdjustments(); clearAccounts()
        putAllLedger(ledger); putAllEvents(events); putAllOverrides(overrides); putAllBills(bills)
        putAllStatements(statements); putAllRules(rules); putAllPlans(plans)
        putAllAccounts(accounts); putAllTransfers(transfers); putAllAdjustments(adjustments)
    }
}
