package kr.personal.foldfinance.data

import org.json.JSONArray
import org.json.JSONObject

/** SAF로 사용자가 직접 선택한 위치에 저장하는 JSON 백업. 0.1 버전은 암호화 미지원. */
object FinanceBackup {
    fun export(
        entries: List<LedgerEntry>, events: List<CalendarEvent>, overrides: List<WorkdayOverride>,
        bills: List<TransitBill>, statements: List<TransitStatement>, rules: List<MerchantRule>, plans: List<RecurringPlan>, s: FinanceSettings,
        accounts: List<AssetAccount>, transfers: List<AssetTransfer>, adjustments: List<AssetAdjustment>
    ): String = JSONObject().apply {
        put("schema", 5)
        put("settings", JSONObject().apply {
            put("salary", s.salary); put("savingsGoal", s.savingsGoal); put("budget", s.budget)
            put("payday", s.payday); put("oneWayFare", s.oneWayFare); put("ridesPerDay", s.ridesPerDay)
            put("weekdayMask", s.weekdayMask); put("kpassEnabled", s.kpassEnabled); put("widgetPrivate", s.widgetPrivate)
        })
        put("ledger", JSONArray().also { arr -> entries.forEach { e -> arr.put(JSONObject().apply {
            put("id", e.id); put("kind", e.kind); put("amount", e.amount); put("date", e.date)
            put("category", e.category); put("merchant", e.merchant); put("memo", e.memo)
            put("status", e.status); put("source", e.source); put("createdAt", e.createdAt); put("tags", e.tags)
            put("dedupeKey", e.dedupeKey ?: JSONObject.NULL)
            put("transitDate", e.transitDate ?: JSONObject.NULL)
            put("workMonth", e.workMonth ?: JSONObject.NULL)
            put("occurredAtTime", e.occurredAtTime ?: JSONObject.NULL)
            put("linkedEventId", e.linkedEventId ?: JSONObject.NULL)
            put("linkedRecurringId", e.linkedRecurringId ?: JSONObject.NULL)
            put("linkedPlanMonth", e.linkedPlanMonth ?: JSONObject.NULL)
            put("accountId", e.accountId ?: JSONObject.NULL)
            put("destinationAccountId", e.destinationAccountId ?: JSONObject.NULL)
            put("rebateForMonth", e.rebateForMonth ?: JSONObject.NULL)
        }) } })
        put("events", JSONArray().also { arr -> events.forEach { e -> arr.put(JSONObject().apply {
            put("id", e.id); put("date", e.date); put("title", e.title); put("start", e.start)
            put("end", e.end); put("note", e.note); put("budget", e.budget)
        }) } })
        put("overrides", JSONArray().also { arr -> overrides.forEach { arr.put(JSONObject().apply {
            put("date", it.date); put("isWorkday", it.isWorkday)
        }) } })
        put("bills", JSONArray().also { arr -> bills.forEach { e -> arr.put(JSONObject().apply {
            put("id", e.id); put("startDate", e.startDate); put("endDate", e.endDate)
            put("amount", e.amount); put("memo", e.memo)
        }) } })
        put("statements", JSONArray().also { arr -> statements.forEach { e -> arr.put(JSONObject().apply {
            put("id", e.id); put("startDate", e.startDate); put("endDate", e.endDate)
            put("amount", e.amount); put("memo", e.memo)
        }) } })
        put("rules", JSONArray().also { arr -> rules.forEach { e -> arr.put(JSONObject().apply {
            put("merchantKey", e.merchantKey); put("category", e.category)
            put("tags", e.tags); put("autoConfirm", e.autoConfirm)
        }) } })
        put("plans", JSONArray().also { arr -> plans.forEach { e -> arr.put(JSONObject().apply {
            put("id", e.id); put("kind", e.kind); put("title", e.title); put("amount", e.amount)
            put("category", e.category); put("dayOfMonth", e.dayOfMonth)
            put("startMonth", e.startMonth); put("active", e.active); put("memo", e.memo)
        }) } })
        put("accounts", JSONArray().also { arr -> accounts.forEach { a -> arr.put(JSONObject().apply {
            put("id", a.id); put("name", a.name); put("type", a.type)
            put("openingDate", a.openingDate); put("openingBalance", a.openingBalance); put("active", a.active)
        }) } })
        put("transfers", JSONArray().also { arr -> transfers.forEach { a -> arr.put(JSONObject().apply {
            put("id", a.id); put("date", a.date); put("sourceAccountId", a.sourceAccountId)
            put("destinationAccountId", a.destinationAccountId); put("amount", a.amount); put("memo", a.memo)
        }) } })
        put("adjustments", JSONArray().also { arr -> adjustments.forEach { a -> arr.put(JSONObject().apply {
            put("id", a.id); put("date", a.date); put("accountId", a.accountId)
            put("amountDelta", a.amountDelta); put("reason", a.reason); put("memo", a.memo)
        }) } })
    }.toString(2)

    data class Imported(
        val ledger: List<LedgerEntry>, val events: List<CalendarEvent>,
        val overrides: List<WorkdayOverride>, val bills: List<TransitBill>,
        val statements: List<TransitStatement>, val rules: List<MerchantRule>, val plans: List<RecurringPlan>, val settings: FinanceSettings,
        val accounts: List<AssetAccount>, val transfers: List<AssetTransfer>, val adjustments: List<AssetAdjustment>
    )
    fun parse(content: String): Imported {
        require(content.length <= 10_000_000) { "백업 파일이 너무 큽니다." }
        val root = JSONObject(content)
        val schema = root.getInt("schema")
        require(schema in 1..5) { "지원하지 않는 백업 버전" }
        val s = root.getJSONObject("settings")
        val settings = FinanceSettings(
            s.getLong("salary"), s.getLong("savingsGoal"), s.getLong("budget"), s.getInt("payday"),
            s.getLong("oneWayFare"), s.getInt("ridesPerDay"), s.getInt("weekdayMask"),
            s.getBoolean("kpassEnabled"), s.getBoolean("widgetPrivate")
        )
        require(settings.payday in 1..28 && settings.salary >= 0 && settings.savingsGoal >= 0 && settings.budget >= 0 && settings.oneWayFare >= 0 && settings.ridesPerDay in 0..10 && settings.weekdayMask in 0..127)
        fun <T> readArray(name: String, mapper: (JSONObject) -> T): List<T> {
            val arr = root.getJSONArray(name)
            require(arr.length() <= 100_000) { "기록이 너무 많습니다." }
            return (0 until arr.length()).map { mapper(arr.getJSONObject(it)) }
        }
        val ledger = readArray("ledger") { e ->
            LedgerEntry(
                id = e.getLong("id"), kind = e.getString("kind"), amount = e.getLong("amount"),
                date = e.getString("date"), category = e.getString("category"), merchant = e.getString("merchant"),
                memo = e.getString("memo"), status = e.getString("status"), source = e.getString("source"),
                dedupeKey = e.optString("dedupeKey").takeUnless { it == "null" || it.isBlank() },
                transitDate = e.optString("transitDate").takeUnless { it == "null" || it.isBlank() },
                workMonth = e.optString("workMonth").takeUnless { it == "null" || it.isBlank() },
                createdAt = e.getLong("createdAt"), tags = e.optString("tags", ""),
                occurredAtTime = e.optString("occurredAtTime").takeUnless { it == "null" || it.isBlank() },
                linkedEventId = if (e.isNull("linkedEventId")) null else e.optLong("linkedEventId").takeIf { it > 0 },
                linkedRecurringId = if (e.isNull("linkedRecurringId")) null else e.optLong("linkedRecurringId").takeIf { it > 0 },
                linkedPlanMonth = e.optString("linkedPlanMonth").takeUnless { it == "null" || it.isBlank() },
                accountId = e.optLong("accountId").takeIf { it > 0 },
                destinationAccountId = e.optLong("destinationAccountId").takeIf { it > 0 },
                rebateForMonth = e.optString("rebateForMonth").takeUnless { it == "null" || it.isBlank() }
            )
        }
        val events = readArray("events") { e ->
            CalendarEvent(e.getLong("id"), e.getString("date"), e.getString("title"), e.getString("start"),
                e.getString("end"), e.getString("note"), e.getLong("budget"))
        }
        val overrides = readArray("overrides") { e -> WorkdayOverride(e.getString("date"), e.getBoolean("isWorkday")) }
        val bills = readArray("bills") { e ->
            TransitBill(e.getLong("id"), e.getString("startDate"), e.getString("endDate"), e.getLong("amount"), e.getString("memo"))
        }
        val statements = if (schema == 1) emptyList() else readArray("statements") { e ->
            TransitStatement(e.getLong("id"), e.getString("startDate"), e.getString("endDate"), e.getLong("amount"), e.getString("memo"))
        }
        val rules = if (schema == 1 || !root.has("rules")) emptyList() else readArray("rules") { e ->
            MerchantRule(e.getString("merchantKey"), e.getString("category"), e.getString("tags"), e.getBoolean("autoConfirm"))
        }
        val plans = if (schema < 4) emptyList() else readArray("plans") { e ->
            RecurringPlan(e.getLong("id"), e.getString("kind"), e.getString("title"),
                e.getLong("amount"), e.getString("category"), e.getInt("dayOfMonth"),
                e.getString("startMonth"), e.getBoolean("active"), e.getString("memo"))
        }
        val accounts = if (schema < 5) emptyList() else readArray("accounts") { a ->
            AssetAccount(a.getLong("id"), a.getString("name"), a.getString("type"),
                a.getString("openingDate"), a.getLong("openingBalance"), a.getBoolean("active"))
        }
        val transfers = if (schema < 5) emptyList() else readArray("transfers") { a ->
            AssetTransfer(a.getLong("id"), a.getString("date"), a.getLong("sourceAccountId"),
                a.getLong("destinationAccountId"), a.getLong("amount"), a.getString("memo"))
        }
        val adjustments = if (schema < 5) emptyList() else readArray("adjustments") { a ->
            AssetAdjustment(a.getLong("id"), a.getString("date"), a.getLong("accountId"),
                a.getLong("amountDelta"), a.getString("reason"), a.getString("memo"))
        }
        val accountIds = accounts.map { it.id }.toSet()
        require(accountIds.size == accounts.size && accounts.all { it.id > 0 && it.name.isNotBlank() &&
            it.type in kr.personal.foldfinance.domain.AssetFlow.accountTypes &&
            runCatching { java.time.LocalDate.parse(it.openingDate) }.isSuccess && it.openingBalance >= 0 })
        require(transfers.map { it.id }.distinct().size == transfers.size && transfers.all {
            it.id > 0 && it.sourceAccountId in accountIds && it.destinationAccountId in accountIds &&
            it.sourceAccountId != it.destinationAccountId && it.amount > 0 &&
            runCatching { java.time.LocalDate.parse(it.date) }.isSuccess
        })
        require(adjustments.map { it.id }.distinct().size == adjustments.size && adjustments.all {
            it.id > 0 && it.accountId in accountIds && it.amountDelta != 0L && it.reason in setOf("VALUATION", "CORRECTION") &&
            runCatching { java.time.LocalDate.parse(it.date) }.isSuccess
        })
        require(plans.map { it.id }.distinct().size == plans.size)
        require(plans.all { it.id > 0 && it.kind in setOf("INCOME", "EXPENSE") && it.title.isNotBlank() &&
            it.category.isNotBlank() && it.amount > 0 && it.dayOfMonth in 1..28 &&
            kr.personal.foldfinance.domain.RecurringMath.validMonth(it.startMonth) })
        val planById = plans.associateBy { it.id }
        require(rules.map { it.merchantKey }.distinct().size == rules.size)
        require(rules.all { it.merchantKey.length in 2..100 && it.category.isNotBlank() })
        require((bills.map { Triple(it.startDate, it.endDate, it.amount) } + statements.map { Triple(it.startDate, it.endDate, it.amount) })
            .all { (start, end, amount) ->
                runCatching { java.time.LocalDate.parse(start) }.isSuccess &&
                runCatching { java.time.LocalDate.parse(end) }.isSuccess && start <= end && amount >= 0
            }) { "교통 정산의 날짜 또는 금액이 올바르지 않습니다." }
        require(statements.map { it.id }.distinct().size == statements.size)
        val eventIds = events.map { it.id }.toSet()
        require(events.map { it.id }.distinct().size == events.size)
        require(events.all { e ->
            runCatching { java.time.LocalDate.parse(e.date) }.isSuccess &&
            Regex("(?:[01]\\d|2[0-3]):[0-5]\\d").matches(e.start) &&
            Regex("(?:[01]\\d|2[0-3]):[0-5]\\d").matches(e.end) && e.start <= e.end && e.budget >= 0
        }) { "일정의 날짜·시간·금액이 잘못되었습니다." }
        require(ledger.all { e ->
            (e.occurredAtTime == null || Regex("(?:[01]\\d|2[0-3]):[0-5]\\d").matches(e.occurredAtTime)) &&
            (e.linkedRecurringId == null && e.linkedPlanMonth == null ||
              (e.linkedRecurringId != null && e.linkedPlanMonth != null &&
               kr.personal.foldfinance.domain.RecurringMath.validMonth(e.linkedPlanMonth) &&
               planById[e.linkedRecurringId]?.kind == e.kind)) &&
            (e.accountId == null || e.accountId in accountIds) &&
            (e.destinationAccountId == null || (e.destinationAccountId in accountIds && e.kind == "SAVING")) &&
            (e.rebateForMonth == null || (e.kind == "KPASS_REBATE" &&
             kr.personal.foldfinance.domain.RecurringMath.validMonth(e.rebateForMonth))) &&
            (e.linkedEventId == null || (e.linkedEventId in eventIds &&
                events.any { it.id == e.linkedEventId && it.date == e.date } && e.kind == "EXPENSE"))
        }) { "지출 일정 연결이나 결제 시각이 올바르지 않습니다." }
        require(ledger.all { e ->
            e.kind in setOf("INCOME", "SAVING", "EXPENSE", "KPASS_REBATE") &&
            e.status in setOf("EXPECTED", "REVIEW", "CONFIRMED", "SETTLED") &&
            e.category.isNotBlank() &&
            runCatching { java.time.LocalDate.parse(e.date) }.isSuccess &&
            (e.kind == "EXPENSE" || e.amount > 0L) &&
            (e.amount != 0L || (e.transitDate != null && e.kind == "EXPENSE")) &&
            (e.linkedRecurringId == null || e.amount > 0L)
        }) { "거래의 종류·상태·금액이 올바르지 않습니다." }
        require(ledger.map { it.id }.distinct().size == ledger.size && ledger.mapNotNull { it.dedupeKey }.distinct().size == ledger.mapNotNull { it.dedupeKey }.size)
        require(ledger.mapNotNull { it.transitDate }.distinct().size == ledger.mapNotNull { it.transitDate }.size)
        return Imported(ledger, events, overrides, bills, statements, rules, plans, settings, accounts, transfers, adjustments)
    }
}
