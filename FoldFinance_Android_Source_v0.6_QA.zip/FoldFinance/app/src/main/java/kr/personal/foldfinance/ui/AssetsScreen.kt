package kr.personal.foldfinance.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kr.personal.foldfinance.data.*
import kr.personal.foldfinance.domain.*
import java.time.LocalDate

private val assetLabels = listOf(
    "BANK" to "입출금·예금통장", "CASH" to "현금", "SAVINGS" to "적금·현금저축",
    "STOCK" to "주식·증권", "HOUSING" to "주택청약", "OTHER" to "기타"
)

/** Only confirmed dated records affect balances; asset changes are not saved twice as income/expense. */
internal fun overview(
    accounts: List<AssetAccount>, ledger: List<LedgerEntry>,
    transfers: List<AssetTransfer>, adjustments: List<AssetAdjustment>
): AssetOverview = AssetFlow.calculate(
    accounts.map { AssetOpening(it.id, it.name, it.type, LocalDate.parse(it.openingDate), it.openingBalance, it.active) },
    ledger.map { AssetPosting(LocalDate.parse(it.date), it.kind, it.amount, it.status, it.accountId, it.destinationAccountId) },
    transfers.map { AssetTransferPosting(LocalDate.parse(it.date), it.sourceAccountId, it.destinationAccountId, it.amount) },
    adjustments.map { AssetAdjustmentPosting(LocalDate.parse(it.date), it.accountId, it.amountDelta) }
)

@Composable
internal fun AccountSelector(
    label: String, accounts: List<AssetAccount>, selectedId: Long?, choose: (Long?) -> Unit,
    includeNone: Boolean = true
) {
    Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    var expanded by remember { mutableStateOf(false) }
    val name = accounts.firstOrNull { it.id == selectedId }?.name ?: "미지정"
    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text("$name  ▾") }
    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
        if (includeNone) DropdownMenuItem(text = { Text("미지정 (자산 잔액에는 반영되지 않음)") }, onClick = { choose(null); expanded = false })
        accounts.filter { it.active || it.id == selectedId }.forEach { a ->
            DropdownMenuItem(text = { Text("${a.name} · ${assetLabels.firstOrNull { it.first == a.type }?.second ?: a.type}") },
                onClick = { choose(a.id); expanded = false })
        }
    }
}

@Composable
internal fun AssetsPage(
    accounts: List<AssetAccount>, ledger: List<LedgerEntry>, transfers: List<AssetTransfer>,
    adjustments: List<AssetAdjustment>, model: FinanceViewModel
) {
    val summary = remember(accounts, ledger, transfers, adjustments) { overview(accounts, ledger, transfers, adjustments) }
    var creating by remember { mutableStateOf(false) }
    var moving by remember { mutableStateOf(false) }
    var reconciling by remember { mutableStateOf<AssetPosition?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        RoundedCard(Modifier.fillMaxWidth()) {
            Text("현재 자산 현황", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Metric("등록된 보유 자산 (부채 제외)", formatWon(summary.total))
            Spacer(Modifier.height(10.dp))
            Text("현금성 잔액 (통장·현금)  ${formatWon(summary.liquid)}", fontSize = 13.sp, color = Green)
            Text("카드 미결제금·예정 고정지출은 아직 차감하지 않습니다. 주식·청약은 현금성 잔액에서 제외합니다.", fontSize = 11.sp)
            if (summary.unassignedConfirmedCount > 0) {
                Spacer(Modifier.height(8.dp))
                Text("자산 미연결 확정 거래 ${summary.unassignedConfirmedCount}건 · 아래 합계가 실제 잔액과 다를 수 있습니다.", color = Pink, fontSize = 12.sp)
            }
            Text("초기 잔액은 기준일 아침의 금액입니다. 기준일 이전 거래를 중복 합산하지 않습니다.", fontSize = 11.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { creating = true }, modifier = Modifier.weight(1f)) { Text("+ 자산 등록", fontSize = 12.sp) }
            OutlinedButton(onClick = { moving = true }, enabled = accounts.count { it.active } >= 2, modifier = Modifier.weight(1f)) { Text("계좌 간 이체", fontSize = 12.sp) }
        }
        if (accounts.isEmpty()) RoundedCard(Modifier.fillMaxWidth()) {
            Text("입출금 통장부터 등록해 주세요.", fontWeight = FontWeight.Bold)
            Text("현재 잔액을 초기 잔액으로 입력하고, 이후 수입·지출·저축에 해당 자산을 연결하면 자동으로 계산합니다.", fontSize = 12.sp)
        }
        summary.positions.forEach { p ->
            RoundedCard(Modifier.fillMaxWidth()) {
                Text(p.account.name + if (!p.account.active) " (보관됨)" else "", fontWeight = FontWeight.Bold)
                Text(assetLabels.firstOrNull { it.first == p.account.type }?.second ?: p.account.type, fontSize = 12.sp)
                Spacer(Modifier.height(5.dp))
                Text(formatWon(p.balance), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = if (p.balance < 0L) Pink else Navy)
                Text("기준 ${p.account.openingDate} · 초기 ${formatWon(p.account.openingBalance)}", fontSize = 11.sp)
                Row {
                    TextButton(onClick = { reconciling = p }) { Text("현재 금액 맞추기", fontSize = 12.sp) }
                    TextButton(onClick = { model.setAccountActive(p.account.id, !p.account.active) }) {
                        Text(if (p.account.active) "보관" else "재사용", fontSize = 12.sp)
                    }
                }
            }
        }
        if (transfers.isNotEmpty()) RoundedCard(Modifier.fillMaxWidth()) {
            Text("최근 계좌 간 이체", fontWeight = FontWeight.Bold)
            transfers.take(5).forEach { transfer ->
                val from = accounts.find { it.id == transfer.sourceAccountId }?.name ?: "미상"
                val to = accounts.find { it.id == transfer.destinationAccountId }?.name ?: "미상"
                Text("${transfer.date} · $from → $to · ${formatWon(transfer.amount)}", fontSize = 12.sp)
                TextButton(onClick = { model.deleteAssetTransfer(transfer.id) }) { Text("이체 취소 (기록 삭제)", fontSize = 11.sp) }
            }
        }
        if (adjustments.isNotEmpty()) RoundedCard(Modifier.fillMaxWidth()) {
            Text("최근 잔액·평가 조정", fontWeight = FontWeight.Bold)
            adjustments.take(5).forEach { a ->
                val accountName = accounts.find { it.id == a.accountId }?.name ?: "미상"
                Text("${a.date} · $accountName · ${formatWon(a.amountDelta)} · ${if (a.reason == "VALUATION") "평가액" else "정정"}", fontSize = 12.sp)
                TextButton(onClick = { model.deleteAssetAdjustment(a.id) }) { Text("조정 취소", fontSize = 11.sp) }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
    if (creating) CreateAssetDialog(onClose = { creating = false }) { model.addAccount(it); creating = false }
    if (moving) TransferAssetDialog(accounts, { moving = false }) { model.addAssetTransfer(it); moving = false }
    reconciling?.let { p -> ReconcileAssetDialog(p, { reconciling = null }) {
        model.addAssetAdjustment(it); reconciling = null
    } }
}

@Composable
private fun CreateAssetDialog(onClose: () -> Unit, onSave: (AssetAccount) -> Unit) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("BANK") }
    var start by remember { mutableStateOf(LocalDate.now().toString()) }
    var balance by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, title = { Text("자산 등록") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("현재 보유 금액을 기준일 아침의 초기 금액으로 기록합니다. 이미 등록한 거래를 다시 더하지 마세요.", fontSize = 12.sp)
            Field("자산 이름 (예: 주거래 통장)", name, { name = it })
            Text("자산 유형", fontWeight = FontWeight.Medium, fontSize = 12.sp)
            assetLabels.forEach { (key, value) -> FilterChip(selected = type == key, onClick = { type = key }, label = { Text(value, fontSize = 12.sp) }) }
            Field("잔액 기준일 (YYYY-MM-DD)", start, { start = it })
            Field("기준일 아침 잔액 · 원", balance, { balance = it })
            if (error.isNotBlank()) Text(error, color = Pink, fontSize = 12.sp)
        } },
        confirmButton = { TextButton(onClick = {
            val n = parseWon(balance)
            if (name.isBlank() || tryDate(start) == null || n == null || n < 0) error = "자산 이름·날짜·잔액을 확인해 주세요."
            else onSave(AssetAccount(name = name.trim(), type = type, openingDate = start, openingBalance = n))
        }) { Text("등록") } }, dismissButton = { TextButton(onClick = onClose) { Text("취소") } })
}

@Composable
private fun TransferAssetDialog(accounts: List<AssetAccount>, onClose: () -> Unit, onSave: (AssetTransfer) -> Unit) {
    var from by remember { mutableStateOf<Long?>(null) }
    var to by remember { mutableStateOf<Long?>(null) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var amount by remember { mutableStateOf("") }
    var memo by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, title = { Text("계좌 간 자금 이동") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("이체는 자산 간 이동이며 수입·저축·지출 통계에 합산되지 않습니다. 저축 납입으로 인정할 돈은 ‘저축’ 메뉴에서 출금·납입 계좌를 선택하세요.", fontSize = 12.sp)
            AccountSelector("출금 자산", accounts, from, { from = it }, false)
            AccountSelector("입금 자산", accounts, to, { to = it }, false)
            Field("이체일", date, { date = it })
            Field("금액", amount, { amount = it })
            Field("메모", memo, { memo = it })
            if (error.isNotBlank()) Text(error, color = Pink)
        } }, confirmButton = { TextButton(onClick = {
            val n = parseWon(amount)
            if (from == null || to == null || from == to || n == null || n <= 0 || tryDate(date) == null ||
                accounts.any { it.id == from && date < it.openingDate } || accounts.any { it.id == to && date < it.openingDate }) error = "출금·입금 자산과 날짜·금액을 확인하세요."
            else onSave(AssetTransfer(date = date, sourceAccountId = from!!, destinationAccountId = to!!, amount = n, memo = memo))
        }) { Text("이체 기록") } }, dismissButton = { TextButton(onClick = onClose) { Text("취소") } })
}

@Composable
private fun ReconcileAssetDialog(position: AssetPosition, onClose: () -> Unit, onSave: (AssetAdjustment) -> Unit) {
    var actual by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var reason by remember { mutableStateOf(if (position.account.type == "STOCK") "VALUATION" else "CORRECTION") }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, title = { Text("${position.account.name} 금액 맞추기") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("현재 계산 잔액 ${formatWon(position.balance)}", fontWeight = FontWeight.Bold)
            Text("실제 확인한 보유액을 입력하면 차액을 기록합니다. 수입·저축 실적에는 반영하지 않습니다.", fontSize = 12.sp)
            Field("현재 실제 금액", actual, { actual = it })
            Field("조정 날짜", date, { date = it })
            Row {
                FilterChip(selected = reason == "VALUATION", onClick = { reason = "VALUATION" }, label = { Text("평가금액 변경") })
                Spacer(Modifier.width(6.dp))
                FilterChip(selected = reason == "CORRECTION", onClick = { reason = "CORRECTION" }, label = { Text("잔액 오류 정정") })
            }
            if (error.isNotBlank()) Text(error, color = Pink)
        } }, confirmButton = { TextButton(onClick = {
            val n = parseWon(actual)
            if (n == null || n < 0L || tryDate(date) == null || date != LocalDate.now().toString() || n == position.balance) {
                error = "오늘 날짜와 현재 계산 금액과 다른 유효한 금액을 입력하세요."
            } else onSave(AssetAdjustment(date = date, accountId = position.account.id, amountDelta = n - position.balance, reason = reason))
        }) { Text("차액 저장") } }, dismissButton = { TextButton(onClick = onClose) { Text("취소") } })
}
