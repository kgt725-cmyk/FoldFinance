package kr.personal.foldfinance.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kr.personal.foldfinance.data.CalendarEvent
import kr.personal.foldfinance.data.FinanceViewModel
import kr.personal.foldfinance.data.LedgerEntry
import kr.personal.foldfinance.domain.*
import java.time.LocalDate
import java.time.YearMonth

@Composable
private fun EventForm(initialDate: String, onClose: () -> Unit, onSave: (CalendarEvent) -> Unit) {
    var date by remember { mutableStateOf(initialDate) }
    var title by remember { mutableStateOf("") }
    var start by remember { mutableStateOf("14:00") }
    var end by remember { mutableStateOf("20:00") }
    var budget by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, title = { Text("일정 추가") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("일정 날짜", date, { date = it }); Field("일정 제목", title, { title = it })
            Field("시작 HH:mm", start, { start = it }); Field("종료 HH:mm", end, { end = it })
            Field("예상 지출 예산 (선택)", budget, { budget = it }); Field("메모", notes, { notes = it })
            if(error.isNotBlank()) Text(error, color = Pink)
        } },
        confirmButton = { TextButton(onClick = {
            val money = if(budget.isBlank()) 0L else parseWon(budget)
            if(tryDate(date) == null || title.isBlank() || !Regex("(?:[01]\\d|2[0-3]):[0-5]\\d").matches(start) ||
                !Regex("(?:[01]\\d|2[0-3]):[0-5]\\d").matches(end) || end < start || money == null || money < 0) error = "입력 내용을 확인하세요."
            else onSave(CalendarEvent(date = date, title = title, start = start, end = end, budget = money, note = notes))
        }) { Text("등록") } }, dismissButton = { TextButton(onClick = onClose) { Text("취소") } })
}

@Composable
private fun MonthCalendar(selected: LocalDate, onSelect: (LocalDate) -> Unit, events: List<CalendarEvent>, entries: List<LedgerEntry>) {
    val ym = YearMonth.from(selected)
    val firstOffset = ym.atDay(1).dayOfWeek.value - 1
    val count = (firstOffset + ym.lengthOfMonth() + 6) / 7
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("월","화","수","목","금","토","일").forEach { Text(it, fontSize = 11.sp, color = Color.Gray) }
        }
        repeat(count) { week ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                repeat(7) { dow ->
                    val dayNum = week * 7 + dow - firstOffset + 1
                    if(dayNum in 1..ym.lengthOfMonth()) {
                        val date = ym.atDay(dayNum)
                        val transaction = entries.filter { it.date == date.toString() && it.kind == "EXPENSE" && it.status in listOf("CONFIRMED", "SETTLED") }.sumOf { it.amount }
                        val hasEvent = events.any { it.date == date.toString() }
                        Column(
                            Modifier.weight(1f).height(71.dp).padding(top = 3.dp)
                                .background(if(date == selected) Color(0xFFE1EDFF) else Color.Transparent, shape = androidx.compose.foundation.shape.RoundedCornerShape(9.dp))
                                .clickable { onSelect(date) }.padding(4.dp)
                        ) {
                            Text("$dayNum", fontSize = 12.sp, fontWeight = if(date == selected) FontWeight.Bold else FontWeight.Normal)
                            if(transaction != 0L) Text("${transaction / 1000}천", fontSize = 9.sp, color = Pink)
                            if(hasEvent) Text("●", fontSize = 8.sp, color = Blue)
                        }
                    } else Spacer(Modifier.weight(1f).height(71.dp))
                }
            }
        }
    }
}

@Composable
internal fun CalendarPage(events: List<CalendarEvent>, ledger: List<LedgerEntry>, model: FinanceViewModel, wide: Boolean, accounts: List<AssetAccount>) {
    var selectedRaw by rememberSaveable { mutableStateOf(LocalDate.now().toString()) }
    val selected = tryDate(selectedRaw) ?: LocalDate.now()
    var create by remember { mutableStateOf(false) }
    var editingTransaction by remember { mutableStateOf<LedgerEntry?>(null) }
    val dayEvents = events.filter { it.date == selectedRaw }
    val dayLedger = ledger.filter { it.date == selectedRaw && it.kind == "EXPENSE" }
    val calendarPanel: @Composable ColumnScope.() -> Unit = {
        RoundedCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { selectedRaw = selected.minusMonths(1).toString() }) { Text("◀") }
                Text("${selected.year}년 ${selected.monthValue}월", fontWeight = FontWeight.Bold)
                TextButton(onClick = { selectedRaw = selected.plusMonths(1).toString() }) { Text("▶") }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { selectedRaw = LocalDate.now().toString() }) { Text("오늘") }
            }
            MonthCalendar(selected, { selectedRaw = it.toString() }, events, ledger)
        }
    }
    val details: @Composable ColumnScope.() -> Unit = {
        RoundedCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$selected", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Button(onClick = { create = true }) { Text("+ 일정") }
            }
            Text("일정", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            if(dayEvents.isEmpty()) Text("등록된 일정 없음", fontSize = 12.sp, color = Color.Gray)
            dayEvents.forEach { item ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${item.start}~${item.end}  ${item.title}", fontSize = 13.sp)
                        if(item.budget > 0) Text("예상 예산 ${formatWon(item.budget)}", fontSize = 11.sp)
                        val linked = dayLedger.filter { it.linkedEventId == item.id && it.status in listOf("CONFIRMED", "SETTLED") }
                        Text("연결된 확정 지출 ${linked.size}건 · ${formatWon(linked.sumOf { it.amount })}", fontSize = 11.sp, color = Green)
                    }
                    TextButton(onClick = { model.deleteEvent(item.id) }) { Text("삭제") }
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("확인된 소비 ${formatWon(dayLedger.filter { it.status in listOf("CONFIRMED", "SETTLED") }.sumOf { it.amount })}", fontWeight = FontWeight.SemiBold)
            dayLedger.forEach { row ->
                Row(Modifier.fillMaxWidth().clickable { editingTransaction = row }.padding(vertical = 6.dp)) {
                    Text(row.merchant.ifBlank { row.category }, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text(if(row.status == "REVIEW") "확인 필요" else formatWon(row.amount), fontSize = 12.sp)
                }
            }
            Text("위 지출 내역을 누르면 이 화면에서 바로 수정할 수 있습니다. 실제 거래 시각을 입력해 일정을 연결하면 해당 일정에 합계를 표시하며, 전체 소비에 다시 더하지 않습니다.", fontSize = 11.sp, color = Color.Gray)
        }
    }
    if(wide) Row(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1.1f), content = calendarPanel)
        Column(Modifier.weight(1f), content = details)
    } else Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        calendarPanel(); details()
    }
    if(create) EventForm(selectedRaw, { create = false }) { model.addEvent(it); create = false }
    editingTransaction?.let { entry ->
        LedgerEditor("EXPENSE", events, accounts = accounts, original = entry, onDismiss = { editingTransaction = null }) {
            model.updateEntry(it)
            editingTransaction = null
        }
    }
}
